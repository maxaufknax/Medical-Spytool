import os
import subprocess
import sys
import webbrowser
import time

def main():
    print("Starting Medical SpyTool...")
    
    # Find the backend directory
    backend_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "backend")
    
    # Start the backend server
    os.chdir(backend_dir)
    
    # Start server process
    server_process = subprocess.Popen(
        [sys.executable, "-m", "app.main"], 
        cwd=backend_dir
    )
    
    # Give the server some time to start
    print("Starting server...")
    time.sleep(2)
    
    # Open the frontend in the default web browser
    frontend_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 
                                "frontend", "index.html")
    print(f"Opening frontend at {frontend_path}")
    
    # Convert to URL format and open in browser
    frontend_url = f"file://{os.path.abspath(frontend_path)}"
    webbrowser.open(frontend_url)
    
    print("Medical SpyTool is running!")
    print("Press Ctrl+C to exit")
    
    try:
        # Keep the script running until user interrupts
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("Shutting down...")
        server_process.terminate()
        server_process.wait(timeout=5)
        print("Goodbye!")

if __name__ == "__main__":
    main()
