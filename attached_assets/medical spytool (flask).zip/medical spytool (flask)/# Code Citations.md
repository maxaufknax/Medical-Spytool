# Code Citations

## License: unknown
https://github.com/redterm/fastapi-postgres/blob/c1265b5945aff29be96a2e3fa00b199761f3482e/app/auth_services.py

```
=
```


## License: unknown
https://github.com/redterm/fastapi-postgres/blob/c1265b5945aff29be96a2e3fa00b199761f3482e/app/auth_services.py

```
=status.HTTP_
```


## License: unknown
https://github.com/redterm/fastapi-postgres/blob/c1265b5945aff29be96a2e3fa00b199761f3482e/app/auth_services.py

```
=status.HTTP_401_UNAUTHORIZED
```


## License: unknown
https://github.com/redterm/fastapi-postgres/blob/c1265b5945aff29be96a2e3fa00b199761f3482e/app/auth_services.py

```
=status.HTTP_401_UNAUTHORIZED,
        detail
```


## License: unknown
https://github.com/redterm/fastapi-postgres/blob/c1265b5945aff29be96a2e3fa00b199761f3482e/app/auth_services.py

```
=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate
```


## License: unknown
https://github.com/redterm/fastapi-postgres/blob/c1265b5945aff29be96a2e3fa00b199761f3482e/app/auth_services.py

```
=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        
```


## License: unknown
https://github.com/redterm/fastapi-postgres/blob/c1265b5945aff29be96a2e3fa00b199761f3482e/app/auth_services.py

```
=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WW
```


## License: unknown
https://github.com/redterm/fastapi-postgres/blob/c1265b5945aff29be96a2e3fa00b199761f3482e/app/auth_services.py

```
=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate
```


## License: unknown
https://github.com/redterm/fastapi-postgres/blob/c1265b5945aff29be96a2e3fa00b199761f3482e/app/auth_services.py

```
=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
```


## License: unknown
https://github.com/redterm/fastapi-postgres/blob/c1265b5945aff29be96a2e3fa00b199761f3482e/app/auth_services.py

```
=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
```


## License: unknown
https://github.com/redterm/fastapi-postgres/blob/c1265b5945aff29be96a2e3fa00b199761f3482e/app/auth_services.py

```
=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try
```


## License: unknown
https://github.com/redterm/fastapi-postgres/blob/c1265b5945aff29be96a2e3fa00b199761f3482e/app/auth_services.py

```
=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payloa
```


## License: unknown
https://github.com/redterm/fastapi-postgres/blob/c1265b5945aff29be96a2e3fa00b199761f3482e/app/auth_services.py

```
=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode
```


## License: unknown
https://github.com/redterm/fastapi-postgres/blob/c1265b5945aff29be96a2e3fa00b199761f3482e/app/auth_services.py

```
=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, settings
```


## License: unknown
https://github.com/redterm/fastapi-postgres/blob/c1265b5945aff29be96a2e3fa00b199761f3482e/app/auth_services.py

```
=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, settings.SECRET
```


## License: unknown
https://github.com/redterm/fastapi-postgres/blob/c1265b5945aff29be96a2e3fa00b199761f3482e/app/auth_services.py

```
=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, settings.SECRET_KEY, algorithms
```


## License: unknown
https://github.com/redterm/fastapi-postgres/blob/c1265b5945aff29be96a2e3fa00b199761f3482e/app/auth_services.py

```
=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, settings.SECRET_KEY, algorithms=
```


## License: unknown
https://github.com/redterm/fastapi-postgres/blob/c1265b5945aff29be96a2e3fa00b199761f3482e/app/auth_services.py

```
=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, settings.SECRET_KEY, algorithms=["HS256
```


## License: unknown
https://github.com/redterm/fastapi-postgres/blob/c1265b5945aff29be96a2e3fa00b199761f3482e/app/auth_services.py

```
=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, settings.SECRET_KEY, algorithms=["HS256"])
        username
```


## License: unknown
https://github.com/redterm/fastapi-postgres/blob/c1265b5945aff29be96a2e3fa00b199761f3482e/app/auth_services.py

```
=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, settings.SECRET_KEY, algorithms=["HS256"])
        username: str = payloa
```


## License: unknown
https://github.com/redterm/fastapi-postgres/blob/c1265b5945aff29be96a2e3fa00b199761f3482e/app/auth_services.py

```
=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, settings.SECRET_KEY, algorithms=["HS256"])
        username: str = payload.get("sub
```


## License: unknown
https://github.com/redterm/fastapi-postgres/blob/c1265b5945aff29be96a2e3fa00b199761f3482e/app/auth_services.py

```
=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, settings.SECRET_KEY, algorithms=["HS256"])
        username: str = payload.get("sub")
```


## License: unknown
https://github.com/redterm/fastapi-postgres/blob/c1265b5945aff29be96a2e3fa00b199761f3482e/app/auth_services.py

```
=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, settings.SECRET_KEY, algorithms=["HS256"])
        username: str = payload.get("sub")
        if username
```


## License: unknown
https://github.com/redterm/fastapi-postgres/blob/c1265b5945aff29be96a2e3fa00b199761f3482e/app/auth_services.py

```
=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, settings.SECRET_KEY, algorithms=["HS256"])
        username: str = payload.get("sub")
        if username is None:
```


## License: unknown
https://github.com/redterm/fastapi-postgres/blob/c1265b5945aff29be96a2e3fa00b199761f3482e/app/auth_services.py

```
=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, settings.SECRET_KEY, algorithms=["HS256"])
        username: str = payload.get("sub")
        if username is None:
            raise
```

