from typing import List, Dict
import pandas as pd
from .base_exporter import BaseExporter

class ExcelExporter(BaseExporter):
    def export(self, results: List[Dict], filepath: str):
        if not results:
            return
            
        # Convert results to DataFrame
        df = pd.DataFrame(results)
        
        # Write to Excel file
        with pd.ExcelWriter(filepath, engine='openpyxl') as writer:
            df.to_excel(writer, index=False, sheet_name='Search Results')
            
            # Auto-adjust column widths
            worksheet = writer.sheets['Search Results']
            for idx, col in enumerate(df.columns):
                max_length = max(
                    df[col].astype(str).apply(len).max(),
                    len(str(col))
                )
                worksheet.column_dimensions[chr(65 + idx)].width = max_length + 2
