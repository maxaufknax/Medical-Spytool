from typing import List, Dict
from .base_exporter import BaseExporter

class BibtexExporter(BaseExporter):
    def export(self, results: List[Dict], filepath: str):
        if not results:
            return
            
        with open(filepath, 'w', encoding='utf-8') as f:
            for result in results:
                entry = self._format_bibtex_entry(result)
                f.write(entry + '\n\n')
    
    def _format_bibtex_entry(self, result: Dict) -> str:
        # Generate citation key from first author's lastname and year
        authors = result.get('authors', 'Unknown').split(',')[0].strip()
        year = result.get('year', 'XXXX')
        cite_key = f"{authors.split()[-1]}{year}"
        
        # Format basic BibTeX entry
        entry = f"@article{{{cite_key},\n"
        entry += f"  title = {{{result.get('title', '')}}},\n"
        entry += f"  author = {{{result.get('authors', '')}}},\n"
        entry += f"  year = {{{result.get('year', '')}}},\n"
        
        # Add optional fields if available
        if 'journal' in result:
            entry += f"  journal = {{{result['journal']}}},\n"
        if 'doi' in result:
            entry += f"  doi = {{{result['doi']}}},\n"
        if 'abstract' in result:
            entry += f"  abstract = {{{result['abstract']}}},\n"
            
        entry += "}"
        return entry
