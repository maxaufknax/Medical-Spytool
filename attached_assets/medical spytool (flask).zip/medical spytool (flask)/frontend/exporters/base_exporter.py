from abc import ABC, abstractmethod
from typing import List, Dict

class BaseExporter(ABC):
    @abstractmethod
    def export(self, results: List[Dict], filepath: str):
        pass
