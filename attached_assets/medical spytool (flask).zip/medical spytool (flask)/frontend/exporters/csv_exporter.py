import csv
from typing import List, Dict
from .base_exporter import BaseExporter

class CSVExporter(BaseExporter):
    def export(self, results: List[Dict], filepath: str):
        if not results:
            return
        
        with open(filepath, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=results[0].keys())
            writer.writeheader()
            writer.writerows(results)
