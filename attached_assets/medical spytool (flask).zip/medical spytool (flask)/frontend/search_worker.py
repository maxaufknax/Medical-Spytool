from PyQt6.QtCore import QObject, pyqtSignal
import aiohttp
import asyncio
from typing import Dict, Any

class SearchWorker(QObject):
    finished = pyqtSignal(list)
    error = pyqtSignal(str)
    
    def __init__(self):
        super().__init__()
        self.session = None
        
    async def setup(self):
        self.session = aiohttp.ClientSession()
        
    async def search(self, endpoint: str, params: Dict[str, Any]):
        try:
            async with self.session.post(f'http://localhost:8000/api/v1/search/{endpoint}', json=params) as response:
                if response.status == 200:
                    results = await response.json()
                    self.finished.emit(results)
                else:
                    self.error.emit(f"Error: {response.status}")
        except Exception as e:
            self.error.emit(str(e))
