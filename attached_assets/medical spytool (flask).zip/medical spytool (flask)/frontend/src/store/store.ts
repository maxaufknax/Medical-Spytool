import { configureStore, createSlice, PayloadAction } from '@reduxjs/toolkit';
import { SearchResult, SearchParameters } from '../types/api';

interface SearchState {
    results: SearchResult[];
    loading: boolean;
    error: string | null;
    currentDatabase: string;
    searchParameters: SearchParameters;
}

const initialState: SearchState = {
    results: [],
    loading: false,
    error: null,
    currentDatabase: 'pubmed',
    searchParameters: {
        max_results: 100,
        field: 'Alle Felder'
    }
};

const searchSlice = createSlice({
    name: 'search',
    initialState,
    reducers: {
        setResults(state, action: PayloadAction<SearchResult[]>) {
            state.results = action.payload;
            state.loading = false;
            state.error = null;
        },
        setLoading(state, action: PayloadAction<boolean>) {
            state.loading = action.payload;
        },
        setError(state, action: PayloadAction<string>) {
            state.error = action.payload;
            state.loading = false;
        },
        updateSearchParameters(state, action: PayloadAction<Partial<SearchParameters>>) {
            state.searchParameters = { ...state.searchParameters, ...action.payload };
        }
    }
});

export const store = configureStore({
    reducer: {
        search: searchSlice.reducer
    }
});

export const { setResults, setLoading, setError, updateSearchParameters } = searchSlice.actions;
export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
