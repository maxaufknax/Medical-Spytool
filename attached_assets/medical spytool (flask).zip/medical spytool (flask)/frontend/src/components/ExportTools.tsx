import React from 'react';
import { SearchResult } from '../types/api';
import { saveAs } from 'file-saver';
import * as XLSX from 'xlsx';

interface ExportToolsProps {
    results: SearchResult[];
    database: string;
}

export const ExportTools: React.FC<ExportToolsProps> = ({ results, database }) => {
    const exportToExcel = () => {
        const ws = XLSX.utils.json_to_sheet(results);
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, 'Results');
        const excelBuffer = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
        const data = new Blob([excelBuffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
        saveAs(data, `${database}_results_${new Date().toISOString()}.xlsx`);
    };

    const exportToBibTeX = () => {
        const bibTeX = results.map(result => {
            return `@article{${result.doi || 'unknown'},
  title={${result.title}},
  author={${result.authors.join(' and ')}},
  journal={${result.journal || 'unknown'}},
  year={${result.year}},
  doi={${result.doi || 'unknown'}}
}`
        }).join('\n\n');

        const blob = new Blob([bibTeX], { type: 'text/plain;charset=utf-8' });
        saveAs(blob, `${database}_results_${new Date().toISOString()}.bib`);
    };

    return (
        <div className="flex gap-2 my-4">
            <button
                onClick={exportToExcel}
                className="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600"
            >
                Excel Export
            </button>
            <button
                onClick={exportToBibTeX}
                className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600"
            >
                BibTeX Export
            </button>
        </div>
    );
};
