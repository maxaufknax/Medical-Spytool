import React from 'react';
import { format } from 'date-fns';

interface SearchHistoryItem {
    id: number;
    query: string;
    database: string;
    timestamp: string;
    results_count: number;
}

interface SearchHistoryProps {
    history: SearchHistoryItem[];
    onHistoryItemClick: (query: string, database: string) => void;
}

export const SearchHistory: React.FC<SearchHistoryProps> = ({
    history,
    onHistoryItemClick
}) => {
    return (
        <div className="mt-4">
            <h3 className="text-lg font-semibold mb-2">Suchverlauf</h3>
            <div className="bg-white shadow overflow-hidden sm:rounded-md">
                <ul className="divide-y divide-gray-200">
                    {history.map((item) => (
                        <li key={item.id}>
                            <button
                                onClick={() => onHistoryItemClick(item.query, item.database)}
                                className="w-full text-left px-4 py-4 hover:bg-gray-50 focus:outline-none"
                            >
                                <div className="flex items-center justify-between">
                                    <div>
                                        <p className="text-sm font-medium text-indigo-600 truncate">
                                            {item.query}
                                        </p>
                                        <p className="text-sm text-gray-500">
                                            {item.database} • {item.results_count} Ergebnisse
                                        </p>
                                    </div>
                                    <div className="text-sm text-gray-500">
                                        {format(new Date(item.timestamp), 'dd.MM.yyyy HH:mm')}
                                    </div>
                                </div>
                            </button>
                        </li>
                    ))}
                </ul>
            </div>
        </div>
    );
};
