import React from 'react';
import DatePicker from 'react-datepicker';
import "react-datepicker/dist/react-datepicker.css";

interface AdvancedSearchProps {
    onParametersChange: (params: any) => void;
    expanded: boolean;
}

export const AdvancedSearch: React.FC<AdvancedSearchProps> = ({
    onParametersChange,
    expanded
}) => {
    const [dateFrom, setDateFrom] = React.useState<Date | null>(null);
    const [dateTo, setDateTo] = React.useState<Date | null>(null);
    const [language, setLanguage] = React.useState<string>('');
    const [publicationType, setPublicationType] = React.useState<string>('');

    React.useEffect(() => {
        onParametersChange({
            date_from: dateFrom,
            date_to: dateTo,
            language,
            publication_type: publicationType
        });
    }, [dateFrom, dateTo, language, publicationType]);

    if (!expanded) return null;

    return (
        <div className="p-4 bg-gray-50 rounded-lg">
            <div className="grid grid-cols-2 gap-4">
                <div>
                    <label className="block text-sm font-medium text-gray-700">Von</label>
                    <DatePicker
                        selected={dateFrom}
                        onChange={date => setDateFrom(date)}
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm"
                    />
                </div>
                <div>
                    <label className="block text-sm font-medium text-gray-700">Bis</label>
                    <DatePicker
                        selected={dateTo}
                        onChange={date => setDateTo(date)}
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm"
                    />
                </div>
                <div>
                    <label className="block text-sm font-medium text-gray-700">Sprache</label>
                    <select
                        value={language}
                        onChange={e => setLanguage(e.target.value)}
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm"
                    >
                        <option value="">Alle</option>
                        <option value="eng">Englisch</option>
                        <option value="ger">Deutsch</option>
                    </select>
                </div>
                <div>
                    <label className="block text-sm font-medium text-gray-700">Publikationstyp</label>
                    <select
                        value={publicationType}
                        onChange={e => setPublicationType(e.target.value)}
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm"
                    >
                        <option value="">Alle</option>
                        <option value="article">Artikel</option>
                        <option value="review">Review</option>
                        <option value="book">Buch</option>
                    </select>
                </div>
            </div>
        </div>
    );
};
