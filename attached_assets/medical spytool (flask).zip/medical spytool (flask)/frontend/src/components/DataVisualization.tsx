import React from 'react';
import {
    BarChart,
    Bar,
    XAxis,
    YAxis,
    CartesianGrid,
    Tooltip,
    ResponsiveContainer
} from 'recharts';

interface ChartData {
    name: string;
    value: number;
}

interface DataVisualizationProps {
    yearDistribution: Record<string, number>;
    title: string;
}

export const DataVisualization: React.FC<DataVisualizationProps> = ({
    yearDistribution,
    title
}) => {
    const chartData: ChartData[] = Object.entries(yearDistribution)
        .map(([year, count]) => ({
            name: year,
            value: count
        }))
        .sort((a, b) => a.name.localeCompare(b.name));

    return (
        <div className="w-full h-80">
            <h3 className="text-lg font-semibold mb-4">{title}</h3>
            <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="value" fill="#4f46e5" />
                </BarChart>
            </ResponsiveContainer>
        </div>
    );
};
