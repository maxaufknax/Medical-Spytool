import React from 'react';
import { SearchResult } from '../types/api';

interface ResultsTableProps {
    results: SearchResult[];
}

export const ResultsTable: React.FC<ResultsTableProps> = ({ results }) => {
    return (
        <div className="overflow-x-auto">
            <table className="min-w-full table-auto">
                <thead>
                    <tr className="bg-gray-100">
                        <th className="px-4 py-2">Titel</th>
                        <th className="px-4 py-2">Autoren</th>
                        <th className="px-4 py-2">Journal</th>
                        <th className="px-4 py-2">Jahr</th>
                        <th className="px-4 py-2">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {results.map((result, index) => (
                        <tr key={index} className="border-b">
                            <td className="px-4 py-2">{result.title}</td>
                            <td className="px-4 py-2">{result.authors.join(', ')}</td>
                            <td className="px-4 py-2">{result.journal}</td>
                            <td className="px-4 py-2">{result.year}</td>
                            <td className="px-4 py-2">
                                {result.url && (
                                    <a 
                                        href={result.url}
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        className="text-blue-500 hover:underline"
                                    >
                                        View
                                    </a>
                                )}
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};
