import React from 'react';
import { DataVisualization } from './DataVisualization';
import { SearchResult } from '../types/api';

interface AnalysisViewProps {
    results: SearchResult[];
    analysisData: {
        yearDistribution: Record<string, number>;
        keyPhrases: string[];
        topAuthors: Record<string, number>;
    };
}

export const AnalysisView: React.FC<AnalysisViewProps> = ({
    results,
    analysisData
}) => {
    return (
        <div className="space-y-8">
            <div>
                <h2 className="text-xl font-bold mb-4">Ergebnisanalyse</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <DataVisualization
                        yearDistribution={analysisData.yearDistribution}
                        title="Publikationen nach Jahr"
                    />
                    <div>
                        <h3 className="text-lg font-semibold mb-2">Top Autoren</h3>
                        <ul className="space-y-2">
                            {Object.entries(analysisData.topAuthors)
                                .sort(([,a], [,b]) => b - a)
                                .slice(0, 10)
                                .map(([author, count]) => (
                                    <li key={author} className="flex justify-between">
                                        <span>{author}</span>
                                        <span className="font-mono">{count}</span>
                                    </li>
                                ))}
                        </ul>
                    </div>
                </div>
            </div>
            
            <div>
                <h3 className="text-lg font-semibold mb-2">Häufige Begriffe</h3>
                <div className="flex flex-wrap gap-2">
                    {analysisData.keyPhrases.slice(0, 20).map(phrase => (
                        <span
                            key={phrase}
                            className="px-3 py-1 bg-indigo-100 text-indigo-800 rounded-full text-sm"
                        >
                            {phrase}
                        </span>
                    ))}
                </div>
            </div>
        </div>
    );
};
