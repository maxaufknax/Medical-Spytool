import React, { useState } from 'react';
import { SearchParameters, SearchResponse } from '../types/api';
import { searchDatabase } from '../services/api';

export const SearchInterface: React.FC = () => {
    const [query, setQuery] = useState('');
    const [database, setDatabase] = useState('pubmed');
    const [loading, setLoading] = useState(false);
    const [results, setResults] = useState<SearchResponse | null>(null);

    const handleSearch = async () => {
        setLoading(true);
        try {
            const params: SearchParameters = {
                max_results: 100,
                field: 'Alle Felder'
            };
            const response = await searchDatabase(database, { query, parameters: params });
            setResults(response);
        } catch (error) {
            console.error('Search failed:', error);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="container mx-auto p-4">
            <div className="flex gap-4 mb-4">
                <select 
                    value={database}
                    onChange={(e) => setDatabase(e.target.value)}
                    className="rounded border p-2"
                >
                    <option value="pubmed">PubMed</option>
                    <option value="dnb">DNB</option>
                    <option value="wos">Web of Science</option>
                    <option value="scopus">Scopus</option>
                </select>
                <input
                    type="text"
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    placeholder="Suchbegriff eingeben..."
                    className="flex-1 rounded border p-2"
                />
                <button 
                    onClick={handleSearch}
                    disabled={loading}
                    className="bg-blue-500 text-white px-4 py-2 rounded"
                >
                    {loading ? 'Suche...' : 'Suchen'}
                </button>
            </div>
            
            {results && <ResultsTable results={results.results} />}
        </div>
    );
};
