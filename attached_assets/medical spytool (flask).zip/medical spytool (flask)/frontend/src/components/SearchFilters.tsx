import React from 'react';
import { SearchParameters } from '../types/api';

interface SearchFiltersProps {
    parameters: SearchParameters;
    onFilterChange: (params: Partial<SearchParameters>) => void;
}

export const SearchFilters: React.FC<SearchFiltersProps> = ({
    parameters,
    onFilterChange
}) => {
    return (
        <div className="space-y-4 p-4 bg-gray-50 rounded-lg">
            <h3 className="font-medium text-gray-900">Filter</h3>
            
            <div className="grid grid-cols-2 gap-4">
                {/* Zeitraum */}
                <div>
                    <label className="block text-sm font-medium text-gray-700">
                        Jahr von
                    </label>
                    <input
                        type="number"
                        min="1900"
                        max={new Date().getFullYear()}
                        value={parameters.year_from || ''}
                        onChange={(e) => onFilterChange({ year_from: e.target.value })}
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm"
                    />
                </div>
                
                <div>
                    <label className="block text-sm font-medium text-gray-700">
                        Jahr bis
                    </label>
                    <input
                        type="number"
                        min="1900"
                        max={new Date().getFullYear()}
                        value={parameters.year_to || ''}
                        onChange={(e) => onFilterChange({ year_to: e.target.value })}
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm"
                    />
                </div>

                {/* Sprache */}
                <div className="col-span-2">
                    <label className="block text-sm font-medium text-gray-700">
                        Sprache
                    </label>
                    <select
                        value={parameters.language || ''}
                        onChange={(e) => onFilterChange({ language: e.target.value })}
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm"
                    >
                        <option value="">Alle</option>
                        <option value="eng">Englisch</option>
                        <option value="ger">Deutsch</option>
                        <option value="fra">Französisch</option>
                    </select>
                </div>

                {/* Dokumenttyp */}
                <div className="col-span-2">
                    <label className="block text-sm font-medium text-gray-700">
                        Dokumenttyp
                    </label>
                    <select
                        value={parameters.publication_type || ''}
                        onChange={(e) => onFilterChange({ publication_type: e.target.value })}
                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm"
                    >
                        <option value="">Alle</option>
                        <option value="article">Artikel</option>
                        <option value="review">Review</option>
                        <option value="book">Buch</option>
                        <option value="conference">Konferenz</option>
                    </select>
                </div>
            </div>
        </div>
    );
};
