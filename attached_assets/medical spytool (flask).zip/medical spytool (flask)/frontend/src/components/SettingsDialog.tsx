import React from 'react';

interface SettingsDialogProps {
    isOpen: boolean;
    onClose: () => void;
    settings: {
        apiKeys: {
            pubmed?: string;
            wos?: string;
            scopus?: string;
        };
        maxResults: number;
        cacheTime: number;
    };
    onSave: (newSettings: any) => void;
}

export const SettingsDialog: React.FC<SettingsDialogProps> = ({
    isOpen,
    onClose,
    settings,
    onSave
}) => {
    const [formData, setFormData] = React.useState(settings);

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
            <div className="bg-white rounded-lg p-6 w-full max-w-2xl">
                <h2 className="text-xl font-bold mb-4">Einstellungen</h2>
                
                <div className="space-y-4">
                    <div>
                        <h3 className="font-medium mb-2">API-Schlüssel</h3>
                        <div className="space-y-2">
                            {['pubmed', 'wos', 'scopus'].map(db => (
                                <div key={db}>
                                    <label className="block text-sm font-medium text-gray-700">
                                        {db.toUpperCase()}
                                    </label>
                                    <input
                                        type="password"
                                        value={formData.apiKeys[db] || ''}
                                        onChange={e => setFormData({
                                            ...formData,
                                            apiKeys: {
                                                ...formData.apiKeys,
                                                [db]: e.target.value
                                            }
                                        })}
                                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm"
                                    />
                                </div>
                            ))}
                        </div>
                    </div>

                    <div>
                        <h3 className="font-medium mb-2">Sucheinstellungen</h3>
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label className="block text-sm font-medium text-gray-700">
                                    Max. Ergebnisse pro Suche
                                </label>
                                <input
                                    type="number"
                                    min="10"
                                    max="1000"
                                    value={formData.maxResults}
                                    onChange={e => setFormData({
                                        ...formData,
                                        maxResults: parseInt(e.target.value)
                                    })}
                                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm"
                                />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700">
                                    Cache-Dauer (Stunden)
                                </label>
                                <input
                                    type="number"
                                    min="1"
                                    max="72"
                                    value={formData.cacheTime}
                                    onChange={e => setFormData({
                                        ...formData,
                                        cacheTime: parseInt(e.target.value)
                                    })}
                                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm"
                                />
                            </div>
                        </div>
                    </div>
                </div>

                <div className="mt-6 flex justify-end space-x-3">
                    <button
                        onClick={onClose}
                        className="px-4 py-2 border rounded-md hover:bg-gray-50"
                    >
                        Abbrechen
                    </button>
                    <button
                        onClick={() => {
                            onSave(formData);
                            onClose();
                        }}
                        className="px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600"
                    >
                        Speichern
                    </button>
                </div>
            </div>
        </div>
    );
};
