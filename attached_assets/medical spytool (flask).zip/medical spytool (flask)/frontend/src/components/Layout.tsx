import React from 'react';
import { useSelector } from 'react-redux';
import { RootState } from '../store/store';
import { SearchInterface } from './SearchInterface';
import { SearchFilters } from './SearchFilters';
import { AdvancedSearch } from './AdvancedSearch';
import { SearchHistory } from './SearchHistory';
import { AnalysisView } from './AnalysisView';
import { ExportTools } from './ExportTools';

export const Layout: React.FC = () => {
    const { results, loading, error } = useSelector((state: RootState) => state.search);
    const [showAdvanced, setShowAdvanced] = React.useState(false);
    const [showAnalysis, setShowAnalysis] = React.useState(false);

    return (
        <div className="min-h-screen bg-gray-50">
            <nav className="bg-white shadow-sm">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="flex justify-between h-16">
                        <div className="flex">
                            <div className="flex-shrink-0 flex items-center">
                                <h1 className="text-xl font-bold text-gray-900">MedicalSpyTool</h1>
                            </div>
                        </div>
                        <div className="flex items-center">
                            <button
                                onClick={() => setShowAdvanced(!showAdvanced)}
                                className="px-3 py-2 text-sm font-medium text-gray-700 hover:text-gray-900"
                            >
                                {showAdvanced ? 'Einfache Suche' : 'Erweiterte Suche'}
                            </button>
                        </div>
                    </div>
                </div>
            </nav>

            <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
                <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
                    <div className="lg:col-span-3">
                        <SearchInterface />
                        {showAdvanced && <AdvancedSearch expanded={showAdvanced} onParametersChange={() => {}} />}
                        
                        {error && (
                            <div className="mt-4 bg-red-50 p-4 rounded-md">
                                <p className="text-red-700">{error}</p>
                            </div>
                        )}
                        
                        {loading ? (
                            <div className="mt-8 flex justify-center">
                                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900"></div>
                            </div>
                        ) : results.length > 0 && (
                            <div className="mt-8">
                                <ExportTools results={results} database="current" />
                                {showAnalysis && (
                                    <AnalysisView
                                        results={results}
                                        analysisData={{
                                            yearDistribution: {},
                                            keyPhrases: [],
                                            topAuthors: {}
                                        }}
                                    />
                                )}
                            </div>
                        )}
                    </div>
                    
                    <div className="lg:col-span-1">
                        <SearchFilters
                            parameters={{
                                max_results: 100,
                                field: 'Alle Felder'
                            }}
                            onFilterChange={() => {}}
                        />
                        <SearchHistory
                            history={[]}
                            onHistoryItemClick={() => {}}
                        />
                    </div>
                </div>
            </main>
        </div>
    );
};
