import { api } from './api';

interface LoginCredentials {
    username: string;
    password: string;
}

interface AuthResponse {
    access_token: string;
    token_type: string;
}

class AuthService {
    private tokenKey = 'medical_spy_token';

    async login(credentials: LoginCredentials): Promise<void> {
        const response = await api.post<AuthResponse>('/auth/login', credentials);
        this.setToken(response.data.access_token);
    }

    getToken(): string | null {
        return localStorage.getItem(this.tokenKey);
    }

    private setToken(token: string): void {
        localStorage.setItem(this.tokenKey, token);
        api.defaults.headers.common['Authorization'] = `Bearer ${token}`;
    }

    logout(): void {
        localStorage.removeItem(this.tokenKey);
        delete api.defaults.headers.common['Authorization'];
    }

    isAuthenticated(): boolean {
        return !!this.getToken();
    }
}

export const authService = new AuthService();
