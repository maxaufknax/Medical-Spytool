import axios from 'axios';
import { SearchRequest, SearchResponse } from '../types/api';

const API_BASE = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1';

export const api = axios.create({
    baseURL: API_BASE,
    headers: {
        'Content-Type': 'application/json',
    },
});

interface ApiError {
    code: string;
    message: string;
    details?: any;
}

// Add error interceptor
api.interceptors.response.use(
    (response) => response,
    (error) => {
        const apiError: ApiError = {
            code: 'UNKNOWN_ERROR',
            message: 'An unknown error occurred'
        };

        if (error.response) {
            apiError.code = error.response.data.code || 'API_ERROR';
            apiError.message = error.response.data.message || error.message;
            apiError.details = error.response.data.details;
        } else if (error.request) {
            apiError.code = 'NETWORK_ERROR';
            apiError.message = 'Network error occurred';
        }

        return Promise.reject(apiError);
    }
);

export const searchDatabase = async (
    database: string, 
    request: SearchRequest
): Promise<SearchResponse> => {
    const response = await api.post(`/search/${database}`, request);
    return response.data;
};

export const analyzeResults = async (results: any[]) => {
    const response = await api.post('/analysis/analyze', { results });
    return response.data;
};
