export interface SearchParameters {
    max_results: number;
    field: string;
    date_from?: string;
    date_to?: string;
    language?: string;
    publication_type?: string;
}

export interface SearchRequest {
    query: string;
    parameters: SearchParameters;
}

export interface SearchResponse {
    query: string;
    database: string;
    results: SearchResult[];
    total_results: number;
    timestamp: string;
}

export interface SearchResult {
    title: string;
    authors: string[];
    journal?: string;
    year: string;
    doi?: string;
    url?: string;
}
