// API base URL
const API_URL = 'http://localhost:8000/api/v1';

// Show selected tab content
function showTab(tabName) {
    // Hide all tab contents
    document.querySelectorAll('.tab-content').forEach(tab => {
        tab.classList.remove('active');
    });
    
    // Deactivate all tab buttons
    document.querySelectorAll('.tab-button').forEach(button => {
        button.classList.remove('active');
    });
    
    // Show selected tab content
    document.getElementById(tabName).classList.add('active');
    
    // Activate selected tab button
    document.querySelectorAll('.tab-button').forEach(button => {
        if (button.textContent.toLowerCase() === tabName) {
            button.classList.add('active');
        }
    });
}

// Perform search
async function performSearch() {
    const searchInput = document.getElementById('search-input').value;
    const resultsContainer = document.getElementById('search-results');
    
    if (!searchInput.trim()) {
        resultsContainer.innerHTML = '<p class="error">Please enter a search query</p>';
        return;
    }
    
    resultsContainer.innerHTML = '<p>Searching...</p>';
    
    try {
        const response = await fetch(`${API_URL}/search?query=${encodeURIComponent(searchInput)}`);
        const data = await response.json();
        
        if (response.ok) {
            displaySearchResults(data, resultsContainer);
        } else {
            resultsContainer.innerHTML = `<p class="error">Error: ${data.detail || 'Failed to perform search'}</p>`;
        }
    } catch (error) {
        resultsContainer.innerHTML = `<p class="error">Error: ${error.message}</p>`;
    }
}

// Display search results
function displaySearchResults(data, container) {
    if (!data || data.length === 0) {
        container.innerHTML = '<p>No results found</p>';
        return;
    }
    
    let html = '<div class="search-results">';
    data.forEach(item => {
        html += `
            <div class="result-item">
                <h3>${item.title || 'Untitled'}</h3>
                <p>${item.description || 'No description available'}</p>
            </div>
        `;
    });
    html += '</div>';
    
    container.innerHTML = html;
}

// Perform analysis
async function performAnalysis() {
    const analysisInput = document.getElementById('analysis-input').value;
    const resultsContainer = document.getElementById('analysis-results');
    
    if (!analysisInput.trim()) {
        resultsContainer.innerHTML = '<p class="error">Please enter text for analysis</p>';
        return;
    }
    
    resultsContainer.innerHTML = '<p>Analyzing...</p>';
    
    try {
        const response = await fetch(`${API_URL}/analysis`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ text: analysisInput })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            displayAnalysisResults(data, resultsContainer);
        } else {
            resultsContainer.innerHTML = `<p class="error">Error: ${data.detail || 'Failed to analyze text'}</p>`;
        }
    } catch (error) {
        resultsContainer.innerHTML = `<p class="error">Error: ${error.message}</p>`;
    }
}

// Display analysis results
function displayAnalysisResults(data, container) {
    if (!data) {
        container.innerHTML = '<p>No analysis results available</p>';
        return;
    }
    
    let html = '<div class="analysis-results">';
    
    if (data.entities && data.entities.length > 0) {
        html += '<h3>Entities</h3><ul>';
        data.entities.forEach(entity => {
            html += `<li>${entity.text} (${entity.type})</li>`;
        });
        html += '</ul>';
    }
    
    if (data.sentiment) {
        html += `<h3>Sentiment</h3><p>Score: ${data.sentiment.score.toFixed(2)}</p>`;
    }
    
    if (data.summary) {
        html += `<h3>Summary</h3><p>${data.summary}</p>`;
    }
    
    html += '</div>';
    container.innerHTML = html;
}

// Initialize the application
document.addEventListener('DOMContentLoaded', () => {
    // Show the search tab by default
    showTab('search');
});
