import sys
from PyQt6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, 
    QHBoxLayout, QPushButton, QLabel, QStatusBar, QLineEdit, QComboBox, 
    QTabWidget, QCheckBox, QTableWidget, QTableWidgetItem, QGroupBox, 
    QScrollArea, QSpinBox, QTextEdit, QRadioButton, QGridLayout, QButtonGroup, QMessageBox)
from PyQt6.QtCore import Qt, QThread
import requests
from search_worker import SearchWorker

class BaseSearchTab(QWidget):
    """Basis-Klasse für alle Suchtabs"""
    def __init__(self):
        super().__init__()
        self.layout = QVBoxLayout()
        self.search_worker = SearchWorker()
        self.search_worker.finished.connect(self.on_search_complete)
        self.search_worker.error.connect(self.on_search_error)
        self.setLayout(self.layout)
        
    def create_base_search_field(self):
        search_box = QHBoxLayout()
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("Suchbegriff eingeben...")
        self.search_button = QPushButton("Suchen")
        search_box.addWidget(self.search_input)
        search_box.addWidget(self.search_button)
        return search_box

    def on_search_complete(self, results):
        # Implementierung in den einzelnen Tab-Klassen
        pass
    
    def on_search_error(self, error_msg):
        QMessageBox.critical(self, "Fehler", f"Suchfehler: {error_msg}")

class GeprisSearchTab(BaseSearchTab):
    def __init__(self):
        super().__init__()
        
        # GEPRIS-spezifische Suchoptionen
        gepris_group = QGroupBox("GEPRIS-Suchoptionen")
        gepris_layout = QVBoxLayout()
        
        # Projekttypen
        project_group = QGroupBox("Projekttyp")
        project_layout = QVBoxLayout()
        self.dfg_projects = QCheckBox("DFG-Projekte")
        self.excellence_initiative = QCheckBox("Exzellenzinitiative")
        self.graduate_schools = QCheckBox("Graduiertenschulen")
        project_layout.addWidget(self.dfg_projects)
        project_layout.addWidget(self.excellence_initiative)
        project_layout.addWidget(self.graduate_schools)
        project_group.setLayout(project_layout)
        
        # Fachgebiete
        subject_group = QGroupBox("Fachgebiet")
        self.subject_combo = QComboBox()
        self.subject_combo.addItems([
            "Alle Fachgebiete",
            "Geistes- und Sozialwissenschaften",
            "Lebenswissenschaften",
            "Naturwissenschaften",
            "Ingenieurwissenschaften"
        ])
        subject_layout = QVBoxLayout()
        subject_layout.addWidget(self.subject_combo)
        subject_group.setLayout(subject_layout)
        
        gepris_layout.addLayout(self.create_base_search_field())
        gepris_layout.addWidget(project_group)
        gepris_layout.addWidget(subject_group)
        gepris_group.setLayout(gepris_layout)
        self.layout.addWidget(gepris_group)

class ScopusSearchTab(BaseSearchTab):
    def __init__(self):
        super().__init__()
        
        # Scopus-spezifische Suchoptionen
        scopus_group = QGroupBox("Scopus-Suchoptionen")
        scopus_layout = QVBoxLayout()
        
        # Dokumententypen
        doc_group = QGroupBox("Dokumententyp")
        doc_layout = QVBoxLayout()
        self.article = QCheckBox("Article")
        self.review = QCheckBox("Review")
        self.conference = QCheckBox("Conference Paper")
        doc_layout.addWidget(self.article)
        doc_layout.addWidget(self.review)
        doc_layout.addWidget(self.conference)
        doc_group.setLayout(doc_layout)
        
        # Zugänglichkeit
        access_group = QGroupBox("Zugänglichkeit")
        access_layout = QVBoxLayout()
        self.open_access = QCheckBox("Open Access")
        access_layout.addWidget(self.open_access)
        access_group.setLayout(access_layout)
        
        scopus_layout.addLayout(self.create_base_search_field())
        scopus_layout.addWidget(doc_group)
        scopus_layout.addWidget(access_group)
        scopus_group.setLayout(scopus_layout)
        self.layout.addWidget(scopus_group)

class DNBSearchTab(BaseSearchTab):
    def __init__(self):
        super().__init__()
        
        # DNB-spezifische Suchoptionen
        dnb_group = QGroupBox("DNB-Suchoptionen")
        dnb_layout = QVBoxLayout()
        
        # Medientyp
        media_group = QGroupBox("Medientyp")
        media_layout = QVBoxLayout()
        self.books = QCheckBox("Bücher")
        self.dissertations = QCheckBox("Hochschulschriften")
        self.articles = QCheckBox("Artikel")
        media_layout.addWidget(self.books)
        media_layout.addWidget(self.dissertations)
        media_layout.addWidget(self.articles)
        media_group.setLayout(media_layout)
        
        dnb_layout.addLayout(self.create_base_search_field())
        dnb_layout.addWidget(media_group)
        dnb_group.setLayout(dnb_layout)
        self.layout.addWidget(dnb_group)

class WebOfScienceSearchTab(BaseSearchTab):
    def __init__(self):
        super().__init__()
        
        # WoS-spezifische Suchoptionen
        wos_group = QGroupBox("Web of Science-Suchoptionen")
        wos_layout = QVBoxLayout()
        
        # Zitationsindizes
        citation_group = QGroupBox("Zitationsindizes")
        citation_layout = QVBoxLayout()
        self.sci = QCheckBox("Science Citation Index")
        self.ssci = QCheckBox("Social Sciences Citation Index")
        self.ahci = QCheckBox("Arts & Humanities Citation Index")
        citation_layout.addWidget(self.sci)
        citation_layout.addWidget(self.ssci)
        citation_layout.addWidget(self.ahci)
        citation_group.setLayout(citation_layout)
        
        wos_layout.addLayout(self.create_base_search_field())
        wos_layout.addWidget(citation_group)
        wos_group.setLayout(wos_layout)
        self.layout.addWidget(wos_group)

class GlobalSearchTab(BaseSearchTab):
    def __init__(self):
        super().__init__()
        
        # Globale Suchoptionen
        global_group = QGroupBox("Gesamtsuche über alle Datenbanken")
        global_layout = QVBoxLayout()
        
        # Datenbankenauswahl
        db_group = QGroupBox("Zu durchsuchende Datenbanken")
        db_layout = QGridLayout()
        self.db_pubmed = QCheckBox("PubMed")
        self.db_embase = QCheckBox("EMBASE")
        self.db_cochrane = QCheckBox("Cochrane")
        self.db_gepris = QCheckBox("GEPRIS")
        self.db_scopus = QCheckBox("Scopus")
        self.db_dnb = QCheckBox("DNB")
        self.db_wos = QCheckBox("Web of Science")
        
        db_layout.addWidget(self.db_pubmed, 0, 0)
        db_layout.addWidget(self.db_embase, 0, 1)
        db_layout.addWidget(self.db_cochrane, 0, 2)
        db_layout.addWidget(self.db_gepris, 1, 0)
        db_layout.addWidget(self.db_scopus, 1, 1)
        db_layout.addWidget(self.db_dnb, 1, 2)
        db_layout.addWidget(self.db_wos, 2, 0)
        db_group.setLayout(db_layout)
        
        # Gemeinsame Filter
        common_group = QGroupBox("Gemeinsame Filter")
        common_layout = QVBoxLayout()
        
        # Zeitraum
        date_layout = QHBoxLayout()
        self.date_from = QSpinBox()
        self.date_to = QSpinBox()
        date_layout.addWidget(QLabel("Zeitraum von:"))
        date_layout.addWidget(self.date_from)
        date_layout.addWidget(QLabel("bis:"))
        date_layout.addWidget(self.date_to)
        common_layout.addLayout(date_layout)
        
        # Sprache
        lang_layout = QHBoxLayout()
        self.language = QComboBox()
        self.language.addItems(["Alle Sprachen", "Deutsch", "Englisch"])
        lang_layout.addWidget(QLabel("Sprache:"))
        lang_layout.addWidget(self.language)
        common_layout.addLayout(lang_layout)
        
        common_group.setLayout(common_layout)
        
        global_layout.addLayout(self.create_base_search_field())
        global_layout.addWidget(db_group)
        global_layout.addWidget(common_group)
        global_group.setLayout(global_layout)
        self.layout.addWidget(global_group)

class SettingsTab(QWidget):
    def __init__(self):
        super().__init__()
        layout = QVBoxLayout()
        
        # API Settings
        api_group = QGroupBox("API-Einstellungen")
        api_layout = QVBoxLayout()
        
        # API Keys
        keys_box = QVBoxLayout()
        self.pubmed_key = QLineEdit()
        self.pubmed_key.setPlaceholderText("PubMed API Key")
        self.embase_key = QLineEdit()
        self.embase_key.setPlaceholderText("EMBASE API Key")
        keys_box.addWidget(QLabel("PubMed API Key:"))
        keys_box.addWidget(self.pubmed_key)
        keys_box.addWidget(QLabel("EMBASE API Key:"))
        keys_box.addWidget(self.embase_key)
        api_layout.addLayout(keys_box)
        
        api_group.setLayout(api_layout)
        layout.addWidget(api_group)
        
        # Display Settings
        display_group = QGroupBox("Anzeigeeinstellungen")
        display_layout = QVBoxLayout()
        
        # Results per page
        results_box = QHBoxLayout()
        self.results_per_page = QSpinBox()
        self.results_per_page.setRange(10, 100)
        self.results_per_page.setValue(20)
        results_box.addWidget(QLabel("Ergebnisse pro Seite:"))
        results_box.addWidget(self.results_per_page)
        display_layout.addLayout(results_box)
        
        display_group.setLayout(display_layout)
        layout.addWidget(display_group)
        
        # Save button
        save_button = QPushButton("Einstellungen speichern")
        layout.addWidget(save_button)
        
        layout.addStretch()
        self.setLayout(layout)

class MedicalSpytoolGUI(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Medical Spytool")
        self.setMinimumSize(1200, 800)
        
        # Create central widget and tabs
        self.tabs = QTabWidget()
        
        # Add all search tabs
        self.global_search_tab = GlobalSearchTab()
        self.gepris_tab = GeprisSearchTab()
        self.scopus_tab = ScopusSearchTab()
        self.dnb_tab = DNBSearchTab()
        self.wos_tab = WebOfScienceSearchTab()
        self.settings_tab = SettingsTab()
        
        self.tabs.addTab(self.global_search_tab, "Gesamtsuche")
        self.tabs.addTab(self.gepris_tab, "GEPRIS")
        self.tabs.addTab(self.scopus_tab, "Scopus")
        self.tabs.addTab(self.dnb_tab, "DNB")
        self.tabs.addTab(self.wos_tab, "Web of Science")
        self.tabs.addTab(self.settings_tab, "Einstellungen")
        
        self.setCentralWidget(self.tabs)
        
        # Add status bar
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)
        self.status_bar.showMessage("Bereit")
        
        self.init_exporters()

    def test_backend(self):
        try:
            response = requests.get('http://localhost:8000/health')
            if response.status_code == 200:
                self.status_bar.showMessage("Backend-Verbindung erfolgreich!")
            else:
                self.status_bar.showMessage("Backend-Fehler: " + response.text)
        except requests.exceptions.ConnectionError:
            self.status_bar.showMessage("Keine Verbindung zum Backend. Läuft der Server?")
    
    def init_exporters(self):
        from exporters import CSVExporter, BibtexExporter, ExcelExporter
        self.exporters = {
            'csv': CSVExporter(),
            'bibtex': BibtexExporter(),
            'excel': ExcelExporter()
        }
    
    def export_results(self, format_type: str, results: list, filepath: str):
        try:
            if format_type in self.exporters:
                self.exporters[format_type].export(results, filepath)
                self.status_bar.showMessage(f"Export als {format_type} erfolgreich")
            else:
                raise ValueError(f"Unbekanntes Export-Format: {format_type}")
        except Exception as e:
            QMessageBox.critical(self, "Export Fehler", str(e))

def main():
    app = QApplication(sys.argv)
    window = MedicalSpytoolGUI()
    window.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
