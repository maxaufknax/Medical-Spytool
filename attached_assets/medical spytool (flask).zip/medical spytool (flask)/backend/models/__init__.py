from .base import Base
from .search_result import SearchResult, GeprisResult, ScopusResult, DNBResult, WoSResult
