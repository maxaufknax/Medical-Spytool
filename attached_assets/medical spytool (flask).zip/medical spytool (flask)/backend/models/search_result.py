from sqlalchemy import Column, Integer, String, Date, ForeignKey, Text, Boolean, Float
from sqlalchemy.orm import relationship
from typing import Optional
from .base import Base

class SearchResult(Base):
    __tablename__ = "search_results"
    
    id = Column(Integer, primary_key=True)
    title = Column(String(500))
    authors = Column(String(500))
    year = Column(Integer)
    source = Column(String(100))
    abstract = Column(Text)
    url = Column(String(500))
    database = Column(String(50))

class GeprisResult(SearchResult):
    __tablename__ = "gepris_results"
    
    id = Column(Integer, ForeignKey('search_results.id'), primary_key=True)
    project_type = Column(String(100))
    funding = Column(String(100))
    institution = Column(String(200))
    subject_area = Column(String(100))

class ScopusResult(SearchResult):
    __tablename__ = "scopus_results"
    
    id = Column(Integer, ForeignKey('search_results.id'), primary_key=True)
    doi = Column(String(100))
    issn = Column(String(20))
    document_type = Column(String(50))
    citations = Column(Integer)
    open_access = Column(Boolean)

class DNBResult(SearchResult):
    __tablename__ = "dnb_results"
    
    id = Column(Integer, ForeignKey('search_results.id'), primary_key=True)
    isbn = Column(String(20))
    media_type = Column(String(50))
    publisher = Column(String(200))
    language = Column(String(50))

class WoSResult(SearchResult):
    __tablename__ = "wos_results"
    
    id = Column(Integer, ForeignKey('search_results.id'), primary_key=True)
    wos_id = Column(String(50))
    citation_index = Column(String(50))
    impact_factor = Column(Float)
    keywords = Column(String(500))
