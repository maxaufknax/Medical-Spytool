import pytest
from app.core.security import create_access_token, verify_password, get_password_hash
from app.models.user import User
from datetime import timedelta

@pytest.mark.asyncio
async def test_password_hashing():
    password = "testpassword123"
    hashed = get_password_hash(password)
    assert verify_password(password, hashed)
    assert not verify_password("wrongpassword", hashed)

@pytest.mark.asyncio
async def test_token_creation():
    data = {"sub": "testuser"}
    token = create_access_token(data, expires_delta=timedelta(minutes=30))
    assert isinstance(token, str)
    assert len(token) > 0
