import pytest
from app.database.connectors import PubMedConnector, DNBConnector, WoSConnector, ScopusConnector
from app.core.config import Settings

@pytest.fixture
def test_settings():
    return Settings(
        DATABASE_URL="sqlite+aiosqlite:///:memory:",
        REDIS_URL="redis://localhost",
        SECRET_KEY="test_secret",
        PUBMED_API_KEY="test_key"
    )

@pytest.mark.asyncio
async def test_pubmed_search(test_settings):
    connector = PubMedConnector(test_settings)
    results = await connector.search("cancer", {"max_results": 10})
    assert isinstance(results, list)
    assert len(results) <= 10
    
    if results:
        assert "title" in results[0]
        assert "authors" in results[0]
        assert "year" in results[0]
