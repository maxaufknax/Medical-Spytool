import pytest
from fastapi import HTTPException
from app.api.endpoints.search import search_database
from app.schemas.search import SearchRequest, SearchParameters
from app.models.user import User
from unittest.mock import AsyncMock, MagicMock

@pytest.fixture
def mock_user():
    return User(id=1, username="testuser", email="test@example.com")

@pytest.fixture
def mock_search_request():
    return SearchRequest(
        query="test",
        parameters=SearchParameters(
            max_results=10,
            field="Alle Felder"
        )
    )

@pytest.mark.asyncio
async def test_search_database_success(mock_user, mock_search_request):
    mock_connector = AsyncMock()
    mock_connector.search.return_value = [{"title": "Test"}]
    
    response = await search_database(
        database="pubmed",
        search_request=mock_search_request,
        current_user=mock_user,
        connector=mock_connector
    )
    
    assert response.total_results == 1
    assert response.database == "pubmed"
    mock_connector.search.assert_called_once()

@pytest.mark.asyncio
async def test_search_database_invalid_database(mock_user, mock_search_request):
    with pytest.raises(HTTPException) as exc:
        await search_database(
            database="invalid",
            search_request=mock_search_request,
            current_user=mock_user,
            connector=AsyncMock()
        )
    assert exc.value.status_code == 400
