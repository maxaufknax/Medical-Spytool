import pytest
from app.analysis.service import AnalysisService

@pytest.fixture
def analysis_service():
    return AnalysisService()

@pytest.fixture
def sample_results():
    return [
        {
            "title": "Test Article 1",
            "authors": ["Author A", "Author B"],
            "abstract": "This is a test abstract about medical research.",
            "year": "2023"
        },
        {
            "title": "Test Article 2",
            "authors": ["Author C", "Author A"],
            "abstract": "Another test abstract about clinical trials.",
            "year": "2022"
        }
    ]

@pytest.mark.asyncio
async def test_analyze_results(analysis_service, sample_results):
    results = await analysis_service.analyze_results(sample_results)
    
    assert "total_results" in results
    assert results["total_results"] == 2
    assert "year_distribution" in results
    assert "key_phrases" in results
    assert "top_authors" in results
    
    assert "Author A" in results["top_authors"]
    assert len(results["key_phrases"]) > 0
