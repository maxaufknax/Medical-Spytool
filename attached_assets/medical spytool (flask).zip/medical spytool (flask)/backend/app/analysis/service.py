from typing import List, Dict
import pandas as pd
import spacy
from sklearn.feature_extraction.text import TfidfVectorizer

class AnalysisService:
    def __init__(self):
        self.nlp = spacy.load("en_core_web_sm")
        self.vectorizer = TfidfVectorizer()
    
    async def analyze_results(self, results: List[Dict]) -> Dict:
        """Analyze search results using NLP and ML techniques."""
        try:
            # Convert results to DataFrame
            df = pd.DataFrame(results)
            
            # Perform text analysis
            text_corpus = df["abstract"].fillna("").tolist()
            tfidf_matrix = self.vectorizer.fit_transform(text_corpus)
            
            # Extract key phrases
            key_phrases = self._extract_key_phrases(text_corpus)
            
            # Generate summary statistics
            stats = {
                "total_results": len(results),
                "year_distribution": df["year"].value_counts().to_dict(),
                "key_phrases": key_phrases,
                "top_authors": self._get_top_authors(df)
            }
            
            return stats
        except Exception as e:
            raise ValueError(f"Analysis failed: {str(e)}")
    
    def _extract_key_phrases(self, texts: List[str]) -> List[str]:
        """Extract key phrases using spaCy."""
        key_phrases = []
        for text in texts:
            doc = self.nlp(text)
            phrases = [chunk.text for chunk in doc.noun_chunks]
            key_phrases.extend(phrases)
        return list(set(key_phrases))
    
    def _get_top_authors(self, df: pd.DataFrame, limit: int = 10) -> Dict:
        """Get most frequent authors."""
        authors = df["authors"].explode()
        return authors.value_counts().head(limit).to_dict()
