import json
from typing import Optional, Any
import aioredis
from ..core.config import settings

class CacheManager:
    def __init__(self):
        self.redis = aioredis.from_url(settings.REDIS_URL)
        self.default_ttl = 3600  # 1 hour

    async def get(self, key: str) -> Optional[Any]:
        """Get value from cache."""
        value = await self.redis.get(key)
        if value:
            return json.loads(value)
        return None

    async def set(self, key: str, value: Any, ttl: int = None) -> bool:
        """Set value in cache."""
        try:
            await self.redis.set(
                key,
                json.dumps(value),
                ex=ttl or self.default_ttl
            )
            return True
        except Exception:
            return False

    async def delete(self, key: str) -> bool:
        """Delete value from cache."""
        return await self.redis.delete(key) > 0

cache_manager = CacheManager()
