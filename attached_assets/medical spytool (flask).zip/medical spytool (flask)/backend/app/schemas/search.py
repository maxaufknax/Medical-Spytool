from pydantic import BaseModel
from typing import Dict, List, Optional
from datetime import datetime

class SearchParameters(BaseModel):
    max_results: int = 100
    field: str = "Alle Felder"
    date_from: Optional[datetime] = None
    date_to: Optional[datetime] = None
    language: Optional[str] = None
    publication_type: Optional[str] = None

class SearchRequest(BaseModel):
    query: str
    parameters: SearchParameters

class SearchResponse(BaseModel):
    query: str
    database: str
    results: List[Dict]
    total_results: int
    timestamp: datetime = datetime.now()
