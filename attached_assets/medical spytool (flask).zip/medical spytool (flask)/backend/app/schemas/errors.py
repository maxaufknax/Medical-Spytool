from pydantic import BaseModel
from typing import Optional, Any

class ErrorResponse(BaseModel):
    code: str
    message: str
    details: Optional[Any] = None

class DatabaseError(ErrorResponse):
    code: str = "DATABASE_ERROR"

class ValidationError(ErrorResponse):
    code: str = "VALIDATION_ERROR"

class AuthenticationError(ErrorResponse):
    code: str = "AUTH_ERROR"
