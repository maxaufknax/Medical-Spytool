from abc import ABC, abstractmethod
from typing import Dict, List, Optional
import aiohttp
from ..config import Settings

class DatabaseConnector(ABC):
    def __init__(self, settings: Settings):
        self.settings = settings
        self.base_url = ""
        self.api_key = ""
    
    @abstractmethod
    async def search(self, query: str, params: Dict) -> List[Dict]:
        pass
    
    @abstractmethod
    async def get_details(self, item_id: str) -> Optional[Dict]:
        pass

class PubMedConnector(DatabaseConnector):
    def __init__(self, settings: Settings):
        super().__init__(settings)
        self.base_url = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/"
        self.api_key = settings.pubmed_api_key

    async def search(self, query: str, params: Dict) -> List[Dict]:
        async with aiohttp.ClientSession() as session:
            try:
                # First get IDs
                search_params = {
                    "db": "pubmed",
                    "term": query,
                    "retmax": params.get("max_results", 100),
                    "retmode": "json",
                    "api_key": self.api_key
                }
                
                async with session.get(f"{self.base_url}esearch.fcgi", params=search_params) as response:
                    if response.status != 200:
                        raise ConnectionError(f"PubMed search failed: {response.status}")
                    
                    search_data = await response.json()
                    pmids = search_data.get("esearchresult", {}).get("idlist", [])
                    
                    if not pmids:
                        return []

                # Then get details
                fetch_params = {
                    "db": "pubmed",
                    "id": ",".join(pmids),
                    "retmode": "xml",
                    "api_key": self.api_key
                }
                
                async with session.get(f"{self.base_url}efetch.fcgi", params=fetch_params) as fetch_response:
                    return await self._parse_pubmed_response(await fetch_response.text())
                    
            except Exception as e:
                raise ConnectionError(f"PubMed search failed: {str(e)}")

    async def _parse_pubmed_response(self, xml_content: str) -> List[Dict]:
        from xml.etree import ElementTree as ET
        
        try:
            root = ET.fromstring(xml_content)
            results = []
            
            for article in root.findall(".//PubmedArticle"):
                result = {
                    "title": self._safe_find_text(article, ".//ArticleTitle"),
                    "authors": self._get_authors(article),
                    "journal": self._safe_find_text(article, ".//Journal/Title"),
                    "year": self._get_publication_year(article),
                    "pmid": self._safe_find_text(article, ".//PMID"),
                    "doi": self._get_doi(article),
                    "abstract": self._get_abstract(article)
                }
                results.append(result)
                
            return results
        except Exception as e:
            raise ValueError(f"Failed to parse PubMed response: {str(e)}")

    def _safe_find_text(self, element: ET.Element, xpath: str) -> str:
        """Safely extract text from XML element."""
        try:
            result = element.find(xpath)
            return result.text if result is not None else "N/A"
        except Exception:
            return "N/A"
    
    def _get_authors(self, article: ET.Element) -> List[str]:
        """Extract authors from article."""
        authors = []
        for author in article.findall(".//Author"):
            try:
                last_name = self._safe_find_text(author, "LastName")
                fore_name = self._safe_find_text(author, "ForeName")
                if last_name != "N/A":
                    authors.append(f"{last_name}, {fore_name}" if fore_name != "N/A" else last_name)
            except Exception:
                continue
        return authors

    def _get_publication_year(self, article: ET.Element) -> str:
        """Extract publication year."""
        try:
            year = self._safe_find_text(article, ".//PubDate/Year")
            if year != "N/A":
                return year
            
            medline_date = self._safe_find_text(article, ".//PubDate/MedlineDate")
            if medline_date != "N/A":
                # Extract first 4-digit number as year
                import re
                year_match = re.search(r'\d{4}', medline_date)
                if year_match:
                    return year_match.group(0)
            return "N/A"
        except Exception:
            return "N/A"

    def _get_doi(self, article: ET.Element) -> str:
        """Extract DOI from article."""
        try:
            for id_elem in article.findall(".//ArticleId"):
                if id_elem.get("IdType") == "doi":
                    return id_elem.text
            return "N/A"
        except Exception:
            return "N/A"

    def _get_abstract(self, article: ET.Element) -> str:
        """Extract abstract from article."""
        try:
            abstract_parts = []
            for abstract in article.findall(".//Abstract/AbstractText"):
                if abstract.text:
                    label = abstract.get("Label", "")
                    text = abstract.text.strip()
                    if label:
                        abstract_parts.append(f"{label}: {text}")
                    else:
                        abstract_parts.append(text)
            return " ".join(abstract_parts) if abstract_parts else "N/A"
        except Exception:
            return "N/A"

    async def _generate_dummy_results(self, query: str, params: Dict) -> List[Dict]:
        """Generate dummy results for testing."""
        import random
        from datetime import datetime
        
        count = min(params.get("max_results", 10), 20)
        current_year = datetime.now().year
        
        results = []
        for i in range(count):
            results.append({
                "title": f"Test Article {i+1} about {query}",
                "authors": ["Test Author 1", "Test Author 2"],
                "journal": "Test Journal",
                "year": str(random.randint(current_year-5, current_year)),
                "doi": f"10.1234/test-{i+1}",
                "url": f"https://example.com/{i+1}"
            })
        return results

    async def _construct_advanced_query(self, base_query: str, params: Dict) -> str:
        """Construct an advanced search query with filters."""
        query_parts = [base_query]
        
        # Add date range
        if params.get('date_from') or params.get('date_to'):
            date_from = params.get('date_from', '1900')
            date_to = params.get('date_to', datetime.now().year)
            query_parts.append(f"AND PUBYEAR BETWEEN {date_from} AND {date_to}")
        
        # Add language filter
        if params.get('language'):
            query_parts.append(f"AND LANGUAGE({params['language']})")
        
        # Add document type filter
        if params.get('publication_type'):
            query_parts.append(f"AND DOCTYPE({params['publication_type']})")
        
        return " ".join(query_parts)

    async def _handle_rate_limiting(self, response: aiohttp.ClientResponse) -> None:
        """Handle API rate limiting."""
        if response.status == 429:  # Too Many Requests
            retry_after = int(response.headers.get('Retry-After', 60))
            logger.warning(f"Rate limit hit, waiting {retry_after} seconds")
            await asyncio.sleep(retry_after)
            return True
        return False

class DNBConnector(DatabaseConnector):
    def __init__(self, settings: Settings):
        super().__init__(settings)
        self.base_url = "https://services.dnb.de/sru/dnb"
        
    async def search(self, query: str, params: Dict) -> List[Dict]:
        async with aiohttp.ClientSession() as session:
            try:
                query_params = {
                    "operation": "searchRetrieve",
                    "version": "1.1",
                    "recordSchema": "MARC21-xml",
                    "query": query,
                    "maximumRecords": params.get("max_results", 100)
                }
                async with session.get(self.base_url, params=query_params) as response:
                    return await self._parse_dnb_response(await response.text())
            except Exception as e:
                raise ConnectionError(f"DNB search failed: {str(e)}")

    async def get_details(self, item_id: str) -> Optional[Dict]:
        # DNB detail implementation
        pass

    async def _parse_dnb_response(self, xml_content: str) -> List[Dict]:
        # DNB response parsing implementation
        pass

class WoSConnector(DatabaseConnector):
    def __init__(self, settings: Settings):
        super().__init__(settings)
        self.base_url = "https://wos-api.clarivate.com/api/woslite"
        self.api_key = settings.wos_api_key

    async def search(self, query: str, params: Dict) -> List[Dict]:
        if not self.api_key:
            return await self._generate_dummy_results(query, params)
            
        headers = {"X-ApiKey": self.api_key}
        async with aiohttp.ClientSession() as session:
            try:
                search_data = {
                    "databaseId": "WOS",
                    "usrQuery": query,
                    "count": params.get("max_results", 100),
                    "firstRecord": 1
                }
                async with session.post(f"{self.base_url}/search", json=search_data, headers=headers) as response:
                    return await self._parse_wos_response(await response.json())
            except Exception as e:
                raise ConnectionError(f"WoS search failed: {str(e)}")

class ScopusConnector(DatabaseConnector):
    def __init__(self, settings: Settings):
        super().__init__(settings)
        self.base_url = "https://api.elsevier.com/content/search/scopus"
        self.api_key = settings.scopus_api_key

    async def search(self, query: str, params: Dict) -> List[Dict]:
        if not self.api_key:
            return await self._generate_dummy_results(query, params)
            
        headers = {
            "X-ELS-APIKey": self.api_key,
            "Accept": "application/json"
        }
        async with aiohttp.ClientSession() as session:
            try:
                query_params = {
                    "query": query,
                    "count": params.get("max_results", 100),
                    "start": 0,
                    "view": "COMPLETE"
                }
                async with session.get(self.base_url, params=query_params, headers=headers) as response:
                    return await self._parse_scopus_response(await response.json())
            except Exception as e:
                raise ConnectionError(f"Scopus search failed: {str(e)}")
