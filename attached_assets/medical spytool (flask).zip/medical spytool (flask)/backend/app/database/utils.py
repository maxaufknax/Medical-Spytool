from sqlalchemy.ext.asyncio import AsyncSession
from typing import Optional, List, Dict
from datetime import datetime
from ..models.user import User
from ..search.models import SearchQuery, SearchResult

async def log_search_query(
    session: AsyncSession,
    user_id: int,
    database: str,
    query: str,
    results_count: int,
    parameters: Optional[Dict] = None
) -> SearchQuery:
    """Log a search query to the database."""
    search_query = SearchQuery(
        user_id=user_id,
        database_id=database,
        query_text=query,
        parameters_json=parameters or {},
        created_at=datetime.utcnow()
    )
    
    session.add(search_query)
    await session.commit()
    return search_query

async def get_user_search_history(
    session: AsyncSession,
    user_id: int,
    limit: int = 10
) -> List[SearchQuery]:
    """Get user's recent search history."""
    query = select(SearchQuery)\
        .where(SearchQuery.user_id == user_id)\
        .order_by(SearchQuery.created_at.desc())\
        .limit(limit)
    
    result = await session.execute(query)
    return result.scalars().all()
