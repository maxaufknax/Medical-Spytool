from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from typing import List
from ...core.security import get_current_user, get_password_hash
from ...models.user import User
from ...schemas.user import UserCreate, UserUpdate, UserResponse
from ...database.utils import get_db

router = APIRouter()

@router.post("/users/", response_model=UserResponse)
async def create_user(
    user_in: UserCreate,
    session: AsyncSession = Depends(get_db)
):
    # Check if user exists
    existing_user = await session.execute(
        select(User).where(User.email == user_in.email)
    )
    if existing_user.scalar_one_or_none():
        raise HTTPException(
            status_code=400,
            detail="Email already registered"
        )
    
    # Create new user
    user = User(
        email=user_in.email,
        username=user_in.username,
        password_hash=get_password_hash(user_in.password),
    )
    session.add(user)
    await session.commit()
    
    return user

@router.get("/users/me", response_model=UserResponse)
async def get_current_user_info(
    current_user: User = Depends(get_current_user)
):
    return current_user

@router.put("/users/me", response_model=UserResponse)
async def update_user(
    user_update: UserUpdate,
    current_user: User = Depends(get_current_user),
    session: AsyncSession = Depends(get_db)
):
    for field, value in user_update.dict(exclude_unset=True).items():
        if field == "password":
            setattr(current_user, "password_hash", get_password_hash(value))
        else:
            setattr(current_user, field, value)
    
    await session.commit()
    return current_user
