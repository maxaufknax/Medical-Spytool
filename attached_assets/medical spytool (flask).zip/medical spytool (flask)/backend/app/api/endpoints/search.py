from fastapi import APIRouter, Depends, HTTPException
from typing import List, Optional
from ...database.connectors import DatabaseConnector
from ...schemas.search import SearchRequest, SearchResponse
from ...core.security import get_current_user
from ...models.user import User

router = APIRouter()

@router.post("/search/{database}", response_model=SearchResponse)
async def search_database(
    database: str,
    search_request: SearchRequest,
    current_user: User = Depends(get_current_user),
    connector: DatabaseConnector = Depends(get_database_connector)
) -> SearchResponse:
    cache_key = f"search:{database}:{search_request.query}:{hash(str(search_request.parameters))}"
    
    # Try to get from cache
    cached_results = await cache_manager.get(cache_key)
    if cached_results:
        return SearchResponse(
            query=search_request.query,
            database=database,
            results=cached_results,
            total_results=len(cached_results)
        )

    # Validate database parameter
    if database not in ["pubmed", "dnb", "wos", "scopus"]:
        raise HTTPException(
            status_code=400,
            detail=f"Unknown database: {database}"
        )
        
    try:
        results = await connector.search(
            query=search_request.query,
            params=search_request.parameters.dict()
        )
        
        # Cache results
        await cache_manager.set(cache_key, results)
        
        # Log search query
        await log_search_query(
            session=request.state.db,
            user_id=current_user.id,
            database=database,
            query=search_request.query,
            results_count=len(results)
        )
        
        return SearchResponse(
            query=search_request.query,
            database=database,
            results=results,
            total_results=len(results)
        )
    except ConnectionError as e:
        raise HTTPException(
            status_code=503,
            detail=f"Database connection failed: {str(e)}"
        )
    except ValueError as e:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid search parameters: {str(e)}"
        )
    except Exception as e:
        logger.exception("Unexpected error during search")
        raise HTTPException(
            status_code=500,
            detail="An unexpected error occurred"
        )

@router.get("/search/history", response_model=List[SearchHistoryResponse])
async def get_search_history(
    current_user: User = Depends(get_current_user),
    session: AsyncSession = Depends(get_db)
) -> List[SearchHistoryResponse]:
    """Get user's search history."""
    history = await get_user_search_history(session, current_user.id)
    return [
        SearchHistoryResponse(
            query=item.query_text,
            database=item.database_id,
            timestamp=item.created_at,
            results_count=item.results_count
        )
        for item in history
    ]
