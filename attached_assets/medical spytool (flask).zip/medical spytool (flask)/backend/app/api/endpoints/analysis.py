from fastapi import APIRouter, Depends, HTTPException
from typing import List
from ...analysis.service import AnalysisService
from ...schemas.analysis import AnalysisRequest, AnalysisResponse
from ...core.security import get_current_user
from ...models.user import User

router = APIRouter()
analysis_service = AnalysisService()

@router.post("/analyze", response_model=AnalysisResponse)
async def analyze_results(
    request: AnalysisRequest,
    current_user: User = Depends(get_current_user)
) -> AnalysisResponse:
    try:
        analysis_results = await analysis_service.analyze_results(request.results)
        return AnalysisResponse(
            analysis_id=str(uuid.uuid4()),
            results=analysis_results
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
