from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, JSON
from sqlalchemy.orm import relationship
from ..database import Base

class SearchQuery(Base):
    __tablename__ = "search_queries"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    database_id = Column(String)
    query_text = Column(String)
    parameters_json = Column(JSON)
    created_at = Column(DateTime(timezone=True))
    
    results = relationship("SearchResult", back_populates="query")

class SearchResult(Base):
    __tablename__ = "search_results"
    
    id = Column(Integer, primary_key=True, index=True)
    query_id = Column(Integer, ForeignKey("search_queries.id"))
    result_json = Column(JSON)
    timestamp = Column(DateTime(timezone=True))
    
    query = relationship("SearchQuery", back_populates="results")
