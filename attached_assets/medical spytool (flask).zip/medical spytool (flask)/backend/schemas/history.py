from datetime import datetime
from pydantic import BaseModel

class SearchHistoryResponse(BaseModel):
    id: int
    query: str
    database: str
    timestamp: datetime
    results_count: int
    user_id: int = None
    
    class Config:
        orm_mode = True
