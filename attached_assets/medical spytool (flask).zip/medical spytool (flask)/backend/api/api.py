from fastapi import APIRouter, HTTPException, Depends
from typing import Dict, List, Optional
from pydantic import BaseModel, ValidationError
from core.logging import logger

class SearchParams(BaseModel):
    query: str
    year_from: Optional[int] = None
    year_to: Optional[int] = None
    language: Optional[str] = None

class GlobalSearchParams(SearchParams):
    databases: List[str]

api_router = APIRouter()

@api_router.post("/search/gepris")
async def search_gepris(params: SearchParams):
    """GEPRIS-Suche"""
    return {"message": "GEPRIS search not yet implemented"}

@api_router.post("/search/scopus")
async def search_scopus(params: SearchParams):
    """Scopus-Suche"""
    return {"message": "Scopus search not yet implemented"}

@api_router.post("/search/dnb")
async def search_dnb(params: SearchParams):
    """DNB-Suche"""
    return {"message": "DNB search not yet implemented"}

@api_router.post("/search/wos")
async def search_wos(params: SearchParams):
    """Web of Science-Suche"""
    return {"message": "Web of Science search not yet implemented"}

@api_router.post("/search/global")
async def global_search(params: GlobalSearchParams):
    try:
        search_service = SearchService()
        results = await search_service.search_global(
            query=params.query,
            databases=params.databases,
            filters=params.dict(exclude={'query', 'databases'})
        )
        return results
    except Exception as e:
        logger.error(f"Global search error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/test", response_model=Dict[str, str])
async def test_endpoint():
    """
    Test endpoint to verify the API is working correctly.
    Returns a welcome message and basic instructions.
    """
    return {
        "message": "API router is working",
        "docs_url": "/docs",
        "redoc_url": "/redoc",
        "health_check": "/health"
    }
