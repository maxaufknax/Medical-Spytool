import uuid
from fastapi import APIRouter, Depends, HTTPException
