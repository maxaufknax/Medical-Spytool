import logging
from fastapi import APIRouter, Depends, HTTPException, Request, Query
from typing import Dict, List, Optional, Union, Any

from schemas.search import SearchParameters, SearchResponse
from schemas.history import SearchHistoryResponse
from database.connectors import (
    DatabaseConnector,
    PubMedConnector,
    DNBConnector,
    WoSConnector,
    ScopusConnector
)
from core.logging import logger
from models.search import SearchQuery
from sqlalchemy.ext.asyncio import AsyncSession

router = APIRouter()

def get_database_connector(database: str) -> DatabaseConnector:
    """Factory function to get the appropriate connector based on the database name."""
    connectors = {
        "pubmed": PubMedConnector(),
        "dnb": DNBConnector(),
        "wos": WoSConnector(),
        "scopus": ScopusConnector(),
    }
    
    connector = connectors.get(database.lower())
    if not connector:
        raise HTTPException(status_code=400, detail=f"Unsupported database: {database}")
    
    return connector

async def log_search_query(
    request: Request,
    query: str,
    database: str,
    results_count: int
) -> SearchHistoryResponse:
    """Log the search query to the database."""
    db = request.state.db
    user_id = getattr(request.state, "user_id", None)
    
    search_query = SearchQuery(
        query=query,
        database=database,
        results_count=results_count,
        user_id=user_id
    )
    
    db.add(search_query)
    await db.commit()
    await db.refresh(search_query)
    
    return SearchHistoryResponse(
        id=search_query.id,
        query=search_query.query,
        database=search_query.database,
        timestamp=search_query.timestamp,
        results_count=search_query.results_count,
        user_id=search_query.user_id
    )

@router.post("/search/", response_model=SearchResponse)
async def search(
    request: Request,
    search_params: SearchParameters,
    connector: DatabaseConnector = Depends(get_database_connector)
) -> SearchResponse:
    """
    Search the specified database using the provided query parameters.
    """
    try:
        logger.info(f"Processing search request for database: {search_params.database}")
        
        results = await connector.search(
            search_params.query,
            params=search_params.dict(exclude={"query", "database"})
        )
        
        # Log the search query to the database
        await log_search_query(
            request,
            search_params.query,
            search_params.database,
            len(results)
        )
        
        return SearchResponse(results=results)
    
    except Exception as e:
        logger.error(f"Search error: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Search error: {str(e)}")
