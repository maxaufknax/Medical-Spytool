from starlette.middleware.base import BaseHTTPMiddleware
from fastapi import Request

class DBSessionMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        # We'll add database session handling later
        return await call_next(request)
