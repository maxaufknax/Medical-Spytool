import logging
import sys
from typing import Any, Dict, Optional

def setup_logger(
    name: str = "medical_spytool",
    level: int = logging.INFO,
    format_string: Optional[str] = None
) -> logging.Logger:
    """Configure and return a logger with the given name and level."""
    logger = logging.getLogger(name)
    logger.setLevel(level)
    
    handler = logging.StreamHandler()
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    
    return logger

# Default application logger
logger = setup_logger()
