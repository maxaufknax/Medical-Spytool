import os
import subprocess
import shutil
import sys
from pathlib import Path

def build_executable():
    print("Building Medical SpyTool Executable...")
    
    # Create build directory
    build_dir = Path("./build")
    dist_dir = Path("./dist")
    
    if build_dir.exists():
        shutil.rmtree(build_dir)
    if dist_dir.exists():
        shutil.rmtree(dist_dir)
    
    build_dir.mkdir(exist_ok=True)
    
    # Install required packages
    print("Installing required packages...")
    subprocess.run([sys.executable, "-m", "pip", "install", "pyinstaller", "fastapi", "uvicorn", "eel"], check=True)
    
    # Create a launcher script that combines the backend and frontend
    with open("./launcher.py", "w") as f:
        f.write("""
import os
import sys
import threading
import webbrowser
import time
import uvicorn
from app.main import app

def start_server():
    uvicorn.run(app, host="localhost", port=8000)

if __name__ == "__main__":
    # Start the FastAPI server in a separate thread
    server_thread = threading.Thread(target=start_server, daemon=True)
    server_thread.start()
    
    # Give the server some time to start
    time.sleep(2)
    
    # Open the web browser
    webbrowser.open("http://localhost:8000")
    
    # Keep the main thread alive
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        sys.exit(0)
""")
    
    # Copy frontend files to a directory that will be included in the executable
    frontend_dir = Path("./static")
    if frontend_dir.exists():
        shutil.rmtree(frontend_dir)
    
    frontend_dir.mkdir(exist_ok=True)
    shutil.copytree("./frontend", "./static/frontend")
    
    # Build the executable with PyInstaller
    print("Building executable with PyInstaller...")
    subprocess.run([
        sys.executable, 
        "-m", 
        "pyinstaller",
        "--name=MedicalSpyTool",
        "--onefile",
        "--windowed",
        "--icon=frontend/favicon.ico" if os.path.exists("frontend/favicon.ico") else "",
        "--add-data=static;static",
        "launcher.py"
    ], check=True)
    
    print("Build complete! Executable is in the 'dist' directory.")

if __name__ == "__main__":
    build_executable()
