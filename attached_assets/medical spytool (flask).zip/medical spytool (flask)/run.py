import subprocess
import sys
import time
import webbrowser
from pathlib import Path

def start_backend():
    print("Starting backend server...")
    backend_process = subprocess.Popen(
        [sys.executable, "backend/main.py"],
        cwd=Path(__file__).parent
    )
    time.sleep(2)  # Wait for backend to start
    return backend_process

def start_frontend():
    print("Starting frontend application...")
    frontend_process = subprocess.Popen(
        [sys.executable, "frontend/main.py"],
        cwd=Path(__file__).parent
    )
    return frontend_process

if __name__ == "__main__":
    backend_proc = start_backend()
    frontend_proc = start_frontend()
    
    try:
        frontend_proc.wait()
    finally:
        backend_proc.terminate()
        backend_proc.wait()
