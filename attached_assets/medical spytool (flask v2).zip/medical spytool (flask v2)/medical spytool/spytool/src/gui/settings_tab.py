"""SettingsTab für die Konfiguration der Anwendung"""
import tkinter as tk
from tkinter import ttk, filedialog
import os

from core.config_manager import ConfigManager
from core.logger import Logger
from core.database_service import DatabaseService

class SettingsTab(ttk.Frame):
    def __init__(self, parent, config_manager: ConfigManager, logger: Logger, database_service: DatabaseService):
        super().__init__(parent)
        self.config_manager = config_manager
        self.logger = logger
        self.database_service = database_service
        
        self._create_widgets()
        self._load_settings()
        
    def _create_widgets(self):
        """Erstellt die GUI-Elemente"""
        # API Keys Section
        api_frame = ttk.LabelFrame(self, text="API Keys")
        api_frame.pack(fill=tk.X, padx=10, pady=5)
        
        # PubMed
        ttk.Label(api_frame, text="PubMed API Key:").grid(row=0, column=0, padx=5, pady=5, sticky=tk.W)
        self.pubmed_key = ttk.Entry(api_frame, width=50)
        self.pubmed_key.grid(row=0, column=1, padx=5, pady=5)
        
        # DNB
        ttk.Label(api_frame, text="DNB Access Token:").grid(row=1, column=0, padx=5, pady=5, sticky=tk.W)
        self.dnb_key = ttk.Entry(api_frame, width=50)
        self.dnb_key.grid(row=1, column=1, padx=5, pady=5)
        
        # Web of Science
        ttk.Label(api_frame, text="Web of Science API Key:").grid(row=2, column=0, padx=5, pady=5, sticky=tk.W)
        self.wos_key = ttk.Entry(api_frame, width=50)
        self.wos_key.grid(row=2, column=1, padx=5, pady=5)
        
        # Scopus
        ttk.Label(api_frame, text="Scopus API Key:").grid(row=3, column=0, padx=5, pady=5, sticky=tk.W)
        self.scopus_key = ttk.Entry(api_frame, width=50)
        self.scopus_key.grid(row=3, column=1, padx=5, pady=5)
        
        # Sucheinstellungen
        search_frame = ttk.LabelFrame(self, text="Sucheinstellungen")
        search_frame.pack(fill=tk.X, padx=10, pady=5)
        
        ttk.Label(search_frame, text="Max. Ergebnisse pro Datenbank:").grid(row=0, column=0, padx=5, pady=5, sticky=tk.W)
        self.max_results = ttk.Entry(search_frame, width=10)
        self.max_results.grid(row=0, column=1, padx=5, pady=5, sticky=tk.W)
        
        ttk.Label(search_frame, text="Timeout (Sekunden):").grid(row=1, column=0, padx=5, pady=5, sticky=tk.W)
        self.timeout = ttk.Entry(search_frame, width=10)
        self.timeout.grid(row=1, column=1, padx=5, pady=5, sticky=tk.W)
        
        # Export-Einstellungen
        export_frame = ttk.LabelFrame(self, text="Export-Einstellungen")
        export_frame.pack(fill=tk.X, padx=10, pady=5)
        
        ttk.Label(export_frame, text="Standard-Format:").grid(row=0, column=0, padx=5, pady=5, sticky=tk.W)
        self.export_format = ttk.Combobox(export_frame, values=["csv", "xlsx"], width=10)
        self.export_format.grid(row=0, column=1, padx=5, pady=5, sticky=tk.W)
        
        ttk.Label(export_frame, text="Export-Pfad:").grid(row=1, column=0, padx=5, pady=5, sticky=tk.W)
        self.export_path = ttk.Entry(export_frame, width=50)
        self.export_path.grid(row=1, column=1, padx=5, pady=5)
        ttk.Button(export_frame, text="...", width=3, command=self._select_export_path).grid(row=1, column=2, padx=5, pady=5)
        
        # Speichern-Button
        ttk.Button(self, text="Einstellungen speichern", command=self._save_settings).pack(pady=20)
        
    def _load_settings(self):
        """Lädt die aktuellen Einstellungen"""
        config = self.config_manager.get_config()
        
        # API Keys
        api_keys = config.get("api_keys", {})
        self.pubmed_key.insert(0, api_keys.get("pubmed", ""))
        self.dnb_key.insert(0, api_keys.get("dnb", ""))
        self.wos_key.insert(0, api_keys.get("wos", ""))
        self.scopus_key.insert(0, api_keys.get("scopus", ""))
        
        # Sucheinstellungen
        search_settings = config.get("search_settings", {})
        self.max_results.insert(0, str(search_settings.get("max_results", 100)))
        self.timeout.insert(0, str(search_settings.get("timeout", 30)))
        
        # Export-Einstellungen
        export_settings = config.get("export_settings", {})
        self.export_format.set(export_settings.get("default_format", "csv"))
        self.export_path.insert(0, export_settings.get("export_path", os.path.expanduser("~/Downloads")))
        
    def _save_settings(self):
        """Speichert die aktuellen Einstellungen"""
        try:
            config = {
                "api_keys": {
                    "pubmed": self.pubmed_key.get(),
                    "dnb": self.dnb_key.get(),
                    "wos": self.wos_key.get(),
                    "scopus": self.scopus_key.get()
                },
                "search_settings": {
                    "max_results": int(self.max_results.get()),
                    "timeout": int(self.timeout.get())
                },
                "export_settings": {
                    "default_format": self.export_format.get(),
                    "export_path": self.export_path.get()
                }
            }
            
            self.config_manager.update_config(config)
            self.logger.info("Einstellungen wurden erfolgreich gespeichert")
            
        except ValueError as e:
            self.logger.error(f"Fehler beim Speichern der Einstellungen: {e}")
        
    def _select_export_path(self):
        """Öffnet einen Dialog zur Auswahl des Export-Pfads"""
        path = filedialog.askdirectory(
            initialdir=self.export_path.get(),
            title="Export-Pfad auswählen"
        )
        
        if path:
            self.export_path.delete(0, tk.END)
            self.export_path.insert(0, path)