"""ResultsTab für die Anzeige und Verwaltung von Suchergebnissen"""
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from typing import Dict, List
import pandas as pd
import os
from datetime import datetime
from core.config_manager import ConfigManager
from core.logger import Logger

class ResultsTab(ttk.Frame):
    def __init__(self, parent, config_manager: ConfigManager, logger: Logger):
        super().__init__(parent)
        self.config_manager = config_manager
        self.logger = logger
        self.results = []  # Speichert die aktuellen Suchergebnisse
        
        self._create_widgets()
        
    def _create_widgets(self):
        """Erstellt die GUI-Elemente"""
        # Toolbar für Aktionen
        toolbar = ttk.Frame(self)
        toolbar.pack(fill=tk.X, padx=5, pady=5)
        
        # Exportieren-Button mit Dropdown-Menü
        export_frame = ttk.Frame(toolbar)
        export_frame.pack(side=tk.LEFT, padx=5)
        
        ttk.Button(export_frame, text="Exportieren als Excel", 
                  command=lambda: self.export_results("xlsx")).pack(side=tk.LEFT, padx=2)
        ttk.Button(export_frame, text="Exportieren als CSV", 
                  command=lambda: self.export_results("csv")).pack(side=tk.LEFT, padx=2)
        
        # Weitere Aktionsbuttons
        ttk.Button(toolbar, text="Auswahl löschen", command=self._delete_selected).pack(side=tk.LEFT, padx=5)
        ttk.Button(toolbar, text="Alles löschen", command=self._clear_results).pack(side=tk.LEFT, padx=5)
        
        # Suchfeld zur Filterung der Ergebnisse
        filter_frame = ttk.Frame(toolbar)
        filter_frame.pack(side=tk.RIGHT, padx=5)
        
        ttk.Label(filter_frame, text="Filter:").pack(side=tk.LEFT)
        self.filter_entry = ttk.Entry(filter_frame, width=20)
        self.filter_entry.pack(side=tk.LEFT, padx=5)
        self.filter_entry.bind("<KeyRelease>", self._filter_results)
        
        ttk.Button(filter_frame, text="X", width=2, 
                  command=self._clear_filter).pack(side=tk.LEFT)
        
        # Status-Leiste
        self.status_var = tk.StringVar()
        self.status_var.set("0 Ergebnisse")
        status_bar = ttk.Label(toolbar, textvariable=self.status_var, anchor=tk.W)
        status_bar.pack(side=tk.RIGHT, padx=10)
        
        # Ergebnistabelle
        table_frame = ttk.Frame(self)
        table_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Erstelle Treeview mit Scrollbars
        self.result_tree = ttk.Treeview(
            table_frame, 
            columns=("title", "authors", "year", "journal", "source", "doi"),
            show="headings",
            selectmode="extended"
        )
        
        # Scrollbars
        vsb = ttk.Scrollbar(table_frame, orient="vertical", command=self.result_tree.yview)
        hsb = ttk.Scrollbar(table_frame, orient="horizontal", command=self.result_tree.xview)
        self.result_tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        
        # Layout der Scrollbars
        self.result_tree.grid(column=0, row=0, sticky="nsew")
        vsb.grid(column=1, row=0, sticky="ns")
        hsb.grid(column=0, row=1, sticky="ew")
        
        # Konfiguriere Tabellenrahmen zum Expandieren
        table_frame.columnconfigure(0, weight=1)
        table_frame.rowconfigure(0, weight=1)
        
        # Spaltenüberschriften
        self.result_tree.heading("title", text="Titel", command=lambda: self._sort_by_column("title"))
        self.result_tree.heading("authors", text="Autoren", command=lambda: self._sort_by_column("authors"))
        self.result_tree.heading("year", text="Jahr", command=lambda: self._sort_by_column("year"))
        self.result_tree.heading("journal", text="Journal", command=lambda: self._sort_by_column("journal"))
        self.result_tree.heading("source", text="Quelle", command=lambda: self._sort_by_column("source"))
        self.result_tree.heading("doi", text="DOI", command=lambda: self._sort_by_column("doi"))
        
        # Spaltenbreiten
        self.result_tree.column("title", width=300, minwidth=150)
        self.result_tree.column("authors", width=200, minwidth=100)
        self.result_tree.column("year", width=60, minwidth=40)
        self.result_tree.column("journal", width=150, minwidth=80)
        self.result_tree.column("source", width=80, minwidth=60)
        self.result_tree.column("doi", width=150, minwidth=80)
        
        # Kontextmenü
        self._setup_context_menu()
        
        # Doppelklick zum Anzeigen von Details
        self.result_tree.bind("<Double-1>", self._show_item_details)
        
    def _setup_context_menu(self):
        """Richtet das Kontextmenü für die Tabelle ein"""
        self.context_menu = tk.Menu(self, tearoff=0)
        self.context_menu.add_command(label="Details anzeigen", command=self._show_selected_details)
        self.context_menu.add_command(label="Auswahl kopieren", command=self._copy_selected)
        self.context_menu.add_separator()
        self.context_menu.add_command(label="Auswahl löschen", command=self._delete_selected)
        
        # Rechtsklick-Bindung
        self.result_tree.bind("<Button-3>", self._show_context_menu)
        
    def _show_context_menu(self, event):
        """Zeigt das Kontextmenü an der Position des Mausklicks an"""
        try:
            self.context_menu.tk_popup(event.x_root, event.y_root)
        finally:
            # Stellt sicher, dass das Menü geschlossen wird
            self.context_menu.grab_release()
            
    def _sort_by_column(self, column):
        """Sortiert die Tabelle nach einer Spalte"""
        # Aktuelle Elemente abrufen
        items = [(self.result_tree.set(k, column), k) for k in self.result_tree.get_children('')]
        
        # Sortieren
        items.sort(reverse=self.result_tree.heading(column).get("sortorder") == "descending")
        
        # Sortierreihenfolge umkehren für den nächsten Klick
        new_order = "descending" if self.result_tree.heading(column).get("sortorder") != "descending" else "ascending"
        self.result_tree.heading(column, sortorder=new_order)
        
        # Elemente in der sortierten Reihenfolge neu einfügen
        for index, (_, k) in enumerate(items):
            self.result_tree.move(k, '', index)
        
    def add_results(self, results: List[Dict]):
        """Fügt neue Suchergebnisse hinzu"""
        self.results.extend(results)
        self._update_display()
        
    def _clear_filter(self):
        """Leert das Filterfeld und zeigt alle Ergebnisse an"""
        self.filter_entry.delete(0, tk.END)
        self._update_display()
        
    def _filter_results(self, event=None):
        """Filtert die Ergebnisse basierend auf dem Filtertext"""
        self._update_display()
        
    def _update_display(self):
        """Aktualisiert die Anzeige der Ergebnisse"""
        # Lösche alte Einträge
        for item in self.result_tree.get_children():
            self.result_tree.delete(item)
            
        # Hole den Filtertext
        filter_text = self.filter_entry.get().lower()
        
        # Zähle gefilterte Ergebnisse
        filtered_count = 0
        
        # Füge gefilterte Einträge hinzu
        for result in self.results:
            # Prüfe, ob der Filtertext in einem der Felder enthalten ist
            if filter_text and not any(
                filter_text in str(value).lower()
                for value in result.values()
                if isinstance(value, (str, int, float))
            ):
                continue
            
            # Bereite Autorenliste vor
            authors = ", ".join(result.get("authors", []))
            
            # Füge Eintrag hinzu
            self.result_tree.insert("", tk.END, values=(
                result.get("title", ""),
                authors[:200] + "..." if len(authors) > 200 else authors,
                result.get("year", ""),
                result.get("journal", ""),
                result.get("source", ""),
                result.get("doi", "")
            ))
            
            filtered_count += 1
            
        # Aktualisiere Statuszeile
        total = len(self.results)
        if filtered_count < total:
            self.status_var.set(f"{filtered_count} von {total} Ergebnissen angezeigt")
        else:
            self.status_var.set(f"{total} Ergebnisse")
            
    def _delete_selected(self):
        """Löscht die ausgewählten Einträge"""
        selected = self.result_tree.selection()
        if not selected:
            return
            
        # Entferne ausgewählte Einträge
        indices = []
        for item in selected:
            idx = self.result_tree.index(item)
            indices.append(idx)
            
        # Lösche von hinten nach vorne, um Indexverschiebungen zu vermeiden
        for idx in sorted(indices, reverse=True):
            del self.results[idx]
            
        self._update_display()
        
    def _clear_results(self):
        """Löscht alle Ergebnisse"""
        if not self.results:
            return
            
        if messagebox.askyesno("Bestätigen", "Möchten Sie wirklich alle Ergebnisse löschen?"):
            self.results = []
            self._update_display()
            
    def _show_selected_details(self):
        """Zeigt Details für den ausgewählten Eintrag an"""
        selected = self.result_tree.selection()
        if selected:
            item = selected[0]  # Nimm den ersten ausgewählten Eintrag
            idx = self.result_tree.index(item)
            self._show_details(idx)
            
    def _show_item_details(self, event):
        """Zeigt Details für den Eintrag an, der doppelt geklickt wurde"""
        item = self.result_tree.identify_row(event.y)
        if item:
            idx = self.result_tree.index(item)
            self._show_details(idx)
            
    def _show_details(self, idx):
        """Zeigt Details für einen Eintrag an"""
        if idx >= len(self.results):
            return
            
        result = self.results[idx]
        
        # Erstelle ein Popup-Fenster
        details_window = tk.Toplevel(self)
        details_window.title("Publikationsdetails")
        details_window.geometry("700x500")
        
        # Inhalt
        main_frame = ttk.Frame(details_window, padding=10)
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Titel
        ttk.Label(main_frame, text="Titel:", font=("Helvetica", 10, "bold")).grid(
            row=0, column=0, sticky=tk.W, padx=5, pady=2
        )
        title_text = tk.Text(main_frame, wrap=tk.WORD, height=3)
        title_text.grid(row=0, column=1, sticky=tk.W+tk.E, padx=5, pady=2)
        title_text.insert(tk.END, result.get("title", ""))
        title_text.config(state=tk.DISABLED)
        
        # Autoren
        ttk.Label(main_frame, text="Autoren:", font=("Helvetica", 10, "bold")).grid(
            row=1, column=0, sticky=tk.W, padx=5, pady=2
        )
        authors_text = tk.Text(main_frame, wrap=tk.WORD, height=2)
        authors_text.grid(row=1, column=1, sticky=tk.W+tk.E, padx=5, pady=2)
        authors_text.insert(tk.END, ", ".join(result.get("authors", [])))
        authors_text.config(state=tk.DISABLED)
        
        # Journal/Quelle
        ttk.Label(main_frame, text="Journal:", font=("Helvetica", 10, "bold")).grid(
            row=2, column=0, sticky=tk.W, padx=5, pady=2
        )
        journal_text = ttk.Entry(main_frame)
        journal_text.grid(row=2, column=1, sticky=tk.W+tk.E, padx=5, pady=2)
        journal_text.insert(0, result.get("journal", ""))
        journal_text.config(state=tk.DISABLED)
        
        # Jahr
        ttk.Label(main_frame, text="Jahr:", font=("Helvetica", 10, "bold")).grid(
            row=3, column=0, sticky=tk.W, padx=5, pady=2
        )
        year_text = ttk.Entry(main_frame, width=10)
        year_text.grid(row=3, column=1, sticky=tk.W, padx=5, pady=2)
        year_text.insert(0, result.get("year", ""))
        year_text.config(state=tk.DISABLED)
        
        # DOI
        ttk.Label(main_frame, text="DOI:", font=("Helvetica", 10, "bold")).grid(
            row=4, column=0, sticky=tk.W, padx=5, pady=2
        )
        doi_text = ttk.Entry(main_frame)
        doi_text.grid(row=4, column=1, sticky=tk.W+tk.E, padx=5, pady=2)
        doi_text.insert(0, result.get("doi", ""))
        doi_text.config(state=tk.DISABLED)
        
        # Quelle
        ttk.Label(main_frame, text="Datenbank:", font=("Helvetica", 10, "bold")).grid(
            row=5, column=0, sticky=tk.W, padx=5, pady=2
        )
        source_text = ttk.Entry(main_frame, width=15)
        source_text.grid(row=5, column=1, sticky=tk.W, padx=5, pady=2)
        source_text.insert(0, result.get("source", "").upper())
        source_text.config(state=tk.DISABLED)
        
        # Abstract
        ttk.Label(main_frame, text="Abstract:", font=("Helvetica", 10, "bold")).grid(
            row=6, column=0, sticky=tk.NW, padx=5, pady=2
        )
        abstract_text = tk.Text(main_frame, wrap=tk.WORD, height=10)
        abstract_text.grid(row=6, column=1, sticky=tk.W+tk.E+tk.N+tk.S, padx=5, pady=2)
        abstract_text.insert(tk.END, result.get("abstract", "Kein Abstract verfügbar"))
        abstract_text.config(state=tk.DISABLED)
        
        # Scrollbar für Abstract
        abstract_scroll = ttk.Scrollbar(main_frame, command=abstract_text.yview)
        abstract_scroll.grid(row=6, column=2, sticky=tk.NS)
        abstract_text.configure(yscrollcommand=abstract_scroll.set)
        
        # Weitere Metadaten je nach Datenbank
        if "isbn" in result:
            ttk.Label(main_frame, text="ISBN:", font=("Helvetica", 10, "bold")).grid(
                row=7, column=0, sticky=tk.W, padx=5, pady=2
            )
            isbn_text = ttk.Entry(main_frame)
            isbn_text.grid(row=7, column=1, sticky=tk.W, padx=5, pady=2)
            isbn_text.insert(0, result.get("isbn", ""))
            isbn_text.config(state=tk.DISABLED)
        
        if "citations" in result:
            ttk.Label(main_frame, text="Zitierungen:", font=("Helvetica", 10, "bold")).grid(
                row=8, column=0, sticky=tk.W, padx=5, pady=2
            )
            citations_text = ttk.Entry(main_frame, width=10)
            citations_text.grid(row=8, column=1, sticky=tk.W, padx=5, pady=2)
            citations_text.insert(0, str(result.get("citations", 0)))
            citations_text.config(state=tk.DISABLED)
        
        # Expandiere Grid für Scrollbars
        main_frame.columnconfigure(1, weight=1)
        main_frame.rowconfigure(6, weight=1)
        
        # Buttons
        button_frame = ttk.Frame(details_window)
        button_frame.pack(fill=tk.X, padx=10, pady=10)
        
        ttk.Button(button_frame, text="Schließen", 
                  command=details_window.destroy).pack(side=tk.RIGHT, padx=5)
                  
    def _copy_selected(self):
        """Kopiert die ausgewählten Einträge in die Zwischenablage"""
        selected = self.result_tree.selection()
        if not selected:
            return
            
        # Text für Zwischenablage sammeln
        copy_text = ""
        for item in selected:
            values = self.result_tree.item(item, "values")
            copy_text += "\t".join(str(v) for v in values) + "\n"
            
        # In Zwischenablage kopieren
        self.clipboard_clear()
        self.clipboard_append(copy_text)
        
    def export_results(self, format_type="xlsx"):
        """Exportiert die Ergebnisse in eine Datei"""
        if not self.results:
            messagebox.showinfo("Information", "Keine Ergebnisse zum Exportieren vorhanden")
            return
            
        # Hole Export-Einstellungen
        config = self.config_manager.get_config()
        default_path = config.get("export_settings", {}).get("export_path", "")
        
        # Wenn kein Pfad konfiguriert ist, stelle sicher, dass ein vernünftiger Standardpfad verwendet wird
        if not default_path or not os.path.exists(default_path):
            default_path = os.path.expanduser("~")
        
        # Erstelle Dateinamen-Vorschlag mit Datum
        current_date = datetime.now().strftime("%Y%m%d")
        filename = f"spytool_results_{current_date}.{format_type}"
        
        # Zeige Speicherdialog
        filepath = filedialog.asksaveasfilename(
            initialdir=default_path,
            initialfile=filename,
            defaultextension=f".{format_type}",
            filetypes=[
                ("Excel-Dateien", "*.xlsx"),
                ("CSV-Dateien", "*.csv"),
                ("Alle Dateien", "*.*")
            ]
        )
        
        if not filepath:
            return
            
        try:
            # Konvertiere Ergebnisse in DataFrame
            # Erstelle saubere Daten für den Export
            export_data = []
            for result in self.results:
                # Basisfelder, die in allen Datenbankeinträgen vorhanden sein sollten
                entry = {
                    "Titel": result.get("title", ""),
                    "Autoren": ", ".join(result.get("authors", [])),
                    "Jahr": result.get("year", ""),
                    "Journal/Quelle": result.get("journal", ""),
                    "Datenbank": result.get("source", "").upper(),
                    "DOI": result.get("doi", "")
                }
                
                # Zusätzliche Felder, die je nach Datenbank unterschiedlich sein können
                if "abstract" in result:
                    entry["Abstract"] = result.get("abstract", "")
                if "volume" in result:
                    entry["Band"] = result.get("volume", "")
                if "issue" in result:
                    entry["Ausgabe"] = result.get("issue", "")
                if "pages" in result:
                    entry["Seiten"] = result.get("pages", "")
                if "isbn" in result:
                    entry["ISBN"] = result.get("isbn", "")
                if "citations" in result:
                    entry["Zitierungen"] = result.get("citations", "")
                if "keywords" in result:
                    if isinstance(result["keywords"], list):
                        entry["Schlüsselwörter"] = ", ".join(result["keywords"])
                    else:
                        entry["Schlüsselwörter"] = str(result.get("keywords", ""))
                
                export_data.append(entry)
            
            # Erstelle DataFrame
            df = pd.DataFrame(export_data)
            
            # Exportiere je nach Dateiendung
            if filepath.endswith('.csv'):
                df.to_csv(filepath, index=False, encoding='utf-8-sig')  # utf-8-sig für Excel-Kompatibilität
            elif filepath.endswith('.xlsx'):
                df.to_excel(filepath, index=False, engine='openpyxl')
                
            self.logger.info(f"Ergebnisse erfolgreich exportiert nach: {filepath}")
            messagebox.showinfo("Export erfolgreich", f"Die Ergebnisse wurden erfolgreich exportiert nach:\n{filepath}")
            
        except Exception as e:
            self.logger.error(f"Fehler beim Exportieren der Ergebnisse: {e}")
            messagebox.showerror("Fehler", f"Fehler beim Exportieren der Ergebnisse:\n{str(e)}")