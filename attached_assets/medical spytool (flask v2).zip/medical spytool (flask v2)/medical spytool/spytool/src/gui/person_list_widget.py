"""Widget zur Verwaltung der Personenliste"""
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import json
import os
from typing import Dict, List, Optional
from core.logger import Logger

class PersonListWidget(ttk.Frame):
    def __init__(self, parent, logger: Logger):
        super().__init__(parent)
        self.logger = logger
        self.persons = []  # Liste der Personen
        
        self._create_widgets()
        
    def _create_widgets(self):
        """Erstellt die GUI-Elemente"""
        # Toolbar für Aktionen
        toolbar = ttk.Frame(self)
        toolbar.pack(fill=tk.X, padx=5, pady=5)
        
        # Buttons für Personenverwaltung
        ttk.Button(toolbar, text="Hinzufügen", command=self._add_person).pack(side=tk.LEFT, padx=2)
        ttk.Button(toolbar, text="Bearbeiten", command=self._edit_selected_person).pack(side=tk.LEFT, padx=2)
        ttk.Button(toolbar, text="Löschen", command=self._delete_selected_persons).pack(side=tk.LEFT, padx=2)
        
        # Import/Export-Buttons
        ttk.Button(toolbar, text="Importieren", command=self._import_persons).pack(side=tk.RIGHT, padx=2)
        ttk.Button(toolbar, text="Exportieren", command=self._export_persons).pack(side=tk.RIGHT, padx=2)
        
        # Liste mit Personen
        list_frame = ttk.Frame(self)
        list_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Erstelle Treeview für Personen
        columns = ("selected", "firstname", "lastname", "institution")
        self.person_tree = ttk.Treeview(
            list_frame,
            columns=columns,
            show="headings",
            selectmode="extended"
        )
        
        # Spaltenüberschriften
        self.person_tree.heading("selected", text="")
        self.person_tree.heading("firstname", text="Vorname", command=lambda: self._sort_by_column("firstname"))
        self.person_tree.heading("lastname", text="Nachname", command=lambda: self._sort_by_column("lastname"))
        self.person_tree.heading("institution", text="Institution", command=lambda: self._sort_by_column("institution"))
        
        # Spaltenbreiten
        self.person_tree.column("selected", width=30, minwidth=30, stretch=tk.NO)
        self.person_tree.column("firstname", width=120, minwidth=80)
        self.person_tree.column("lastname", width=120, minwidth=80)
        self.person_tree.column("institution", width=150, minwidth=100)
        
        # Scrollbars
        vsb = ttk.Scrollbar(list_frame, orient="vertical", command=self.person_tree.yview)
        hsb = ttk.Scrollbar(list_frame, orient="horizontal", command=self.person_tree.xview)
        self.person_tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        
        # Layout der Scrollbars
        self.person_tree.grid(column=0, row=0, sticky="nsew")
        vsb.grid(column=1, row=0, sticky="ns")
        hsb.grid(column=0, row=1, sticky="ew")
        
        # Konfiguriere Tabellenrahmen zum Expandieren
        list_frame.columnconfigure(0, weight=1)
        list_frame.rowconfigure(0, weight=1)
        
        # Status-Leiste
        self.status_var = tk.StringVar(value="0 Personen")
        status_bar = ttk.Label(self, textvariable=self.status_var, anchor=tk.W)
        status_bar.pack(side=tk.BOTTOM, fill=tk.X, padx=5, pady=2)
        
        # Doppelklick zum Bearbeiten
        self.person_tree.bind("<Double-1>", lambda e: self._edit_selected_person())
        
        # Rechtsklick-Menü
        self._setup_context_menu()
        
        # Checkbox-Click zum Auswählen/Abwählen
        self.person_tree.bind("<ButtonRelease-1>", self._handle_click)
    
    def pack_in(self, parent):
        """Packt das Widget in einen anderen Container"""
        # Falls das Widget bereits gepackt ist, entferne es zuerst
        self.pack_forget()
        
        # Packe das Widget in den neuen Container
        self.pack(in_=parent, fill=tk.BOTH, expand=True, padx=5, pady=5)
        return self
    
    def _setup_context_menu(self):
        """Erstellt das Kontextmenü"""
        self.context_menu = tk.Menu(self, tearoff=0)
        self.context_menu.add_command(label="Hinzufügen", command=self._add_person)
        self.context_menu.add_command(label="Bearbeiten", command=self._edit_selected_person)
        self.context_menu.add_command(label="Löschen", command=self._delete_selected_persons)
        self.context_menu.add_separator()
        self.context_menu.add_command(label="Alle auswählen", command=self._select_all_persons)
        self.context_menu.add_command(label="Keine auswählen", command=self._unselect_all_persons)
        
        # Rechtsklick-Bindung
        self.person_tree.bind("<Button-3>", self._show_context_menu)
    
    def _show_context_menu(self, event):
        """Zeigt das Kontextmenü an"""
        try:
            self.context_menu.tk_popup(event.x_root, event.y_root)
        finally:
            self.context_menu.grab_release()
    
    def _sort_by_column(self, column):
        """Sortiert die Personenliste nach einer Spalte"""
        # Aktuelle Elemente abrufen
        items = [(self.person_tree.set(k, column), k) for k in self.person_tree.get_children('')]
        
        # Sortieren
        items.sort(reverse=self.person_tree.heading(column).get("sortorder") == "descending")
        
        # Sortierreihenfolge umkehren für den nächsten Klick
        new_order = "descending" if self.person_tree.heading(column).get("sortorder") != "descending" else "ascending"
        self.person_tree.heading(column, sortorder=new_order)
        
        # Elemente in der sortierten Reihenfolge neu einfügen
        for index, (_, k) in enumerate(items):
            self.person_tree.move(k, '', index)
    
    def _handle_click(self, event):
        """Reagiert auf Klicks in der Personenliste"""
        region = self.person_tree.identify_region(event.x, event.y)
        if region == "cell":
            column = self.person_tree.identify_column(event.x)
            if column == "#1":  # Spalte für Checkbox
                item = self.person_tree.identify_row(event.y)
                if item:
                    self._toggle_selection(item)
    
    def _toggle_selection(self, item_id):
        """Wechselt den Auswahlstatus einer Person"""
        current_values = self.person_tree.item(item_id, "values")
        if current_values:
            is_selected = current_values[0] == "✓"
            new_values = ("" if is_selected else "✓",) + current_values[1:]
            self.person_tree.item(item_id, values=new_values)
            
            # Aktualisiere Auswahl in der Personenliste
            idx = self.person_tree.index(item_id)
            if 0 <= idx < len(self.persons):
                self.persons[idx]["selected"] = not is_selected
    
    def _select_all_persons(self):
        """Wählt alle Personen aus"""
        for item in self.person_tree.get_children():
            current_values = self.person_tree.item(item, "values")
            new_values = ("✓",) + current_values[1:]
            self.person_tree.item(item, values=new_values)
            
            # Aktualisiere Auswahl in der Personenliste
            idx = self.person_tree.index(item)
            if 0 <= idx < len(self.persons):
                self.persons[idx]["selected"] = True
    
    def _unselect_all_persons(self):
        """Hebt die Auswahl aller Personen auf"""
        for item in self.person_tree.get_children():
            current_values = self.person_tree.item(item, "values")
            new_values = ("",) + current_values[1:]
            self.person_tree.item(item, values=new_values)
            
            # Aktualisiere Auswahl in der Personenliste
            idx = self.person_tree.index(item)
            if 0 <= idx < len(self.persons):
                self.persons[idx]["selected"] = False
    
    def _add_person(self):
        """Fügt eine neue Person hinzu"""
        dialog = PersonDialog(self, title="Person hinzufügen")
        if dialog.result:
            self.persons.append(dialog.result)
            self._update_display()
    
    def _edit_selected_person(self):
        """Bearbeitet die ausgewählte Person"""
        selected_items = self.person_tree.selection()
        if not selected_items:
            return
            
        # Nimm den ersten ausgewählten Eintrag
        item_id = selected_items[0]
        idx = self.person_tree.index(item_id)
        
        if 0 <= idx < len(self.persons):
            person = self.persons[idx]
            dialog = PersonDialog(self, title="Person bearbeiten", person=person)
            
            if dialog.result:
                # Übernehme Änderungen
                self.persons[idx] = dialog.result
                self._update_display()
    
    def _delete_selected_persons(self):
        """Löscht die ausgewählten Personen"""
        selected_items = self.person_tree.selection()
        if not selected_items:
            return
            
        # Bestätigung einholen
        if len(selected_items) == 1:
            confirm_msg = "Möchten Sie diese Person wirklich löschen?"
        else:
            confirm_msg = f"Möchten Sie diese {len(selected_items)} Personen wirklich löschen?"
            
        if not messagebox.askyesno("Löschen bestätigen", confirm_msg):
            return
            
        # Indizes sammeln und sortieren (absteigend, um Verschiebungen zu vermeiden)
        indices = []
        for item in selected_items:
            idx = self.person_tree.index(item)
            indices.append(idx)
            
        # Lösche von hinten nach vorne
        for idx in sorted(indices, reverse=True):
            if 0 <= idx < len(self.persons):
                del self.persons[idx]
                
        self._update_display()
        self.logger.info(f"{len(indices)} Person(en) aus der Liste entfernt.")
    
    def _update_display(self):
        """Aktualisiert die Anzeige der Personenliste"""
        # Lösche alle bestehenden Einträge
        for item in self.person_tree.get_children():
            self.person_tree.delete(item)
            
        # Füge aktuelle Personen hinzu
        for person in self.persons:
            selected_marker = "✓" if person.get("selected", False) else ""
            self.person_tree.insert(
                "",
                tk.END,
                values=(
                    selected_marker,
                    person.get("firstname", ""),
                    person.get("lastname", ""),
                    person.get("institution", "")
                )
            )
            
        # Aktualisiere Status
        self.status_var.set(f"{len(self.persons)} Person(en)")
    
    def add_person(self, firstname: str, lastname: str, institution: str = "", selected: bool = True) -> bool:
        """
        Fügt eine neue Person zur Liste hinzu
        
        Args:
            firstname: Vorname der Person
            lastname: Nachname der Person
            institution: Institution der Person (optional)
            selected: Ob die Person standardmäßig ausgewählt sein soll
            
        Returns:
            True wenn erfolgreich, False wenn die Person bereits existiert
        """
        # Überprüfe, ob die Person bereits existiert
        if any(p["firstname"] == firstname and p["lastname"] == lastname for p in self.persons):
            return False
            
        # Füge Person hinzu
        person = {
            "firstname": firstname,
            "lastname": lastname,
            "institution": institution,
            "selected": selected
        }
        self.persons.append(person)
        self._update_display()
        return True
    
    def get_persons(self) -> List[Dict]:
        """Gibt die gesamte Personenliste zurück"""
        return self.persons
    
    def get_selected_persons(self) -> List[Dict]:
        """Gibt nur die ausgewählten Personen zurück"""
        return [p for p in self.persons if p.get("selected", False)]
    
    def set_persons(self, persons: List[Dict]):
        """Setzt die Personenliste"""
        self.persons = persons
        self._update_display()
    
    def clear_persons(self):
        """Leert die Personenliste"""
        self.persons = []
        self._update_display()
    
    def _import_persons(self):
        """Importiert Personen aus einer JSON-Datei"""
        filepath = filedialog.askopenfilename(
            title="Personenliste importieren",
            filetypes=[("JSON-Dateien", "*.json"), ("Alle Dateien", "*.*")],
            defaultextension=".json"
        )
        
        if not filepath:
            return
            
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                persons = json.load(f)
                
            # Überprüfe das Format
            if not isinstance(persons, list):
                raise ValueError("Ungültiges Format: Personenliste muss ein Array sein")
                
            # Prüfe, ob alle erforderlichen Felder vorhanden sind
            for person in persons:
                if not isinstance(person, dict) or "firstname" not in person or "lastname" not in person:
                    raise ValueError("Ungültiges Format: Alle Personen müssen Vor- und Nachnamen haben")
                    
            # Setze die Personenliste
            self.set_persons(persons)
            self.logger.info(f"{len(persons)} Personen aus {os.path.basename(filepath)} importiert")
            messagebox.showinfo("Import erfolgreich", f"{len(persons)} Personen wurden erfolgreich importiert")
            
        except Exception as e:
            error_msg = f"Fehler beim Importieren der Personenliste: {e}"
            self.logger.error(error_msg)
            messagebox.showerror("Import fehlgeschlagen", error_msg)
    
    def _export_persons(self):
        """Exportiert Personen in eine JSON-Datei"""
        if not self.persons:
            messagebox.showinfo("Keine Personen", "Die Personenliste ist leer, es gibt nichts zu exportieren.")
            return
            
        filepath = filedialog.asksaveasfilename(
            title="Personenliste exportieren",
            filetypes=[("JSON-Dateien", "*.json"), ("Alle Dateien", "*.*")],
            defaultextension=".json"
        )
        
        if not filepath:
            return
            
        try:
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(self.persons, f, ensure_ascii=False, indent=2)
                
            self.logger.info(f"{len(self.persons)} Personen nach {os.path.basename(filepath)} exportiert")
            messagebox.showinfo("Export erfolgreich", f"{len(self.persons)} Personen wurden erfolgreich exportiert")
            
        except Exception as e:
            error_msg = f"Fehler beim Exportieren der Personenliste: {e}"
            self.logger.error(error_msg)
            messagebox.showerror("Export fehlgeschlagen", error_msg)


class PersonDialog(tk.Toplevel):
    """Dialog zum Hinzufügen oder Bearbeiten einer Person"""
    def __init__(self, parent, title="Person", person: Optional[Dict] = None):
        super().__init__(parent)
        self.title(title)
        self.transient(parent)
        self.grab_set()  # Modal machen
        self.result = None
        
        # Fenstereinstellungen
        self.geometry("400x220")
        self.resizable(False, False)
        
        # Person zum Bearbeiten oder leere Person
        self.person = person or {"firstname": "", "lastname": "", "institution": "", "selected": True}
        
        # Widgets erstellen
        self._create_widgets()
        
        # Position des Fensters relativ zum Elternfenster
        self.geometry(f"+{parent.winfo_rootx() + 50}+{parent.winfo_rooty() + 50}")
        
        # Auf Abschluss warten
        self.wait_window(self)
        
    def _create_widgets(self):
        """Erstellt die GUI-Elemente"""
        # Hauptrahmen mit etwas Padding
        main_frame = ttk.Frame(self, padding=10)
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Eingabefelder
        ttk.Label(main_frame, text="Vorname:").grid(row=0, column=0, sticky=tk.W, padx=5, pady=5)
        self.firstname = ttk.Entry(main_frame, width=30)
        self.firstname.grid(row=0, column=1, padx=5, pady=5, sticky=tk.W+tk.E)
        self.firstname.insert(0, self.person.get("firstname", ""))
        
        ttk.Label(main_frame, text="Nachname:").grid(row=1, column=0, sticky=tk.W, padx=5, pady=5)
        self.lastname = ttk.Entry(main_frame, width=30)
        self.lastname.grid(row=1, column=1, padx=5, pady=5, sticky=tk.W+tk.E)
        self.lastname.insert(0, self.person.get("lastname", ""))
        
        ttk.Label(main_frame, text="Institution:").grid(row=2, column=0, sticky=tk.W, padx=5, pady=5)
        self.institution = ttk.Entry(main_frame, width=30)
        self.institution.grid(row=2, column=1, padx=5, pady=5, sticky=tk.W+tk.E)
        self.institution.insert(0, self.person.get("institution", ""))
        
        # Auswahlstatus
        self.selected = tk.BooleanVar(value=self.person.get("selected", True))
        selected_cb = ttk.Checkbutton(
            main_frame, 
            text="Für Suche auswählen", 
            variable=self.selected
        )
        selected_cb.grid(row=3, column=0, columnspan=2, padx=5, pady=10, sticky=tk.W)
        
        # Buttons
        button_frame = ttk.Frame(main_frame)
        button_frame.grid(row=4, column=0, columnspan=2, pady=10, sticky=tk.E)
        
        ttk.Button(button_frame, text="Speichern", command=self._save).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="Abbrechen", command=self._cancel).pack(side=tk.LEFT, padx=5)
        
        # Enter-Taste für Speichern binden
        self.bind("<Return>", lambda e: self._save())
        self.bind("<Escape>", lambda e: self._cancel())
        
        # Focus auf erstes Feld
        self.firstname.focus_set()
        
    def _save(self):
        """Speichert die Person und schließt den Dialog"""
        firstname = self.firstname.get().strip()
        lastname = self.lastname.get().strip()
        
        # Validierung
        if not firstname:
            messagebox.showerror("Fehler", "Bitte geben Sie einen Vornamen ein.")
            self.firstname.focus_set()
            return
            
        if not lastname:
            messagebox.showerror("Fehler", "Bitte geben Sie einen Nachnamen ein.")
            self.lastname.focus_set()
            return
            
        # Ergebnis setzen
        self.result = {
            "firstname": firstname,
            "lastname": lastname,
            "institution": self.institution.get().strip(),
            "selected": self.selected.get()
        }
        
        # Dialog schließen
        self.destroy()
        
    def _cancel(self):
        """Bricht den Dialog ab"""
        self.result = None
        self.destroy()