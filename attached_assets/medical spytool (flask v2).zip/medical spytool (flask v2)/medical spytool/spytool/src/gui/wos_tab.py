"""WoSTab für die Suche in der Web of Science Datenbank"""
import tkinter as tk
from tkinter import ttk, messagebox
import threading
from datetime import datetime
from tkcalendar import DateEntry
from typing import Dict, List, Callable

from core.config_manager import ConfigManager
from core.logger import Logger
from core.database_service import DatabaseService
from utils.query_builder import QueryBuilder
from .person_list_widget import PersonListWidget

class WoSTab(ttk.Frame):
    def __init__(self, parent, config_manager: ConfigManager, logger: Logger, database_service: DatabaseService, central_person_list=None):
        super().__init__(parent)
        self.config_manager = config_manager
        self.logger = logger
        self.database_service = database_service
        self.results_callback = None
        self.central_person_list = central_person_list
        
        # Hole Web of Science Datenbankinstanz
        self.wos_db = database_service.get_database("wos")
        
        self._create_widgets()
        
    def _create_widgets(self):
        """Erstellt die GUI-Elemente"""
        # Hauptrahmen mit Scrollbars
        main_canvas = tk.Canvas(self)
        main_scrollbar = ttk.Scrollbar(self, orient="vertical", command=main_canvas.yview)
        main_scrollable_frame = ttk.Frame(main_canvas)
        
        main_scrollable_frame.bind(
            "<Configure>",
            lambda e: main_canvas.configure(
                scrollregion=main_canvas.bbox("all")
            )
        )
        
        main_canvas.create_window((0, 0), window=main_scrollable_frame, anchor="nw")
        main_canvas.configure(yscrollcommand=main_scrollbar.set)
        
        main_canvas.pack(side="left", fill="both", expand=True)
        main_scrollbar.pack(side="right", fill="y")
        
        # Personenliste und Suchoptionen
        left_frame = ttk.Frame(main_scrollable_frame, padding=10)
        left_frame.pack(side=tk.LEFT, fill=tk.BOTH, padx=10, pady=10)
        
        # Personenliste
        person_frame = ttk.LabelFrame(left_frame, text="Personenliste")
        person_frame.pack(fill=tk.BOTH, expand=True, pady=5)
        
        # Verwende zentrale Personenliste falls vorhanden, sonst erstelle eine neue
        if self.central_person_list:
            self.person_list = self.central_person_list
        else:
            self.person_list = PersonListWidget(person_frame, self.logger)
        self.person_list.pack(fill=tk.BOTH, expand=True, pady=5)
        
        # Suchoptionen
        search_options_frame = ttk.LabelFrame(left_frame, text="Suchoptionen")
        search_options_frame.pack(fill=tk.X, pady=10)
        
        # Zusätzlicher Suchbegriff
        additional_term_frame = ttk.Frame(search_options_frame)
        additional_term_frame.pack(fill=tk.X, pady=5)
        
        ttk.Label(additional_term_frame, text="Zusätzlicher Suchbegriff:").pack(side=tk.LEFT, padx=5)
        self.additional_term = ttk.Entry(additional_term_frame, width=30)
        self.additional_term.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5)
        
        # Datumsfilter
        date_frame = ttk.Frame(search_options_frame)
        date_frame.pack(fill=tk.X, pady=5)
        
        # Checkbox zum Aktivieren/Deaktivieren des Datumsfilters
        self.use_date_filter = tk.BooleanVar(value=False)
        self.date_filter_cb = ttk.Checkbutton(
            date_frame, 
            text="Datumsfilter verwenden", 
            variable=self.use_date_filter,
            command=self._toggle_date_filter
        )
        self.date_filter_cb.pack(side=tk.LEFT, padx=5)
        
        # Von-Datum
        self.date_from_label = ttk.Label(date_frame, text="Von:")
        self.date_from_label.pack(side=tk.LEFT, padx=(15, 5))
        self.date_from = DateEntry(
            date_frame,
            width=12,
            background='darkblue',
            foreground='white',
            borderwidth=2,
            state="disabled"
        )
        self.date_from.pack(side=tk.LEFT, padx=5)
        
        # Bis-Datum
        self.date_to_label = ttk.Label(date_frame, text="Bis:")
        self.date_to_label.pack(side=tk.LEFT, padx=(15, 5))
        self.date_to = DateEntry(
            date_frame,
            width=12,
            background='darkblue',
            foreground='white',
            borderwidth=2,
            state="disabled"
        )
        self.date_to.pack(side=tk.LEFT, padx=5)
        
        # Sprache
        language_frame = ttk.Frame(search_options_frame)
        language_frame.pack(fill=tk.X, pady=5)
        
        ttk.Label(language_frame, text="Sprache:").pack(side=tk.LEFT, padx=5)
        self.language = ttk.Combobox(language_frame, values=["Alle", "Deutsch", "Englisch"], width=15)
        self.language.current(0)
        self.language.pack(side=tk.LEFT, padx=5)
        
        # Dokumenttyp
        doc_type_frame = ttk.Frame(search_options_frame)
        doc_type_frame.pack(fill=tk.X, pady=5)
        
        ttk.Label(doc_type_frame, text="Dokumenttyp:").pack(side=tk.LEFT, padx=5)
        self.doc_type = ttk.Combobox(
            doc_type_frame, 
            values=["Alle", "Article", "Review", "Book", "Conference Proceedings"], 
            width=15
        )
        self.doc_type.current(0)
        self.doc_type.pack(side=tk.LEFT, padx=5)
        
        # Maximale Ergebnisse
        max_results_frame = ttk.Frame(search_options_frame)
        max_results_frame.pack(fill=tk.X, pady=5)
        
        ttk.Label(max_results_frame, text="Max. Ergebnisse pro Person:").pack(side=tk.LEFT, padx=5)
        self.max_results = ttk.Spinbox(max_results_frame, from_=10, to=500, increment=10, width=5)
        self.max_results.delete(0, tk.END)
        self.max_results.insert(0, "100")
        self.max_results.pack(side=tk.LEFT, padx=5)
        
        # Buttons
        button_frame = ttk.Frame(left_frame)
        button_frame.pack(fill=tk.X, pady=10)
        
        ttk.Button(
            button_frame, 
            text="Suche starten", 
            command=self._start_search
        ).pack(side=tk.LEFT, padx=5)
        
        ttk.Button(
            button_frame, 
            text="Zurücksetzen", 
            command=self._reset_search
        ).pack(side=tk.LEFT, padx=5)
        
        # Rechte Seite mit Fortschrittsanzeige
        right_frame = ttk.Frame(main_scrollable_frame, padding=10)
        right_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Fortschrittsanzeige
        progress_frame = ttk.LabelFrame(right_frame, text="Fortschritt")
        progress_frame.pack(fill=tk.BOTH, expand=True, pady=5)
        
        # Gesamtfortschritt
        ttk.Label(progress_frame, text="Gesamtfortschritt:").pack(anchor=tk.W, padx=5, pady=5)
        self.total_progress = ttk.Progressbar(progress_frame, orient="horizontal", length=300, mode="determinate")
        self.total_progress.pack(fill=tk.X, padx=5, pady=5)
        
        # Aktueller Fortschritt
        ttk.Label(progress_frame, text="Aktueller Suchvorgang:").pack(anchor=tk.W, padx=5, pady=5)
        self.current_progress = ttk.Progressbar(progress_frame, orient="horizontal", length=300, mode="determinate")
        self.current_progress.pack(fill=tk.X, padx=5, pady=5)
        
        # Status
        self.status_var = tk.StringVar(value="Bereit")
        status_frame = ttk.Frame(progress_frame)
        status_frame.pack(fill=tk.X, pady=10)
        
        ttk.Label(status_frame, text="Status:").pack(side=tk.LEFT, padx=5)
        ttk.Label(status_frame, textvariable=self.status_var).pack(side=tk.LEFT, padx=5)
        
        # Logausgabe
        log_frame = ttk.LabelFrame(right_frame, text="Protokoll")
        log_frame.pack(fill=tk.BOTH, expand=True, pady=5)
        
        self.log_text = tk.Text(log_frame, wrap=tk.WORD, height=10)
        log_scrollbar = ttk.Scrollbar(log_frame, orient="vertical", command=self.log_text.yview)
        self.log_text.configure(yscrollcommand=log_scrollbar.set)
        
        self.log_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=5, pady=5)
        log_scrollbar.pack(side=tk.RIGHT, fill=tk.Y, padx=(0, 5), pady=5)
        
        # Log mit aktuellem Zeitstempel ausgeben
        def log_message(message):
            current_time = datetime.now().strftime("%H:%M:%S")
            self.log_text.insert(tk.END, f"[{current_time}] {message}\n")
            self.log_text.see(tk.END)  # Scrolle zum Ende
            self.logger.info(f"[WoS] {message}")
        
        self.log = log_message
        self.log("Web of Science Suchmodul initialisiert")
    
    def _toggle_date_filter(self):
        """Aktiviert oder deaktiviert die Datumsauswahlfelder"""
        if self.use_date_filter.get():
            self.date_from.config(state="normal")
            self.date_to.config(state="normal")
        else:
            self.date_from.config(state="disabled")
            self.date_to.config(state="disabled")
    
    def set_results_callback(self, callback: Callable):
        """Setzt den Callback für Suchergebnisse"""
        self.results_callback = callback
    
    def _reset_search(self):
        """Setzt alle Suchparameter zurück"""
        self.additional_term.delete(0, tk.END)
        self.use_date_filter.set(False)
        self._toggle_date_filter()
        
        # Setze Daten auf heute zurück
        today = datetime.today()
        self.date_from.set_date(today.replace(year=today.year - 1))  # 1 Jahr zurück
        self.date_to.set_date(today)
        
        self.language.current(0)  # "Alle" auswählen
        self.doc_type.current(0)  # "Alle" auswählen
        self.max_results.delete(0, tk.END)
        self.max_results.insert(0, "100")
        
        # Fortschritt zurücksetzen
        self.total_progress["value"] = 0
        self.current_progress["value"] = 0
        self.status_var.set("Bereit")
        
        self.log("Suchparameter zurückgesetzt")
    
    def _start_search(self):
        """Startet die Suche nach Publikationen in Web of Science"""
        # Überprüfe, ob API-Key gesetzt ist
        if not self.wos_db or not hasattr(self.wos_db, 'api_key') or not self.wos_db.api_key:
            messagebox.showerror(
                "Fehler", 
                "Es ist kein Web of Science API-Key konfiguriert. Bitte gehen Sie zu den Einstellungen und fügen Sie einen gültigen API-Key hinzu."
            )
            return
            
        # Überprüfe, ob Personen ausgewählt sind
        persons = self.person_list.get_selected_persons()
        if not persons:
            messagebox.showwarning(
                "Keine Personen ausgewählt", 
                "Bitte fügen Sie mindestens eine Person zur Personenliste hinzu und wählen Sie diese für die Suche aus."
            )
            return
            
        # Hole Suchparameter
        try:
            max_results = int(self.max_results.get())
            if max_results < 1:
                raise ValueError("Max. Ergebnisse muss mindestens 1 sein")
        except ValueError as e:
            messagebox.showerror("Fehler", f"Ungültige Anzahl von max. Ergebnissen: {e}")
            return
            
        self.log(f"Starte Suche für {len(persons)} Personen in Web of Science")
        
        # Zurücksetzen der Fortschrittsanzeige
        self.total_progress["value"] = 0
        self.current_progress["value"] = 0
        
        # Erstelle Such-Filter
        filters = {
            "language": self.language.get(),
            "document_type": self.doc_type.get()
        }
        
        # Datumsfilter, wenn aktiviert
        if self.use_date_filter.get():
            filters["date_from"] = self.date_from.get_date().strftime("%Y-%m-%d")
            filters["date_to"] = self.date_to.get_date().strftime("%Y-%m-%d")
            
        # Zusätzlicher Suchbegriff
        additional_term = self.additional_term.get().strip()
        
        # Starte Suche in separatem Thread
        threading.Thread(
            target=self._execute_search,
            args=(persons, additional_term, filters, max_results),
            daemon=True
        ).start()
    
    def _execute_search(self, persons: List[Dict], additional_term: str, filters: Dict, max_results: int):
        """Führt die Suche für alle ausgewählten Personen durch"""
        all_results = []
        total_persons = len(persons)
        
        for i, person in enumerate(persons):
            try:
                # Aktualisiere Statusanzeige
                person_name = f"{person['firstname']} {person['lastname']}"
                self.status_var.set(f"Suche nach: {person_name}")
                self.total_progress["value"] = int((i / total_persons) * 100)
                
                self.log(f"Suche nach Publikationen von {person_name}")
                
                # Erstelle Abfrage mit QueryBuilder
                query_builder = QueryBuilder()
                query_builder.add_author(person['firstname'], person['lastname'])
                
                if additional_term:
                    query_builder.add_term(additional_term)
                
                if filters.get("language") != "Alle":
                    query_builder.add_language(filters["language"])
                    
                if filters.get("document_type") != "Alle":
                    query_builder.add_document_type(filters["document_type"])
                    
                if "date_from" in filters and "date_to" in filters:
                    query_builder.add_date_range(
                        start_date=filters["date_from"],
                        end_date=filters["date_to"]
                    )
                
                # Erstelle die WoS-spezifische Abfrage
                query = query_builder.build("wos")
                    
                # Aktualisiere Fortschrittsanzeige
                self.current_progress["value"] = 0
                self.log(f"Abfrage: {query}")
                
                # Führe die Suche durch
                results = self.wos_db.search(query, max_results=max_results)
                
                # Füge Person als Metadaten hinzu
                for result in results:
                    result["searched_person"] = person_name
                    result["source"] = "wos"
                
                # Füge Ergebnisse zur Gesamtliste hinzu
                all_results.extend(results)
                
                # Aktualisiere Fortschrittsanzeige
                self.current_progress["value"] = 100
                self.log(f"{len(results)} Publikationen für {person_name} gefunden")
                
            except Exception as e:
                error_msg = f"Fehler bei der Suche nach {person_name}: {e}"
                self.log(error_msg)
                self.logger.error(error_msg)
        
        # Suchvorgang abgeschlossen
        self.total_progress["value"] = 100
        self.status_var.set(f"Fertig: {len(all_results)} Publikationen insgesamt")
        self.log(f"Suchvorgang abgeschlossen. Insgesamt {len(all_results)} Publikationen gefunden.")
        
        # Rufe den Callback auf, wenn Ergebnisse gefunden wurden
        if all_results and self.results_callback:
            self.results_callback(all_results)
            self.log("Ergebnisse wurden an die Ergebnisansicht übermittelt.")