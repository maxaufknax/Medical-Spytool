"""AnalysisTab für die Visualisierung und Analyse von Suchergebnissen"""
import tkinter as tk
from tkinter import ttk
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from typing import List, Dict

from core.config_manager import ConfigManager
from core.logger import Logger

class AnalysisTab(ttk.Frame):
    def __init__(self, parent, config_manager: ConfigManager, logger: Logger):
        super().__init__(parent)
        self.config_manager = config_manager
        self.logger = logger
        self.results = []  # Speichert die aktuellen Suchergebnisse
        
        self._create_widgets()
        
    def _create_widgets(self):
        """Erstellt die GUI-Elemente"""
        # Kontroll-Panel
        control_frame = ttk.LabelFrame(self, text="Analyse-Optionen")
        control_frame.pack(fill=tk.X, padx=5, pady=5)
        
        # Diagrammtyp-Auswahl
        ttk.Label(control_frame, text="Diagrammtyp:").pack(side=tk.LEFT, padx=5)
        self.chart_type = ttk.Combobox(
            control_frame, 
            values=["Publikationen pro Jahr", "Top Journals", "Häufige Autoren"],
            width=25
        )
        self.chart_type.pack(side=tk.LEFT, padx=5)
        self.chart_type.set("Publikationen pro Jahr")
        
        ttk.Button(control_frame, text="Aktualisieren", command=self._update_chart).pack(side=tk.LEFT, padx=5)
        
        # Frame für das Diagramm
        self.chart_frame = ttk.Frame(self)
        self.chart_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
    def set_results(self, results: List[Dict]):
        """Aktualisiert die Ergebnisliste und das Diagramm"""
        self.results = results
        self._update_chart()
        
    def _update_chart(self):
        """Aktualisiert das Diagramm basierend auf der aktuellen Auswahl"""
        # Lösche altes Diagramm
        for widget in self.chart_frame.winfo_children():
            widget.destroy()
            
        if not self.results:
            ttk.Label(self.chart_frame, text="Keine Daten verfügbar").pack(expand=True)
            return
            
        # Erstelle DataFrame
        df = pd.DataFrame(self.results)
        
        # Erstelle Figure und Axis
        fig, ax = plt.subplots(figsize=(10, 6))
        
        chart_type = self.chart_type.get()
        
        if chart_type == "Publikationen pro Jahr":
            self._create_publications_per_year(df, ax)
        elif chart_type == "Top Journals":
            self._create_top_journals(df, ax)
        elif chart_type == "Häufige Autoren":
            self._create_top_authors(df, ax)
            
        # Erstelle Canvas und zeige Diagramm
        canvas = FigureCanvasTkAgg(fig, master=self.chart_frame)
        canvas.draw()
        canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
        
    def _create_publications_per_year(self, df: pd.DataFrame, ax):
        """Erstellt ein Diagramm der Publikationen pro Jahr"""
        if 'year' not in df.columns:
            return
            
        # Zähle Publikationen pro Jahr
        year_counts = df['year'].value_counts().sort_index()
        
        # Erstelle Balkendiagramm
        ax.bar(year_counts.index, year_counts.values)
        
        # Beschrifte Achsen
        ax.set_xlabel('Jahr')
        ax.set_ylabel('Anzahl Publikationen')
        ax.set_title('Publikationen pro Jahr')
        
        # Rotiere x-Achsen-Labels
        plt.xticks(rotation=45)
        
    def _create_top_journals(self, df: pd.DataFrame, ax):
        """Erstellt ein Diagramm der häufigsten Journals"""
        if 'journal' not in df.columns:
            return
            
        # Zähle Publikationen pro Journal
        journal_counts = df['journal'].value_counts().head(10)
        
        # Erstelle horizontales Balkendiagramm
        ax.barh(journal_counts.index, journal_counts.values)
        
        # Beschrifte Achsen
        ax.set_xlabel('Anzahl Publikationen')
        ax.set_ylabel('Journal')
        ax.set_title('Top 10 Journals')
        
    def _create_top_authors(self, df: pd.DataFrame, ax):
        """Erstellt ein Diagramm der häufigsten Autoren"""
        if 'authors' not in df.columns:
            return
            
        # Extrahiere alle Autoren
        all_authors = []
        for authors in df['authors']:
            if isinstance(authors, list):
                all_authors.extend(authors)
            
        # Zähle Publikationen pro Autor
        author_counts = pd.Series(all_authors).value_counts().head(10)
        
        # Erstelle horizontales Balkendiagramm
        ax.barh(author_counts.index, author_counts.values)
        
        # Beschrifte Achsen
        ax.set_xlabel('Anzahl Publikationen')
        ax.set_ylabel('Autor')
        ax.set_title('Top 10 Autoren')