"""GeprisTab für die Suche in der DFG GEPRIS-Datenbank"""
import tkinter as tk
from tkinter import ttk, messagebox
import threading
from datetime import datetime
from tkcalendar import DateEntry
from typing import Dict, List, Callable

from core.config_manager import ConfigManager
from core.logger import Logger
from core.database_service import DatabaseService
from utils.query_builder import QueryBuilder
from .person_list_widget import PersonListWidget

class GeprisTab(ttk.Frame):
    def __init__(self, parent, config_manager: ConfigManager, logger: Logger, database_service: DatabaseService, central_person_list=None):
        super().__init__(parent)
        self.config_manager = config_manager
        self.logger = logger
        self.database_service = database_service
        self.central_person_list = central_person_list
        self.results_callback = None
        
        # Hole GEPRIS Datenbankinstanz
        self.gepris_db = database_service.get_database("gepris")
        
        self._create_widgets()
    
    def set_results_callback(self, callback: Callable):
        """Setzt die Callback-Funktion für Suchergebnisse"""
        self.results_callback = callback
        
    def _toggle_date_filter_fields(self):
        """Aktiviert oder deaktiviert die Datumsfelder basierend auf dem Checkbox-Status"""
        if self.use_date_filter.get():
            self.date_from.config(state="normal")
            self.date_to.config(state="normal")
        else:
            self.date_from.config(state="disabled")
            self.date_to.config(state="disabled")
        
    def _create_widgets(self):
        """Erstellt die GUI-Elemente"""
        # Hauptrahmen mit Scrollbars
        main_canvas = tk.Canvas(self)
        main_scrollbar = ttk.Scrollbar(self, orient="vertical", command=main_canvas.yview)
        main_scrollable_frame = ttk.Frame(main_canvas)
        
        main_scrollable_frame.bind(
            "<Configure>",
            lambda e: main_canvas.configure(
                scrollregion=main_canvas.bbox("all")
            )
        )
        
        main_canvas.create_window((0, 0), window=main_scrollable_frame, anchor="nw")
        main_canvas.configure(yscrollcommand=main_scrollbar.set)
        
        main_canvas.pack(side="left", fill="both", expand=True)
        main_scrollbar.pack(side="right", fill="y")
        
        # Personenliste und Suchoptionen
        left_frame = ttk.Frame(main_scrollable_frame, padding=10)
        left_frame.pack(side=tk.LEFT, fill=tk.BOTH, padx=10, pady=10)
        
        # Personenliste
        person_frame = ttk.LabelFrame(left_frame, text="Personenliste")
        person_frame.pack(fill=tk.BOTH, expand=True, pady=5)
        
        # Verwende die zentrale Personenliste, falls vorhanden, sonst eigene erstellen
        if self.central_person_list:
            # Anstatt die zentrale Liste zu packen, nur eine Referenz darauf behalten
            # und ihre Funktionen verwenden
            self.person_list = self.central_person_list
            # Erstelle ein neues Frame in unserem Tab, das nur Zugriff auf die zentrale Liste bietet
            person_list_frame = ttk.Frame(person_frame)
            person_list_frame.pack(fill=tk.BOTH, expand=True, pady=5)
            
            # Hinzufügen eines Labels als Hinweis auf die gemeinsame Nutzung
            ttk.Label(person_list_frame, text="Verwendung der zentralen Personenliste").pack(pady=5)
            
            # Füge Buttons für häufige Aktionen hinzu
            btn_frame = ttk.Frame(person_list_frame)
            btn_frame.pack(fill=tk.X, pady=5)
            ttk.Button(btn_frame, text="Personen auswählen", 
                      command=lambda: self.person_list._select_all_persons()).pack(side=tk.LEFT, padx=2)
            ttk.Button(btn_frame, text="Auswahl aufheben", 
                      command=lambda: self.person_list._unselect_all_persons()).pack(side=tk.LEFT, padx=2)
        else:
            # Wenn keine zentrale Liste vorhanden ist, erstelle eine neue
            self.person_list = PersonListWidget(person_frame, self.logger)
            self.person_list.pack(fill=tk.BOTH, expand=True, pady=5)
        
        # Suchoptionen
        search_options_frame = ttk.LabelFrame(left_frame, text="Suchoptionen")
        search_options_frame.pack(fill=tk.X, pady=10)
        
        # Zusätzlicher Suchbegriff
        additional_term_frame = ttk.Frame(search_options_frame)
        additional_term_frame.pack(fill=tk.X, pady=5)
        
        ttk.Label(additional_term_frame, text="Zusätzlicher Suchbegriff:").pack(side=tk.LEFT, padx=5)
        self.additional_term = ttk.Entry(additional_term_frame, width=30)
        self.additional_term.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5)
        
        # Datumsfilter
        date_frame = ttk.Frame(search_options_frame)
        date_frame.pack(fill=tk.X, pady=5)
        
        # Checkbox zum Aktivieren/Deaktivieren des Datumsfilters
        self.use_date_filter = tk.BooleanVar(value=False)
        self.date_filter_cb = ttk.Checkbutton(
            date_frame, 
            text="Datumsfilter verwenden", 
            variable=self.use_date_filter,
            command=lambda: self._toggle_date_filter_fields()
        )
        self.date_filter_cb.pack(side=tk.LEFT, padx=5)
        
        # Von-Datum
        self.date_from_label = ttk.Label(date_frame, text="Von:")
        self.date_from_label.pack(side=tk.LEFT, padx=(15, 5))
        self.date_from = DateEntry(
            date_frame,
            width=12,
            background='darkblue',
            foreground='white',
            borderwidth=2,
            state="disabled"
        )
        self.date_from.pack(side=tk.LEFT, padx=5)
        
        # Bis-Datum
        self.date_to_label = ttk.Label(date_frame, text="Bis:")
        self.date_to_label.pack(side=tk.LEFT, padx=(15, 5))
        self.date_to = DateEntry(
            date_frame,
            width=12,
            background='darkblue',
            foreground='white',
            borderwidth=2,
            state="disabled"
        )
        self.date_to.pack(side=tk.LEFT, padx=5)
        
        # GEPRIS-spezifische Optionen
        gepris_specific_frame = ttk.Frame(search_options_frame)
        gepris_specific_frame.pack(fill=tk.X, pady=5)
        
        ttk.Label(gepris_specific_frame, text="Projekttyp:").pack(side=tk.LEFT, padx=5)
        self.project_type = ttk.Combobox(
            gepris_specific_frame, 
            values=["Alle", "Einzelförderung", "Graduiertenkolleg", "Forschergruppe", "Sonderforschungsbereich"], 
            width=15
        )
        self.project_type.current(0)
        self.project_type.pack(side=tk.LEFT, padx=5)

        # Förderprogramm
        program_frame = ttk.Frame(search_options_frame)
        program_frame.pack(fill=tk.X, pady=5)
        
        ttk.Label(program_frame, text="Förderprogramm:").pack(side=tk.LEFT, padx=5)
        self.funding_program = ttk.Combobox(
            program_frame, 
            values=["Alle", "Sachbeihilfe", "Emmy Noether", "Heisenberg", "Forschungsstipendium"], 
            width=15
        )
        self.funding_program.current(0)
        self.funding_program.pack(side=tk.LEFT, padx=5)
        
        # Maximale Ergebnisse