import tkinter as tk
from tkinter import ttk, messagebox
from core.config_manager import ConfigManager
from core.logger import Logger
from core.database_service import DatabaseService
from core.person_manager import PersonManager
from .person_list_widget import PersonListWidget
from .search_tab import SearchTab
from .results_tab import ResultsTab
from .analysis_tab import AnalysisTab
from .settings_tab import SettingsTab
from .pubmed_tab import PubMedTab
from .dnb_tab import DNBTab
from .scopus_tab import ScopusTab
from .wos_tab import WoSTab
from .gepris_tab import GeprisTab
from .log_tab import LogTab

class MainWindow(tk.Tk):
    def __init__(self):
        super().__init__()
        
        self.title("Medical Spytool")
        self.geometry("1200x800")
        
        # Initialisiere Core-Module
        self.config_manager = ConfigManager()
        self.logger = Logger()
        self.database_service = DatabaseService(self.config_manager, self.logger)
        self.person_manager = PersonManager()
        
        # Status-Variable initialisieren
        self.status_var = tk.StringVar(value="Bereit")
        
        # Erstelle ein zentrales PersonListWidget
        left_sidebar = ttk.Frame(self)
        left_sidebar.pack(side=tk.LEFT, fill=tk.Y, padx=5, pady=5)
        
        # Person List Frame
        person_frame = ttk.LabelFrame(left_sidebar, text="Personenliste")
        person_frame.pack(fill=tk.BOTH, expand=True, pady=5)
        
        # Zentrale Personenliste erstellen
        self.central_person_list = PersonListWidget(person_frame, self.logger)
        self.central_person_list.pack(fill=tk.BOTH, expand=True, pady=5)
        
        # Content Frame
        content_frame = ttk.Frame(self)
        content_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        self._create_widgets(content_frame)
        self._setup_menu()
        
        # Status-Leiste
        status_bar = ttk.Label(self, textvariable=self.status_var, relief=tk.SUNKEN, anchor=tk.W)
        status_bar.pack(side=tk.BOTTOM, fill=tk.X)
        
        self.logger.info("Medical Spytool gestartet")
        
    def _create_widgets(self, parent):
        """Erstellt die GUI-Elemente"""
        # Erstelle Notebook für Tabs mit Styles
        style = ttk.Style()
        style.configure("TNotebook", tabposition='nw')
        style.configure("TNotebook.Tab", padding=[10, 5], font=('Helvetica', 10))
        
        # Tab Control mit horizontalen Tabs
        self.notebook = ttk.Notebook(parent)
        self.notebook.pack(fill=tk.BOTH, expand=True)
        
        # Erstelle Tabs
        self.search_tab = SearchTab(
            self.notebook,
            self.config_manager,
            self.logger,
            self.database_service,
            self.central_person_list  # Übergebe die zentrale Personenliste
        )
        
        # Spezialisierte Einstellungs-Tabs für Datenbanken
        self.pubmed_tab = PubMedTab(
            self.notebook,
            self.config_manager,
            self.logger,
            self.database_service,
            self.central_person_list  # Übergebe die zentrale Personenliste
        )
        self.dnb_tab = DNBTab(
            self.notebook,
            self.config_manager,
            self.logger,
            self.database_service,
            self.central_person_list  # Übergebe die zentrale Personenliste
        )
        self.scopus_tab = ScopusTab(
            self.notebook,
            self.config_manager,
            self.logger,
            self.database_service,
            self.central_person_list  # Übergebe die zentrale Personenliste
        )
        self.wos_tab = WoSTab(
            self.notebook,
            self.config_manager,
            self.logger,
            self.database_service,
            self.central_person_list  # Übergebe die zentrale Personenliste
        )
        self.gepris_tab = GeprisTab(
            self.notebook,
            self.config_manager,
            self.logger,
            self.database_service,
            self.central_person_list  # Übergebe die zentrale Personenliste
        )
        
        # Ergebnis- und Analyse-Tabs
        self.results_tab = ResultsTab(
            self.notebook,
            self.config_manager,
            self.logger
        )
        self.analysis_tab = AnalysisTab(
            self.notebook,
            self.config_manager,
            self.logger
        )
        
        # Einstellungen und Log-Tab
        self.settings_tab = SettingsTab(
            self.notebook,
            self.config_manager,
            self.logger,
            self.database_service
        )
        self.log_tab = LogTab(
            self.notebook,
            self.logger
        )
        
        # Füge Tabs in logischen Gruppen hinzu
        self.notebook.add(self.search_tab, text="Suche", padding=5)
        
        # Füge Trennzeichen für spezifische Datenbank-Tabs hinzu
        separator_frame = ttk.Frame(self.notebook, height=1, style="Separator.TFrame")
        self.notebook.add(separator_frame, text="", state="disabled")
        
        # Spezifische Datenbank-Einstellungs-Tabs
        self.notebook.add(self.pubmed_tab, text="PubMed-Einst.", padding=5)
        self.notebook.add(self.dnb_tab, text="DNB-Einst.", padding=5)
        self.notebook.add(self.scopus_tab, text="Scopus-Einst.", padding=5)
        self.notebook.add(self.wos_tab, text="WoS-Einst.", padding=5)
        self.notebook.add(self.gepris_tab, text="GEPRIS-Einst.", padding=5)
        
        # Trennzeichen für Ergebnis-Tabs
        separator_frame2 = ttk.Frame(self.notebook, height=1, style="Separator.TFrame")
        self.notebook.add(separator_frame2, text="", state="disabled")
        
        # Ergebnis-Tabs
        self.notebook.add(self.results_tab, text="Ergebnisse", padding=5)
        self.notebook.add(self.analysis_tab, text="Analyse", padding=5)
        
        # Trennzeichen für Einstellungs-Tabs
        separator_frame3 = ttk.Frame(self.notebook, height=1, style="Separator.TFrame")
        self.notebook.add(separator_frame3, text="", state="disabled")
        
        # Einstellungs-Tabs
        self.notebook.add(self.settings_tab, text="Einstellungen", padding=5)
        self.notebook.add(self.log_tab, text="Log", padding=5)
        
        # Tab-Wechsel-Event
        self.notebook.bind("<<NotebookTabChanged>>", self._on_tab_changed)
        
        # Verbinde Tabs - Weiterleitung der Suchergebnisse
        self.search_tab.set_results_callback(self._handle_search_results)
        self.pubmed_tab.set_results_callback(self._handle_search_results)
        self.dnb_tab.set_results_callback(self._handle_search_results)
        self.scopus_tab.set_results_callback(self._handle_search_results)
        self.wos_tab.set_results_callback(self._handle_search_results)
        self.gepris_tab.set_results_callback(self._handle_search_results)
        
    def _on_tab_changed(self, event):
        """Behandelt Tab-Wechsel-Ereignisse"""
        tab_id = self.notebook.select()
        tab_text = self.notebook.tab(tab_id, "text")
        if tab_text:
            self.status_var.set(f"Aktiver Tab: {tab_text}")
            self.logger.info(f"Tab gewechselt zu: {tab_text}")
        
    def _handle_search_results(self, results):
        """Verarbeitet neue Suchergebnisse"""
        if not results:
            messagebox.showinfo("Information", "Die Suche hat keine Ergebnisse zurückgeliefert.")
            return
        
        # Aktualisiere Ergebnisse und Analyse
        self.results_tab.add_results(results)
        self.analysis_tab.set_results(results)
        
        # Wechsle zum Ergebnistab
        result_tab_index = self._find_tab_index_by_text("Ergebnisse")
        if result_tab_index >= 0:
            self.notebook.select(result_tab_index)
            
        # Aktualisiere Status
        result_count = len(results)
        self.status_var.set(f"{result_count} Ergebnisse gefunden")
        
    def _find_tab_index_by_text(self, tab_text):
        """Findet den Index eines Tabs anhand seines Textes"""
        for i in range(self.notebook.index("end")):
            if self.notebook.tab(i, "text") == tab_text:
                return i
        return -1
        
    def _setup_menu(self):
        """Erstellt die Menüleiste"""
        menubar = tk.Menu(self)
        self.config(menu=menubar)
        
        # Datei-Menü
        file_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Datei", menu=file_menu)
        file_menu.add_command(label="Neue Suche", command=self._new_search)
        file_menu.add_separator()
        file_menu.add_command(label="Personenliste importieren", command=self._import_persons)
        file_menu.add_command(label="Personenliste exportieren", command=self._export_persons)
        file_menu.add_separator()
        file_menu.add_command(label="Ergebnisse exportieren", command=self._export_results)
        file_menu.add_separator()
        file_menu.add_command(label="Beenden", command=self.quit)
        
        # Bearbeiten-Menü
        edit_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Bearbeiten", menu=edit_menu)
        edit_menu.add_command(label="Einstellungen", command=lambda: self.notebook.select(self._find_tab_index_by_text("Einstellungen")))
        
        # Ansicht-Menü
        view_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Ansicht", menu=view_menu)
        view_menu.add_command(label="Suche", command=lambda: self.notebook.select(0))
        view_menu.add_separator()
        view_menu.add_command(label="PubMed-Einst.", command=lambda: self.notebook.select(self._find_tab_index_by_text("PubMed-Einst.")))
        view_menu.add_command(label="DNB-Einst.", command=lambda: self.notebook.select(self._find_tab_index_by_text("DNB-Einst.")))
        view_menu.add_command(label="Scopus-Einst.", command=lambda: self.notebook.select(self._find_tab_index_by_text("Scopus-Einst.")))
        view_menu.add_command(label="WoS-Einst.", command=lambda: self.notebook.select(self._find_tab_index_by_text("WoS-Einst.")))
        view_menu.add_command(label="GEPRIS-Einst.", command=lambda: self.notebook.select(self._find_tab_index_by_text("GEPRIS-Einst.")))
        view_menu.add_separator()
        view_menu.add_command(label="Ergebnisse", command=lambda: self.notebook.select(self._find_tab_index_by_text("Ergebnisse")))
        view_menu.add_command(label="Analyse", command=lambda: self.notebook.select(self._find_tab_index_by_text("Analyse")))
        view_menu.add_separator()
        view_menu.add_command(label="Log", command=lambda: self.notebook.select(self._find_tab_index_by_text("Log")))
        
        # Hilfe-Menü
        help_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Hilfe", menu=help_menu)
        help_menu.add_command(label="Dokumentation", command=self._show_documentation)
        help_menu.add_separator()
        help_menu.add_command(label="Über", command=self._show_about)
        
    def _new_search(self):
        """Startet eine neue Suche"""
        # Wechsle zum Suchtab
        self.notebook.select(0)
        
    def _import_persons(self):
        """Importiert Personen in die Personenliste"""
        self.central_person_list._import_persons()
        
    def _export_persons(self):
        """Exportiert die Personenliste"""
        self.central_person_list._export_persons()
        
    def _export_results(self):
        """Exportiert die aktuellen Suchergebnisse"""
        self.results_tab.export_results()
        
    def _show_documentation(self):
        """Zeigt die Dokumentation an"""
        self.logger.info("Dokumentation wird geöffnet...")
        # Implementierung der Dokumentationsanzeige
        messagebox.showinfo("Dokumentation", "Die Dokumentation ist noch in Bearbeitung.")
        
    def _show_about(self):
        """Zeigt Informationen über die Anwendung an"""
        about_window = tk.Toplevel(self)
        about_window.title("Über Medical Spytool")
        about_window.geometry("400x300")
        about_window.resizable(False, False)
        about_window.transient(self)
        about_window.grab_set()
        
        # Header mit Logo (oder Platzhaltertext)
        header_frame = ttk.Frame(about_window)
        header_frame.pack(fill=tk.X, pady=10)
        
        ttk.Label(header_frame, text="Medical Spytool", font=("Helvetica", 16, "bold")).pack()
        
        # Informationsbereich
        info_frame = ttk.Frame(about_window)
        info_frame.pack(fill=tk.BOTH, expand=True, padx=20)
        
        ttk.Label(info_frame, text="Version 1.0.0", font=("Helvetica", 10)).pack(pady=(10, 0))
        ttk.Label(info_frame, text="Ein Tool zur medizinischen Literaturrecherche").pack(pady=(5, 15))
        
        # Trennlinie
        separator = ttk.Separator(info_frame, orient="horizontal")
        separator.pack(fill=tk.X, pady=5)
        
        # Copyright und Entwickler
        ttk.Label(info_frame, text="© 2025").pack(pady=(15, 0))
        ttk.Label(info_frame, text="Entwickelt von: Maximilian Paasch").pack(pady=2)
        ttk.Label(info_frame, text="Medizinische Hochschule Hannover").pack()
        
        # Schließen-Button
        button_frame = ttk.Frame(about_window)
        button_frame.pack(fill=tk.X, pady=15)
        
        ttk.Button(
            button_frame, 
            text="Schließen", 
            command=about_window.destroy, 
            width=15
        ).pack()
        
        # Zentriere das Fenster auf dem Hauptfenster
        about_window.update_idletasks()
        x = self.winfo_x() + (self.winfo_width() - about_window.winfo_width()) // 2
        y = self.winfo_y() + (self.winfo_height() - about_window.winfo_height()) // 2
        about_window.geometry(f"+{x}+{y}")

if __name__ == "__main__":
    app = MainWindow()
    app.mainloop()