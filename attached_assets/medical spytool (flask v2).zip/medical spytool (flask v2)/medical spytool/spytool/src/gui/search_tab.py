"""SearchTab für die Suche in verschiedenen Datenbanken"""
import tkinter as tk
from tkinter import ttk, messagebox
import threading
from datetime import datetime
from tkcalendar import DateEntry
from typing import Dict, List, Callable

from core.config_manager import ConfigManager
from core.logger import Logger
from core.database_service import DatabaseService
from utils.query_builder import QueryBuilder
from .person_list_widget import PersonListWidget

class SearchTab(ttk.Frame):
    def __init__(self, parent, config_manager: ConfigManager, logger: Logger, database_service: DatabaseService, person_list_widget=None):
        super().__init__(parent)
        self.config_manager = config_manager
        self.logger = logger
        self.database_service = database_service
        self.results_callback = None
        self.databases = database_service.get_all_databases()
        self.all_selected = True  # Standardmäßig alle Datenbanken auswählen
        self.person_list = person_list_widget  # Verwende die übergebene PersonListWidget
        
        self._create_widgets()
        
    def _create_widgets(self):
        """Erstellt die GUI-Elemente"""
        # Hauptrahmen mit Scrollbars
        main_canvas = tk.Canvas(self)
        main_scrollbar = ttk.Scrollbar(self, orient="vertical", command=main_canvas.yview)
        main_scrollable_frame = ttk.Frame(main_canvas)
        
        main_scrollable_frame.bind(
            "<Configure>",
            lambda e: main_canvas.configure(
                scrollregion=main_canvas.bbox("all")
            )
        )
        
        main_canvas.create_window((0, 0), window=main_scrollable_frame, anchor="nw")
        main_canvas.configure(yscrollcommand=main_scrollbar.set)
        
        main_canvas.pack(side="left", fill="both", expand=True)
        main_scrollbar.pack(side="right", fill="y")
        
        # Suchoptionen Frame
        search_frame = ttk.LabelFrame(main_scrollable_frame, text="Suchoptionen")
        search_frame.pack(fill=tk.X, padx=5, pady=5)
        
        # Suchbegriff
        search_term_frame = ttk.Frame(search_frame)
        search_term_frame.pack(fill=tk.X, padx=5, pady=5)
        
        ttk.Label(search_term_frame, text="Zusätzlicher Suchbegriff (optional):").pack(side=tk.LEFT, padx=5)
        self.search_term = ttk.Entry(search_term_frame, width=50)
        self.search_term.pack(side=tk.LEFT, padx=5, fill=tk.X, expand=True)
        ttk.Button(search_term_frame, text="Löschen", command=self._clear_search_term).pack(side=tk.RIGHT, padx=5)
        
        # Datenbankauswahl
        db_frame = ttk.Frame(search_frame)
        db_frame.pack(fill=tk.X, padx=5, pady=5)
        
        db_label_frame = ttk.Frame(db_frame)
        db_label_frame.pack(side=tk.LEFT, fill=tk.X)
        ttk.Label(db_label_frame, text="Datenbanken:").pack(side=tk.LEFT, padx=5)
        ttk.Button(
            db_label_frame, 
            text="Alle auswählen/abwählen", 
            command=self._toggle_all_databases
        ).pack(side=tk.LEFT, padx=5)
        
        # Checkboxen für Datenbanken
        self.db_vars = {}
        self.db_checkboxes = {}
        
        db_checkboxes_frame = ttk.Frame(db_frame)
        db_checkboxes_frame.pack(side=tk.LEFT, padx=20)
        
        for i, db_name in enumerate(self.databases.keys()):
            self.db_vars[db_name] = tk.BooleanVar(value=True)
            self.db_checkboxes[db_name] = ttk.Checkbutton(
                db_checkboxes_frame,
                text=db_name.capitalize(),
                variable=self.db_vars[db_name]
            )
            self.db_checkboxes[db_name].grid(row=0, column=i, padx=10, pady=5)
        
        # Filter-Optionen
        filter_frame = ttk.LabelFrame(search_frame, text="Filter")
        filter_frame.pack(fill=tk.X, padx=5, pady=5)
        
        # Datumsfilter / Jahresbereich
        date_frame = ttk.Frame(filter_frame)
        date_frame.pack(fill=tk.X, pady=5)
        
        # Checkbox zum Aktivieren/Deaktivieren des Datumsfilters
        self.use_date_filter = tk.BooleanVar(value=False)
        self.date_filter_cb = ttk.Checkbutton(
            date_frame, 
            text="Jahresfilter verwenden", 
            variable=self.use_date_filter,
            command=self._toggle_date_filter
        )
        self.date_filter_cb.pack(side=tk.LEFT, padx=5)
        
        # Von-Jahr
        self.date_from_label = ttk.Label(date_frame, text="Von Jahr:")
        self.date_from_label.pack(side=tk.LEFT, padx=(15, 5))
        current_year = datetime.now().year
        self.year_from = ttk.Spinbox(
            date_frame,
            from_=1900,
            to=current_year,
            width=6,
            state="disabled"
        )
        self.year_from.delete(0, tk.END)
        self.year_from.insert(0, str(current_year - 5))  # Default: 5 Jahre zurück
        self.year_from.pack(side=tk.LEFT, padx=5)
        
        # Bis-Jahr
        self.date_to_label = ttk.Label(date_frame, text="Bis Jahr:")
        self.date_to_label.pack(side=tk.LEFT, padx=(15, 5))
        self.year_to = ttk.Spinbox(
            date_frame,
            from_=1900,
            to=current_year,
            width=6,
            state="disabled"
        )
        self.year_to.delete(0, tk.END)
        self.year_to.insert(0, str(current_year))  # Default: aktuelles Jahr
        self.year_to.pack(side=tk.LEFT, padx=5)
        
        # Sprache
        language_frame = ttk.Frame(filter_frame)
        language_frame.pack(fill=tk.X, pady=5)
        
        ttk.Label(language_frame, text="Sprache:").pack(side=tk.LEFT, padx=5)
        self.language = ttk.Combobox(language_frame, values=["Alle", "Deutsch", "Englisch"], width=15)
        self.language.current(0)  # "Alle" auswählen
        self.language.pack(side=tk.LEFT, padx=5)
        
        # Reset-Button für Filter
        ttk.Button(filter_frame, text="Filter zurücksetzen", 
                  command=self._reset_filters).pack(side=tk.RIGHT, padx=20, pady=5)
        
        # Maximale Ergebnisse
        max_results_frame = ttk.Frame(search_frame)
        max_results_frame.pack(fill=tk.X, pady=5)
        
        ttk.Label(max_results_frame, text="Max. Ergebnisse pro Datenbank:").pack(side=tk.LEFT, padx=5)
        self.max_results = ttk.Spinbox(max_results_frame, from_=10, to=500, increment=10, width=5)
        self.max_results.delete(0, tk.END)
        self.max_results.insert(0, "100")
        self.max_results.pack(side=tk.LEFT, padx=5)
        
        # Buttons
        button_frame = ttk.Frame(search_frame)
        button_frame.pack(fill=tk.X, pady=10)
        
        ttk.Button(button_frame, text="Suche starten", 
                  command=self._start_search).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="Suche in allen Datenbanken", 
                  command=self._search_all).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="Personensuche", 
                  command=self._start_person_search).pack(side=tk.LEFT, padx=5)
        
        # Fortschrittsanzeige
        progress_frame = ttk.LabelFrame(main_scrollable_frame, text="Fortschritt")
        progress_frame.pack(fill=tk.X, padx=5, pady=5)
        
        # Gesamtfortschritt
        ttk.Label(progress_frame, text="Gesamtfortschritt:").pack(anchor=tk.W, padx=5, pady=5)
        self.total_progress = ttk.Progressbar(progress_frame, orient="horizontal", length=300, mode="determinate")
        self.total_progress.pack(fill=tk.X, padx=5, pady=5)
        
        # Aktueller Fortschritt
        ttk.Label(progress_frame, text="Aktueller Suchvorgang:").pack(anchor=tk.W, padx=5, pady=5)
        self.current_progress = ttk.Progressbar(progress_frame, orient="horizontal", length=300, mode="determinate")
        self.current_progress.pack(fill=tk.X, padx=5, pady=5)
        
        # Status
        self.progress_var = tk.StringVar(value="Bereit")
        status_frame = ttk.Frame(progress_frame)
        status_frame.pack(fill=tk.X, pady=5)
        
        ttk.Label(status_frame, text="Status:").pack(side=tk.LEFT, padx=5)
        ttk.Label(status_frame, textvariable=self.progress_var).pack(side=tk.LEFT, padx=5)
        
        # Logausgabe
        log_frame = ttk.LabelFrame(main_scrollable_frame, text="Protokoll")
        log_frame.pack(fill=tk.BOTH, expand=True, pady=5)
        
        self.log_text = tk.Text(log_frame, wrap=tk.WORD, height=10)
        log_scrollbar = ttk.Scrollbar(log_frame, orient="vertical", command=self.log_text.yview)
        self.log_text.configure(yscrollcommand=log_scrollbar.set)
        
        self.log_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=5, pady=5)
        log_scrollbar.pack(side=tk.RIGHT, fill=tk.Y, padx=(0, 5), pady=5)
        
        # Log mit aktuellem Zeitstempel ausgeben
        def log_message(message):
            current_time = datetime.now().strftime("%H:%M:%S")
            self.log_text.insert(tk.END, f"[{current_time}] {message}\n")
            self.log_text.see(tk.END)  # Scrolle zum Ende
            self.logger.info(f"[Suche] {message}")
        
        self.log = log_message
        self.log("Suchmodul initialisiert")
        
    def _toggle_date_filter(self):
        """Aktiviert oder deaktiviert die Datumsauswahlfelder"""
        if self.use_date_filter.get():
            self.year_from.config(state="normal")
            self.year_to.config(state="normal")
        else:
            self.year_from.config(state="disabled")
            self.year_to.config(state="disabled")
            
    def set_results_callback(self, callback: Callable):
        """Setzt den Callback für Suchergebnisse"""
        self.results_callback = callback
    
    def _clear_search_term(self):
        """Leert das Suchbegriffsfeld"""
        self.search_term.delete(0, tk.END)
        
    def _reset_filters(self):
        """Setzt alle Filter zurück"""
        current_year = datetime.now().year
        
        self.use_date_filter.set(False)
        self._toggle_date_filter()
        
        self.year_from.delete(0, tk.END)
        self.year_from.insert(0, str(current_year - 5))
        
        self.year_to.delete(0, tk.END)
        self.year_to.insert(0, str(current_year))
        
        self.language.current(0)  # "Alle" auswählen
        
    def _toggle_all_databases(self):
        """Wechselt zwischen Auswahl aller und keiner Datenbanken"""
        self.all_selected = not self.all_selected
        for var in self.db_vars.values():
            var.set(self.all_selected)
    
    def _search_all(self):
        """Startet die Suche in allen Datenbanken, unabhängig von der aktuellen Auswahl"""
        # Überprüfen, ob Personen ausgewählt sind
        persons = self.person_list.get_selected_persons()
        if persons:
            # Suche mit ausgewählten Personen
            self._start_person_search()
        else:
            # Vorübergehend alle Datenbanken auswählen für normale Suche
            original_states = {db: var.get() for db, var in self.db_vars.items()}
            
            try:
                # Alle auswählen
                for var in self.db_vars.values():
                    var.set(True)
                
                # Suche starten
                self._start_search()
            finally:
                # Ursprünglichen Zustand wiederherstellen
                for db, state in original_states.items():
                    self.db_vars[db].set(state)
        
    def _start_search(self):
        """Startet die Suche in den ausgewählten Datenbanken"""
        # Hole Suchbegriff
        search_term = self.search_term.get().strip()
        # Überprüfen, ob Personen ausgewählt sind - falls ja, Personensuche starten
        persons = self.person_list.get_selected_persons()
        if persons:
            self._start_person_search()
            return
            
        # Für normale Suche (ohne Personen) ist ein Suchbegriff erforderlich
        if not search_term:
            self.logger.warning("Bitte geben Sie einen Suchbegriff ein oder wählen Sie Personen für die Suche aus")
            messagebox.showwarning("Warnung", "Bitte geben Sie einen Suchbegriff ein oder wählen Sie Personen für die Suche aus")
            return
            
        # Hole ausgewählte Datenbanken
        selected_dbs = [
            db_name for db_name, var in self.db_vars.items()
            if var.get()
        ]
        
        if not selected_dbs:
            self.logger.warning("Bitte wählen Sie mindestens eine Datenbank aus")
            messagebox.showwarning("Warnung", "Bitte wählen Sie mindestens eine Datenbank aus")
            return
            
        # Erstelle Such-Filter
        filters = {
            "language": self.language.get()
        }
        
        # Jahresfilter, wenn aktiviert
        if self.use_date_filter.get():
            try:
                year_from = int(self.year_from.get())
                year_to = int(self.year_to.get())
                filters["year_from"] = str(year_from)
                filters["year_to"] = str(year_to)
            except ValueError:
                self.logger.warning("Ungültige Jahresangaben")
                messagebox.showwarning("Warnung", "Bitte geben Sie gültige Jahresangaben ein")
                return
        
        # Maximale Ergebnisse
        try:
            max_results = int(self.max_results.get())
            if max_results < 1:
                raise ValueError("Max. Ergebnisse muss mindestens 1 sein")
        except ValueError:
            self.logger.warning("Ungültige Anzahl von max. Ergebnissen")
            messagebox.showwarning("Warnung", "Bitte geben Sie eine gültige Anzahl für max. Ergebnisse ein")
            return
        
        # Fortschrittsanzeige zurücksetzen
        self.total_progress["value"] = 0
        self.current_progress["value"] = 0
        
        # Starte Suche in separatem Thread
        threading.Thread(
            target=self._execute_search,
            args=(search_term, selected_dbs, filters, max_results),
            daemon=True
        ).start()
    
    def _start_person_search(self):
        """Startet die Suche für ausgewählte Personen in den ausgewählten Datenbanken"""
        # Hole ausgewählte Personen
        persons = self.person_list.get_selected_persons()
        if not persons:
            self.logger.warning("Bitte wählen Sie mindestens eine Person aus")
            messagebox.showwarning("Warnung", "Bitte wählen Sie mindestens eine Person aus")
            return
        
        # Hole ausgewählte Datenbanken
        selected_dbs = [
            db_name for db_name, var in self.db_vars.items()
            if var.get()
        ]
        
        if not selected_dbs:
            self.logger.warning("Bitte wählen Sie mindestens eine Datenbank aus")
            messagebox.showwarning("Warnung", "Bitte wählen Sie mindestens eine Datenbank aus")
            return
        
        # Zusätzlicher Suchbegriff (optional)
        additional_term = self.search_term.get().strip()
        
        # Erstelle Such-Filter
        filters = {
            "language": self.language.get()
        }
        
        # Jahresfilter, wenn aktiviert
        if self.use_date_filter.get():
            try:
                year_from = int(self.year_from.get())
                year_to = int(self.year_to.get())
                filters["year_from"] = str(year_from)
                filters["year_to"] = str(year_to)
            except ValueError:
                self.logger.warning("Ungültige Jahresangaben")
                messagebox.showwarning("Warnung", "Bitte geben Sie gültige Jahresangaben ein")
                return
        
        # Maximale Ergebnisse
        try:
            max_results = int(self.max_results.get())
            if max_results < 1:
                raise ValueError("Max. Ergebnisse muss mindestens 1 sein")
        except ValueError:
            self.logger.warning("Ungültige Anzahl von max. Ergebnissen")
            messagebox.showwarning("Warnung", "Bitte geben Sie eine gültige Anzahl für max. Ergebnisse ein")
            return
        
        # Fortschrittsanzeige zurücksetzen
        self.total_progress["value"] = 0
        self.current_progress["value"] = 0
        
        # Starte Suche in separatem Thread
        threading.Thread(
            target=self._execute_person_search,
            args=(persons, additional_term, selected_dbs, filters, max_results),
            daemon=True
        ).start()
        
    def _execute_search(self, search_term: str, databases: List[str], filters: Dict, max_results: int):
        """Führt die Suche aus"""
        try:
            all_results = []
            total_dbs = len(databases)
            
            for i, db_name in enumerate(databases):
                self.progress_var.set(f"Suche in {db_name.upper()}...")
                self.total_progress["value"] = int((i / total_dbs) * 100)
                self.current_progress["value"] = 0
                
                try:
                    # Nutze die DatabaseService.search_database Methode für einheitliche Suche
                    self.log(f"Starte Suche in {db_name} mit Suchbegriff: {search_term}")
                    results = self.database_service.search_database(
                        db_name, 
                        search_term, 
                        filters=filters,
                        max_results=max_results
                    )
                    
                    all_results.extend(results)
                    self.log(f"Suche in {db_name}: {len(results)} Ergebnisse gefunden")
                    self.current_progress["value"] = 100
                    
                except Exception as e:
                    error_msg = f"Fehler bei der Suche in {db_name}: {e}"
                    self.log(error_msg)
                    self.logger.error(error_msg)
            
            # Fortschritt auf 100% setzen
            self.total_progress["value"] = 100
                    
            if self.results_callback:
                self.results_callback(all_results)
                
            self.progress_var.set(
                f"Suche abgeschlossen. {len(all_results)} Ergebnisse gefunden."
            )
            
        except Exception as e:
            self.logger.error(f"Fehler bei der Suche: {e}")
            self.progress_var.set("Fehler bei der Suche")
            
    def _execute_person_search(self, persons: List[Dict], additional_term: str, 
                              databases: List[str], filters: Dict, max_results: int):
        """Führt die Suche für alle ausgewählten Personen durch"""
        try:
            self.logger.info(f"Starte Personensuche für {len(persons)} Personen in {len(databases)} Datenbanken")
            all_results = []
            total_persons = len(persons)
            
            for p_idx, person in enumerate(persons):
                person_name = f"{person['firstname']} {person['lastname']}"
                self.log(f"Starte Suche für Person: {person_name}")
                
                # Aktualisiere den Gesamtfortschritt für diese Person
                self.total_progress["value"] = int((p_idx / total_persons) * 100)
                
                # Ergebnisse für diese Person über alle ausgewählten Datenbanken sammeln
                person_results = []
                
                # Direkten Aufruf der search_person Methode für alle ausgewählten Datenbanken
                self.log(f"Suche nach {person_name} in allen ausgewählten Datenbanken...")
                self.progress_var.set(f"Suche nach {person_name}...")
                self.current_progress["value"] = 30
                
                try:
                    # Direkte Nutzung der database_service.search_person Methode für alle Datenbanken
                    person_results = self.database_service.search_person(
                        firstname=person['firstname'],
                        lastname=person['lastname'],
                        additional_terms=additional_term,
                        filters=filters,
                        max_results=max_results
                    )
                    
                    # Log-Ausgabe über Ergebniszahlen pro Datenbank
                    db_result_counts = {}
                    for result in person_results:
                        source = result.get("source", "unbekannt")
                        db_result_counts[source] = db_result_counts.get(source, 0) + 1
                    
                    for db_name, count in db_result_counts.items():
                        self.log(f"{count} Ergebnisse für {person_name} in {db_name} gefunden")
                        
                    # Aktualisiere Fortschritt
                    self.current_progress["value"] = 100
                    all_results.extend(person_results)
                    
                except Exception as e:
                    error_msg = f"Fehler bei der Suche nach {person_name}: {e}"
                    self.log(error_msg)
                    self.logger.error(error_msg)
            
            # Suchvorgang abgeschlossen
            self.total_progress["value"] = 100
            self.progress_var.set(f"Fertig: {len(all_results)} Ergebnisse insgesamt")
            self.log(f"Suchvorgang abgeschlossen. Insgesamt {len(all_results)} Ergebnisse gefunden.")
            
            # Rufe den Callback auf, wenn Ergebnisse gefunden wurden
            if all_results and self.results_callback:
                self.results_callback(all_results)
                self.log("Ergebnisse wurden an die Ergebnisansicht übermittelt.")
                
        except Exception as e:
            error_msg = f"Unerwarteter Fehler bei der Personensuche: {e}"
            self.log(error_msg)
            self.logger.error(error_msg)
            self.progress_var.set("Fehler bei der Suche")