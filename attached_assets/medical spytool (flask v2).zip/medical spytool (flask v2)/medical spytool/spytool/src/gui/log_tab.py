"""LogTab für die Anzeige von Protokolleinträgen"""
import tkinter as tk
from tkinter import ttk
import time
from core.logger import Logger

class LogTab(ttk.Frame):
    def __init__(self, parent, logger: Logger):
        super().__init__(parent)
        self.logger = logger
        self.auto_scroll = True
        self._create_widgets()
        self._setup_logger_handlers()
        self._update_logs()
        
    def _create_widgets(self):
        """Erstellt die GUI-Elemente"""
        # Erstelle Notebook für einfachen und detaillierten Log
        self.log_notebook = ttk.Notebook(self)
        self.log_notebook.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Tab für detaillierten Log
        self.detailed_tab = ttk.Frame(self.log_notebook)
        self.log_notebook.add(self.detailed_tab, text="Detailliertes Protokoll")
        
        # Tab für einfachen Log (Prozessschritte)
        self.simple_tab = ttk.Frame(self.log_notebook)
        self.log_notebook.add(self.simple_tab, text="Einfaches Protokoll")
        
        # Erstelle Widgets für detaillierten Log
        self._create_log_view(self.detailed_tab, "detailed")
        
        # Erstelle Widgets für einfachen Log
        self._create_log_view(self.simple_tab, "simple")
        
    def _create_log_view(self, parent, log_type):
        """Erstellt die Log-Ansicht für einen Tab-Typ
        
        Args:
            parent: Das übergeordnete Widget
            log_type: "simple" oder "detailed" als Log-Typ
        """
        # Toolbar
        toolbar = ttk.Frame(parent)
        toolbar.pack(fill=tk.X, padx=5, pady=5)
        
        # Level-Filter
        ttk.Label(toolbar, text="Log-Level:").pack(side=tk.LEFT, padx=5)
        level_var = tk.StringVar(value="INFO")
        level_combo = ttk.Combobox(
            toolbar, 
            textvariable=level_var,
            values=["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"],
            width=10,
            state="readonly"
        )
        level_combo.pack(side=tk.LEFT, padx=5)
        
        # Suchfeld
        ttk.Label(toolbar, text="Filter:").pack(side=tk.LEFT, padx=10)
        search_var = tk.StringVar()
        search_entry = ttk.Entry(toolbar, textvariable=search_var, width=25)
        search_entry.pack(side=tk.LEFT, padx=5)
        
        # Auto-Scroll-Option
        auto_scroll_var = tk.BooleanVar(value=True)
        auto_scroll_check = ttk.Checkbutton(
            toolbar,
            text="Auto-Scroll",
            variable=auto_scroll_var
        )
        auto_scroll_check.pack(side=tk.LEFT, padx=20)
        
        # Copy-Button
        copy_button = ttk.Button(toolbar, text="Protokoll kopieren")
        copy_button.pack(side=tk.RIGHT, padx=5)
        
        # Clear-Button
        clear_button = ttk.Button(toolbar, text="Logs löschen")
        clear_button.pack(side=tk.RIGHT, padx=5)
        
        # Log-Anzeige mit Scrollbar
        log_frame = ttk.Frame(parent)
        log_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Erstelle Treeview für Log-Einträge
        log_tree = ttk.Treeview(
            log_frame,
            columns=("time", "level", "message"),
            show="headings",
            selectmode="extended"
        )
        
        # Spaltenüberschriften
        log_tree.heading("time", text="Zeit")
        log_tree.heading("level", text="Level")
        log_tree.heading("message", text="Nachricht")
        
        # Spaltenbreiten
        log_tree.column("time", width=150, minwidth=100)
        log_tree.column("level", width=80, minwidth=60)
        log_tree.column("message", width=800, minwidth=200)
        
        # Scrollbars
        vsb = ttk.Scrollbar(log_frame, orient="vertical", command=log_tree.yview)
        hsb = ttk.Scrollbar(log_frame, orient="horizontal", command=log_tree.xview)
        log_tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        
        # Layout der Scrollbars
        log_tree.grid(column=0, row=0, sticky="nsew")
        vsb.grid(column=1, row=0, sticky="ns")
        hsb.grid(column=0, row=1, sticky="ew")
        
        # Konfiguriere Tabellenrahmen zum Expandieren
        log_frame.columnconfigure(0, weight=1)
        log_frame.rowconfigure(0, weight=1)
        
        # Kontext-Menü für Rechtsklick
        context_menu = tk.Menu(parent, tearoff=0)
        context_menu.add_command(label="Kopieren")
        context_menu.add_separator()
        context_menu.add_command(label="Auswahl löschen")
        
        # Status-Leiste
        status_var = tk.StringVar(value="0 Log-Einträge")
        status_bar = ttk.Label(parent, textvariable=status_var, anchor=tk.W)
        status_bar.pack(side=tk.BOTTOM, fill=tk.X, padx=5, pady=2)
        
        # Färbe Einträge je nach Level
        log_tree.tag_configure("error", background="#ffcccc")
        log_tree.tag_configure("warning", background="#ffffcc")
        
        # Speichere Referenzen
        if log_type == "detailed":
            self.detailed_log_tree = log_tree
            self.detailed_level_var = level_var
            self.detailed_search_var = search_var
            self.detailed_auto_scroll_var = auto_scroll_var
            self.detailed_status_var = status_var
            self.detailed_context_menu = context_menu
            self.detailed_log_entries = []
            self.detailed_filtered_logs = []
            
            # Konfiguriere Ereignisse
            level_combo.bind("<<ComboboxSelected>>", lambda e: self._filter_logs("detailed"))
            search_var.trace("w", lambda *args: self._filter_logs("detailed"))
            auto_scroll_check.config(command=lambda: self._toggle_auto_scroll("detailed"))
            clear_button.config(command=lambda: self._clear_logs("detailed"))
            log_tree.bind("<Button-3>", lambda e: self._show_context_menu(e, "detailed"))
            copy_button.config(command=lambda: self._copy_all_logs("detailed"))
            
            # Konfiguriere Kontextmenü
            context_menu.entryconfigure("Kopieren", command=lambda: self._copy_selected("detailed"))
            context_menu.entryconfigure("Auswahl löschen", command=lambda: self._delete_selected("detailed"))
        else:
            self.simple_log_tree = log_tree
            self.simple_level_var = level_var
            self.simple_search_var = search_var
            self.simple_auto_scroll_var = auto_scroll_var
            self.simple_status_var = status_var
            self.simple_context_menu = context_menu
            self.simple_log_entries = []
            self.simple_filtered_logs = []
            
            # Konfiguriere Ereignisse
            level_combo.bind("<<ComboboxSelected>>", lambda e: self._filter_logs("simple"))
            search_var.trace("w", lambda *args: self._filter_logs("simple"))
            auto_scroll_check.config(command=lambda: self._toggle_auto_scroll("simple"))
            clear_button.config(command=lambda: self._clear_logs("simple"))
            log_tree.bind("<Button-3>", lambda e: self._show_context_menu(e, "simple"))
            copy_button.config(command=lambda: self._copy_all_logs("simple"))
            
            # Konfiguriere Kontextmenü
            context_menu.entryconfigure("Kopieren", command=lambda: self._copy_selected("simple"))
            context_menu.entryconfigure("Auswahl löschen", command=lambda: self._delete_selected("simple"))
        
    def _setup_logger_handlers(self):
        """Konfiguriert den Logger, um Einträge zu erfassen"""
        self.logger.add_gui_handler(self._add_detailed_log_entry, "detailed")
        self.logger.add_gui_handler(self._add_simple_log_entry, "simple")
        
    def _add_detailed_log_entry(self, log_time, level, message):
        """Fügt einen neuen detaillierten Log-Eintrag hinzu"""
        entry = {
            "time": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(log_time)),
            "level": level,
            "message": message
        }
        self.detailed_log_entries.append(entry)
        # Aktualisierung erfolgt durch _update_logs
        
    def _add_simple_log_entry(self, log_time, level, message):
        """Fügt einen neuen einfachen Log-Eintrag hinzu"""
        entry = {
            "time": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(log_time)),
            "level": level,
            "message": message
        }
        self.simple_log_entries.append(entry)
        # Aktualisierung erfolgt durch _update_logs
        
    def _update_logs(self):
        """Aktualisiert die Log-Anzeige periodisch"""
        self._filter_logs("detailed")
        self._filter_logs("simple")
        self.after(500, self._update_logs)  # Alle 500ms aktualisieren
        
    def _filter_logs(self, log_type):
        """Filtert die Log-Einträge basierend auf Level und Suchtext
        
        Args:
            log_type: "simple" oder "detailed" als Log-Typ
        """
        # Definiere Log-Level-Hierarchie für Filter
        level_order = {
            "DEBUG": 0,
            "INFO": 1,
            "WARNING": 2,
            "ERROR": 3,
            "CRITICAL": 4
        }
        
        if log_type == "detailed":
            # Hole aktuellen Filter
            selected_level = self.detailed_level_var.get()
            search_text = self.detailed_search_var.get().lower()
            min_level = level_order.get(selected_level, 0)
            
            # Filtere Logs
            self.detailed_filtered_logs = [
                log for log in self.detailed_log_entries
                if level_order.get(log["level"], 0) >= min_level
                and (not search_text or search_text in log["message"].lower())
            ]
            
            # Aktualisiere Anzeige
            self._update_display("detailed")
        else:
            # Hole aktuellen Filter
            selected_level = self.simple_level_var.get()
            search_text = self.simple_search_var.get().lower()
            min_level = level_order.get(selected_level, 0)
            
            # Filtere Logs
            self.simple_filtered_logs = [
                log for log in self.simple_log_entries
                if level_order.get(log["level"], 0) >= min_level
                and (not search_text or search_text in log["message"].lower())
            ]
            
            # Aktualisiere Anzeige
            self._update_display("simple")
        
    def _update_display(self, log_type):
        """Aktualisiert die Treeview-Anzeige mit den gefilterten Logs
        
        Args:
            log_type: "simple" oder "detailed" als Log-Typ
        """
        if log_type == "detailed":
            log_tree = self.detailed_log_tree
            filtered_logs = self.detailed_filtered_logs
            all_logs = self.detailed_log_entries
            auto_scroll = self.detailed_auto_scroll_var.get()
            status_var = self.detailed_status_var
        else:
            log_tree = self.simple_log_tree
            filtered_logs = self.simple_filtered_logs
            all_logs = self.simple_log_entries
            auto_scroll = self.simple_auto_scroll_var.get()
            status_var = self.simple_status_var
            
        # Alte Anzeige löschen
        for item in log_tree.get_children():
            log_tree.delete(item)
            
        # Neue Einträge hinzufügen
        for log in filtered_logs:
            item_id = log_tree.insert(
                "",
                tk.END,
                values=(log["time"], log["level"], log["message"])
            )
            
            # Färbe Einträge je nach Level
            if log["level"] == "ERROR" or log["level"] == "CRITICAL":
                log_tree.item(item_id, tags=("error",))
            elif log["level"] == "WARNING":
                log_tree.item(item_id, tags=("warning",))
                
        # Auto-Scroll zum Ende
        if auto_scroll and filtered_logs:
            last_item = log_tree.get_children()[-1]
            log_tree.see(last_item)
            
        # Status-Update
        status_var.set(f"{len(filtered_logs)} von {len(all_logs)} Log-Einträgen")
            
    def _toggle_auto_scroll(self, log_type):
        """Schaltet das automatische Scrollen ein/aus
        
        Args:
            log_type: "simple" oder "detailed" als Log-Typ
        """
        if log_type == "detailed":
            self.detailed_auto_scroll = self.detailed_auto_scroll_var.get()
        else:
            self.simple_auto_scroll = self.simple_auto_scroll_var.get()
        
    def _clear_logs(self, log_type):
        """Löscht alle Log-Einträge
        
        Args:
            log_type: "simple" oder "detailed" als Log-Typ
        """
        if log_type == "detailed":
            self.detailed_log_entries = []
            self.detailed_filtered_logs = []
        else:
            self.simple_log_entries = []
            self.simple_filtered_logs = []
            
        self._update_display(log_type)
        
    def _show_context_menu(self, event, log_type):
        """Zeigt das Kontextmenü an
        
        Args:
            event: Das Event-Objekt
            log_type: "simple" oder "detailed" als Log-Typ
        """
        try:
            if log_type == "detailed":
                self.detailed_context_menu.tk_popup(event.x_root, event.y_root)
            else:
                self.simple_context_menu.tk_popup(event.x_root, event.y_root)
        finally:
            if log_type == "detailed":
                self.detailed_context_menu.grab_release()
            else:
                self.simple_context_menu.grab_release()
            
    def _copy_selected(self, log_type):
        """Kopiert ausgewählte Log-Einträge in die Zwischenablage
        
        Args:
            log_type: "simple" oder "detailed" als Log-Typ
        """
        if log_type == "detailed":
            log_tree = self.detailed_log_tree
        else:
            log_tree = self.simple_log_tree
            
        selected_items = log_tree.selection()
        if not selected_items:
            return
            
        # Erstelle Text für Zwischenablage
        copy_text = ""
        for item in selected_items:
            values = log_tree.item(item, "values")
            copy_text += f"{values[0]} [{values[1]}] {values[2]}\n"
            
        # In Zwischenablage kopieren
        self.clipboard_clear()
        self.clipboard_append(copy_text)
        self.logger.info(f"{len(selected_items)} Log-Einträge wurden in die Zwischenablage kopiert")
        
    def _copy_all_logs(self, log_type):
        """Kopiert alle aktuell gefilterten Log-Einträge in die Zwischenablage
        
        Args:
            log_type: "simple" oder "detailed" als Log-Typ
        """
        if log_type == "detailed":
            logs = self.detailed_filtered_logs
        else:
            logs = self.simple_filtered_logs
            
        if not logs:
            self.logger.info("Keine Log-Einträge zum Kopieren vorhanden")
            return
            
        # Erstelle Text für Zwischenablage
        copy_text = ""
        for log in logs:
            copy_text += f"{log['time']} [{log['level']}] {log['message']}\n"
            
        # In Zwischenablage kopieren
        self.clipboard_clear()
        self.clipboard_append(copy_text)
        self.logger.info(f"{len(logs)} Log-Einträge wurden in die Zwischenablage kopiert")
        
    def _delete_selected(self, log_type):
        """Löscht ausgewählte Log-Einträge
        
        Args:
            log_type: "simple" oder "detailed" als Log-Typ
        """
        if log_type == "detailed":
            log_tree = self.detailed_log_tree
            filtered_logs = self.detailed_filtered_logs
            all_logs = self.detailed_log_entries
        else:
            log_tree = self.simple_log_tree
            filtered_logs = self.simple_filtered_logs
            all_logs = self.simple_log_entries
            
        selected_items = log_tree.selection()
        if not selected_items:
            return
            
        # Entferne ausgewählte Einträge
        indices_to_remove = []
        for item in selected_items:
            idx = log_tree.index(item)
            if idx < len(filtered_logs):
                log_to_remove = filtered_logs[idx]
                if log_to_remove in all_logs:
                    indices_to_remove.append(all_logs.index(log_to_remove))
                
        # Lösche von hinten nach vorne, um Indexverschiebungen zu vermeiden
        for idx in sorted(indices_to_remove, reverse=True):
            if idx < len(all_logs):
                del all_logs[idx]
                
        # Aktualisiere die Anzeige
        self._filter_logs(log_type)