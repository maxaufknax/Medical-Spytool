from typing import Dict, List
from core.logger import Logger
from core.config_manager import ConfigManager
from databases.pubmed import PubMedDatabase
from databases.dnb import DNBDatabase
from databases.wos import WoSDatabase
from databases.scopus import ScopusDatabase
from databases.gepris import GeprisDatabase
from utils.mock_data import MockDataProvider
from utils.query_builder import QueryBuilder

class DatabaseService:
    def __init__(self, config_manager: ConfigManager, logger: Logger):
        self.config_manager = config_manager
        self.logger = logger
        self.databases: Dict = {}
        self.mock_data_provider = MockDataProvider()
        self.use_mock_data = False
        self._init_databases()
        
    def _init_databases(self):
        """Initialisiert alle Datenbankmodule"""
        config = self.config_manager.get_config()
        api_keys = config.get("api_keys", {})
        
        # Check if we should use mock data (for testing without API keys)
        self.use_mock_data = config.get("development", {}).get("use_mock_data", False)
        if self.use_mock_data:
            self.logger.info("Test-Modus ist aktiv: Verwende Mock-Daten für Datenbankabfragen")
        
        try:
            pubmed_db = PubMedDatabase(api_keys.get("pubmed", ""))
            
            dnb_db = DNBDatabase()
            if "dnb" in api_keys and api_keys["dnb"]:
                dnb_db.access_token = api_keys["dnb"]
            
            wos_db = WoSDatabase()
            if "wos" in api_keys and api_keys["wos"]:
                wos_db.api_key = api_keys["wos"]
            
            scopus_db = ScopusDatabase()
            if "scopus" in api_keys and api_keys["scopus"]:
                scopus_db.api_key = api_keys["scopus"]
                
            gepris_db = GeprisDatabase()
            if "gepris" in api_keys and api_keys["gepris"]:
                gepris_db.api_key = api_keys["gepris"]
            
            self.databases = {
                "pubmed": pubmed_db,
                "dnb": dnb_db,
                "wos": wos_db,
                "scopus": scopus_db,
                "gepris": gepris_db
            }
            self.logger.info("Datenbank-Services erfolgreich initialisiert")
        except Exception as e:
            self.logger.error(f"Fehler bei der Initialisierung der Datenbanken: {e}")
            
    def get_database(self, name: str):
        """Gibt eine Datenbankinstanz zurück"""
        return self.databases.get(name)
        
    def get_all_databases(self) -> Dict:
        """Gibt alle verfügbaren Datenbanken zurück"""
        return self.databases
        
    def search_all(self, query: str, filters: Dict = None, max_results: int = 100) -> List[Dict]:
        """
        Führt eine Suche in allen verfügbaren Datenbanken durch
        
        Args:
            query: Die Suchanfrage
            filters: Suchfilter (optional)
            max_results: Maximale Anzahl an Ergebnissen pro Datenbank
            
        Returns:
            Liste mit kombinierten Suchergebnissen
        """
        all_results = []
        
        # Erstelle einen QueryBuilder für die Suchanfrage mit Filtern
        query_builder = QueryBuilder()
        query_builder.add_term(query)
        
        # Füge Filter hinzu, wenn vorhanden
        if filters:
            if "year_from" in filters and "year_to" in filters:
                query_builder.add_year_range(
                    start_year=filters["year_from"],
                    end_year=filters["year_to"]
                )
                
            if "language" in filters and filters["language"] != "Alle":
                query_builder.add_language(filters["language"])
        
        for db_name, db in self.databases.items():
            try:
                # Erstelle datenbankspezifische Abfrage
                db_query = query_builder.build(db_name)
                self.logger.info(f"Suche in {db_name} mit Query: {db_query}")
                
                # Verwende Mock-Daten wenn im Test-Modus
                if self.use_mock_data:
                    results = self.mock_data_provider.get_mock_publications(query, db_name, count=max_results)
                    self.logger.info(f"Test-Modus: Mock-Suche in {db_name}: {len(results)} Ergebnisse generiert")
                else:
                    # Führe die tatsächliche Datenbanksuche durch
                    results = db.search(db_query, max_results)
                    
                    # Füge Datenbankquelle zu jedem Ergebnis hinzu, falls nicht schon gesetzt
                    for result in results:
                        if "source" not in result:
                            result["source"] = db_name
                            
                all_results.extend(results)
                if not self.use_mock_data:
                    self.logger.info(f"Suche in {db_name}: {len(results)} Ergebnisse gefunden")
            except Exception as e:
                self.logger.error(f"Fehler bei der Suche in {db_name}: {e}")
                # Bei einem Fehler im Live-Modus, versuche es mit Mock-Daten als Fallback
                if not self.use_mock_data:
                    self.logger.warning(f"Verwende Mock-Daten als Fallback für {db_name}")
                    fallback_results = self.mock_data_provider.get_mock_publications(
                        query, db_name, count=max_results
                    )
                    for result in fallback_results:
                        result["is_mock"] = True  # Markiere als Mock-Daten
                        result["source"] = db_name
                    all_results.extend(fallback_results)
                
        return all_results
        
    def search_database(self, db_name: str, query: str, filters: Dict = None, max_results: int = 100) -> List[Dict]:
        """
        Führt eine Suche in einer bestimmten Datenbank durch
        
        Args:
            db_name: Name der Datenbank
            query: Die Suchanfrage
            filters: Suchfilter (optional)
            max_results: Maximale Anzahl an Ergebnissen
            
        Returns:
            Liste mit Suchergebnissen
        """
        db = self.databases.get(db_name)
        if not db:
            self.logger.error(f"Datenbank {db_name} nicht gefunden")
            return []
            
        try:
            # Erstelle einen QueryBuilder für die Suchanfrage mit Filtern
            query_builder = QueryBuilder()
            query_builder.add_term(query)
            
            # Füge Filter hinzu, wenn vorhanden
            if filters:
                if "year_from" in filters and "year_to" in filters:
                    query_builder.add_year_range(
                        start_year=filters["year_from"],
                        end_year=filters["year_to"]
                    )
                    
                if "language" in filters and filters["language"] != "Alle":
                    query_builder.add_language(filters["language"])
            
            # Erstelle datenbankspezifische Abfrage
            db_query = query_builder.build(db_name)
            self.logger.info(f"Suche in {db_name} mit Query: {db_query}")
            
            # Verwende Mock-Daten wenn im Test-Modus
            if self.use_mock_data:
                results = self.mock_data_provider.get_mock_publications(query, db_name, count=max_results)
                self.logger.info(f"Test-Modus: Mock-Suche in {db_name}: {len(results)} Ergebnisse generiert")
            else:
                # Führe die tatsächliche Datenbanksuche durch
                results = db.search(db_query, max_results)
                
                # Füge Datenbankquelle zu jedem Ergebnis hinzu
                for result in results:
                    if "source" not in result:
                        result["source"] = db_name
                        
            return results
        except Exception as e:
            self.logger.error(f"Fehler bei der Suche in {db_name}: {e}")
            # Bei einem Fehler im Live-Modus, versuche es mit Mock-Daten als Fallback
            if not self.use_mock_data:
                self.logger.warning(f"Verwende Mock-Daten als Fallback für {db_name}")
                fallback_results = self.mock_data_provider.get_mock_publications(query, db_name, count=max_results)
                for result in fallback_results:
                    result["is_mock"] = True  # Markiere als Mock-Daten
                    result["source"] = db_name
                return fallback_results
            return []
            
    def search_person(self, firstname: str, lastname: str, additional_terms: str = None,
                    database: str = None, filters: Dict = None, max_results: int = 100) -> List[Dict]:
        """
        Sucht nach einer Person in einer oder allen Datenbanken
        
        Args:
            firstname: Vorname
            lastname: Nachname
            additional_terms: Zusätzliche Suchbegriffe (optional)
            database: Name der Datenbank (None für alle)
            filters: Suchfilter (optional)
            max_results: Maximale Anzahl an Ergebnissen pro Datenbank
            
        Returns:
            Liste mit Suchergebnissen
        """
        all_results = []
        
        # Erstelle einen QueryBuilder für die Personensuche
        query_builder = QueryBuilder()
        query_builder.add_author(firstname, lastname)
        
        # Füge zusätzliche Suchbegriffe hinzu, wenn vorhanden
        if additional_terms:
            query_builder.add_term(additional_terms)
        
        # Füge Filter hinzu, wenn vorhanden
        if filters:
            if "year_from" in filters and "year_to" in filters:
                query_builder.add_year_range(
                    start_year=filters["year_from"],
                    end_year=filters["year_to"]
                )
                
            if "language" in filters and filters["language"] != "Alle":
                query_builder.add_language(filters["language"])
                
        # Suche in einer bestimmten Datenbank oder allen
        dbs_to_search = {database: self.databases[database]} if database and database in self.databases else self.databases
        
        for db_name, db in dbs_to_search.items():
            try:
                # Erstelle datenbankspezifische Abfrage
                db_query = query_builder.build(db_name)
                self.logger.info(f"Personensuche für {firstname} {lastname} in {db_name} mit Query: {db_query}")
                
                # Verwende Mock-Daten wenn im Test-Modus oder API-Key fehlt
                use_mock = self.use_mock_data
                if not use_mock:
                    # Prüfe auf fehlende API Keys bei bestimmten Datenbanken
                    if db_name == "wos" and not db.api_key:
                        self.logger.warning(f"Kein API-Key für {db_name}. Verwende Mock-Daten.")
                        use_mock = True
                    elif db_name == "scopus" and not db.api_key:
                        self.logger.warning(f"Kein API-Key für {db_name}. Verwende Mock-Daten.")
                        use_mock = True
                    elif db_name == "gepris" and not db.api_key:
                        self.logger.warning(f"Kein API-Key für {db_name}. Verwende Mock-Daten.")
                        use_mock = True
                        
                if use_mock:
                    # Verwende Mock-Daten
                    person_name = f"{firstname} {lastname}"
                    results = self.mock_data_provider.get_mock_publications(
                        person_name, db_name, count=max_results, additional_terms=additional_terms
                    )
                    self.logger.info(f"Mock-Personensuche in {db_name}: {len(results)} Ergebnisse generiert")
                else:
                    # Führe die tatsächliche Datenbanksuche durch
                    results = db.search(db_query, max_results)
                
                # Füge Personeninfo und Datenbankquelle zu jedem Ergebnis hinzu
                for result in results:
                    if "source" not in result:
                        result["source"] = db_name
                    result["searched_person"] = f"{firstname} {lastname}"
                
                all_results.extend(results)
                
                # Logge die Anzahl der Ergebnisse
                if not use_mock:
                    self.logger.info(f"Personensuche in {db_name}: {len(results)} Ergebnisse gefunden")
                
            except Exception as e:
                self.logger.error(f"Fehler bei der Personensuche in {db_name}: {e}")
                # Bei einem Fehler, versuche es mit Mock-Daten als Fallback
                if not self.use_mock_data:
                    self.logger.warning(f"Verwende Mock-Daten als Fallback für {db_name}")
                    person_name = f"{firstname} {lastname}"
                    fallback_results = self.mock_data_provider.get_mock_publications(
                        person_name, db_name, count=max_results, additional_terms=additional_terms
                    )
                    for result in fallback_results:
                        result["is_mock"] = True
                        result["source"] = db_name
                        result["searched_person"] = f"{firstname} {lastname}"
                    all_results.extend(fallback_results)
                
        return all_results