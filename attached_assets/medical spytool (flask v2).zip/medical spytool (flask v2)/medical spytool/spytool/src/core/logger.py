import logging
import os
import time
from datetime import datetime
from typing import Callable, List, Literal

class Logger:
    """Logging-Klasse für die Anwendung mit einfachem und erweitertem Log"""
    
    def __init__(self):
        """Initialisiert den Logger"""
        # Erstelle Log-Verzeichnis, falls nicht vorhanden
        log_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "logs")
        os.makedirs(log_dir, exist_ok=True)
        
        # Dateinamen für die Logs
        date_str = datetime.now().strftime('%Y%m%d')
        detailed_log_filename = os.path.join(log_dir, f"spytool_detailed_{date_str}.log")
        simple_log_filename = os.path.join(log_dir, f"spytool_simple_{date_str}.log")
        
        # Erweiterten Logger konfigurieren
        self.detailed_logger = self._setup_logger("spytool.detailed", logging.DEBUG, detailed_log_filename)
        
        # Einfachen Logger konfigurieren (für wichtige Prozessschritte)
        self.simple_logger = self._setup_logger("spytool.simple", logging.INFO, simple_log_filename)
        
        # GUI-Handler für die Echtzeitanzeige (detaillierter und einfacher Log)
        self.detailed_gui_handlers: List[Callable] = []
        self.simple_gui_handlers: List[Callable] = []
    
    def _setup_logger(self, name: str, level: int, log_filename: str) -> logging.Logger:
        """Konfiguriert einen Logger mit File- und Console-Handler
        
        Args:
            name: Name des Loggers
            level: Log-Level
            log_filename: Pfad zur Logdatei
            
        Returns:
            Konfigurierter Logger
        """
        logger = logging.getLogger(name)
        logger.setLevel(level)
        logger.propagate = False
        
        # Lösche bestehende Handler (für Neuinitialisierung)
        if logger.handlers:
            logger.handlers.clear()
        
        # Datei-Handler für das Logging
        file_handler = logging.FileHandler(log_filename, encoding='utf-8')
        file_handler.setLevel(level)
        
        # Konsolen-Handler
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.INFO)
        
        # Formatter für die Handler
        formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
        file_handler.setFormatter(formatter)
        console_handler.setFormatter(formatter)
        
        # Handler hinzufügen
        logger.addHandler(file_handler)
        logger.addHandler(console_handler)
        
        return logger
        
    def add_gui_handler(self, handler: Callable, log_type: Literal["simple", "detailed"] = "detailed"):
        """
        Fügt einen GUI-Handler hinzu, der bei jedem Log-Eintrag aufgerufen wird
        
        Args:
            handler: Eine Funktion, die log_time, level und message als Parameter nimmt
            log_type: Art des Logs ("simple" oder "detailed")
        """
        if log_type == "detailed":
            if handler not in self.detailed_gui_handlers:
                self.detailed_gui_handlers.append(handler)
        else:
            if handler not in self.simple_gui_handlers:
                self.simple_gui_handlers.append(handler)
        
    def remove_gui_handler(self, handler: Callable, log_type: Literal["simple", "detailed"] = "detailed"):
        """Entfernt einen GUI-Handler
        
        Args:
            handler: Der zu entfernende Handler
            log_type: Art des Logs ("simple" oder "detailed")
        """
        if log_type == "detailed":
            if handler in self.detailed_gui_handlers:
                self.detailed_gui_handlers.remove(handler)
        else:
            if handler in self.simple_gui_handlers:
                self.simple_gui_handlers.remove(handler)
            
    def _log(self, level: int, msg: str, log_type: Literal["simple", "detailed"] = "detailed"):
        """Internes Logging mit Benachrichtigung der GUI-Handler
        
        Args:
            level: Log-Level
            msg: Log-Nachricht
            log_type: Art des Logs ("simple" oder "detailed")
        """
        if log_type == "detailed":
            self.detailed_logger.log(level, msg)
            handlers = self.detailed_gui_handlers
        else:
            self.simple_logger.log(level, msg)
            handlers = self.simple_gui_handlers
        
        # GUI-Handler aufrufen
        log_time = time.time()
        level_name = logging.getLevelName(level)
        for handler in handlers:
            try:
                handler(log_time, level_name, msg)
            except Exception as e:
                print(f"Fehler beim Aufrufen des GUI-Handlers: {e}")
    
    # Methoden für den detaillierten Log
    def debug(self, msg: str):
        """Debug-Level-Logging (nur detaillierter Log)"""
        self._log(logging.DEBUG, msg, "detailed")
        
    def info(self, msg: str, simple: bool = False):
        """Info-Level-Logging
        
        Args:
            msg: Log-Nachricht
            simple: Wenn True, wird auch in den einfachen Log geschrieben
        """
        self._log(logging.INFO, msg, "detailed")
        if simple:
            self._log(logging.INFO, msg, "simple")
        
    def warning(self, msg: str, simple: bool = False):
        """Warning-Level-Logging
        
        Args:
            msg: Log-Nachricht
            simple: Wenn True, wird auch in den einfachen Log geschrieben
        """
        self._log(logging.WARNING, msg, "detailed")
        if simple:
            self._log(logging.WARNING, msg, "simple")
        
    def error(self, msg: str, simple: bool = True):
        """Error-Level-Logging (standardmäßig in beiden Logs)
        
        Args:
            msg: Log-Nachricht
            simple: Wenn True, wird auch in den einfachen Log geschrieben
        """
        self._log(logging.ERROR, msg, "detailed")
        if simple:
            self._log(logging.ERROR, msg, "simple")
        
    def critical(self, msg: str, simple: bool = True):
        """Critical-Level-Logging (standardmäßig in beiden Logs)
        
        Args:
            msg: Log-Nachricht
            simple: Wenn True, wird auch in den einfachen Log geschrieben
        """
        self._log(logging.CRITICAL, msg, "detailed")
        if simple:
            self._log(logging.CRITICAL, msg, "simple")
    
    # Spezielle Methoden für den einfachen Log
    def log_process_step(self, msg: str):
        """Protokolliert einen wichtigen Prozessschritt im einfachen Log
        
        Args:
            msg: Beschreibung des Prozessschritts
        """
        self._log(logging.INFO, f"PROZESSSCHRITT: {msg}", "simple")
        self._log(logging.INFO, f"PROZESSSCHRITT: {msg}", "detailed")
    
    def log_search_result(self, database: str, count: int):
        """Protokolliert ein Suchergebnis im einfachen Log
        
        Args:
            database: Name der durchsuchten Datenbank
            count: Anzahl der gefundenen Ergebnisse
        """
        msg = f"SUCHERGEBNIS: {database} - {count} Ergebnisse gefunden"
        self._log(logging.INFO, msg, "simple")
        self._log(logging.INFO, msg, "detailed")