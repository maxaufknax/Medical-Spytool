"""Person Manager für die Verwaltung von Autorenprofilen"""
from typing import Dict, List, Optional
import json
import os

class PersonManager:
    def __init__(self):
        self.data_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'data')
        self.persons_file = os.path.join(self.data_dir, 'persons.json')
        self.persons = self._load_persons()
        
    def _load_persons(self) -> Dict[str, Dict]:
        """Lädt die gespeicherten Personendaten"""
        if not os.path.exists(self.data_dir):
            os.makedirs(self.data_dir)
            
        if not os.path.exists(self.persons_file):
            return {}
            
        try:
            with open(self.persons_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            print(f"Error loading persons data: {e}")
            return {}
            
    def _save_persons(self) -> None:
        """Speichert die Personendaten"""
        try:
            with open(self.persons_file, 'w', encoding='utf-8') as f:
                json.dump(self.persons, f, indent=4)
        except Exception as e:
            print(f"Error saving persons data: {e}")
            
    def add_person(self, person_id: str, data: Dict) -> None:
        """Fügt eine neue Person hinzu oder aktualisiert existierende Daten"""
        self.persons[person_id] = data
        self._save_persons()
        
    def get_person(self, person_id: str) -> Optional[Dict]:
        """Gibt die Daten einer Person zurück"""
        return self.persons.get(person_id)
        
    def update_person(self, person_id: str, data: Dict) -> None:
        """Aktualisiert die Daten einer Person"""
        if person_id in self.persons:
            self.persons[person_id].update(data)
            self._save_persons()
            
    def delete_person(self, person_id: str) -> None:
        """Löscht eine Person"""
        if person_id in self.persons:
            del self.persons[person_id]
            self._save_persons()
            
    def list_persons(self) -> List[Dict]:
        """Gibt eine Liste aller Personen zurück"""
        return list(self.persons.values())