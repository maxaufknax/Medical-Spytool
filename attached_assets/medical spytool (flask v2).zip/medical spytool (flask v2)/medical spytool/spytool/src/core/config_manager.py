import json
import os
from typing import Dict, Any

class ConfigManager:
    def __init__(self):
        self.config_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'config')
        self.config_file = os.path.join(self.config_dir, 'settings.json')
        self.config = self._load_config()
        
    def _load_config(self) -> Dict[str, Any]:
        """Lädt die Konfiguration aus der JSON-Datei"""
        if not os.path.exists(self.config_dir):
            os.makedirs(self.config_dir)
            
        if not os.path.exists(self.config_file):
            default_config = {
                "api_keys": {
                    "pubmed": "",
                    "dnb": "",
                    "wos": "",
                    "scopus": ""
                },
                "search_settings": {
                    "max_results": 100,
                    "timeout": 30
                },
                "export_settings": {
                    "default_format": "csv",
                    "export_path": os.path.expanduser("~/Downloads")
                }
            }
            self._save_config(default_config)
            return default_config
            
        try:
            with open(self.config_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            print(f"Error loading config: {e}")
            return {}
            
    def _save_config(self, config: Dict[str, Any]) -> None:
        """Speichert die Konfiguration in der JSON-Datei"""
        try:
            with open(self.config_file, 'w', encoding='utf-8') as f:
                json.dump(config, f, indent=4)
        except Exception as e:
            print(f"Error saving config: {e}")
            
    def get_config(self) -> Dict[str, Any]:
        """Gibt die aktuelle Konfiguration zurück"""
        return self.config
        
    def update_config(self, new_config: Dict[str, Any]) -> None:
        """Aktualisiert die Konfiguration mit neuen Werten"""
        self.config.update(new_config)
        self._save_config(self.config)
        
    def set_api_key(self, service: str, api_key: str) -> None:
        """Setzt den API-Key für einen bestimmten Service"""
        if "api_keys" not in self.config:
            self.config["api_keys"] = {}
        self.config["api_keys"][service] = api_key
        self._save_config(self.config)
        
    def get_api_key(self, service: str) -> str:
        """Gibt den API-Key für einen bestimmten Service zurück"""
        return self.config.get("api_keys", {}).get(service, "")