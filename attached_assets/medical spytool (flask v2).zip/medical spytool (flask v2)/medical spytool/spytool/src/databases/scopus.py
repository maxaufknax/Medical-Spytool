import requests
from typing import Dict, List, Optional

class ScopusDatabase:
    BASE_URL = "https://api.elsevier.com/content/search/scopus"
    
    def __init__(self):
        self.api_key = None
        
    def search(self, query: str, max_results: int = 100) -> List[Dict]:
        """
        Führt eine Suche in Scopus durch
        
        Args:
            query: Die Scopus-formatierte Suchanfrage (vom QueryBuilder erstellt)
            max_results: Maximale Anzahl der Ergebnisse
            
        Returns:
            Liste von Publikationen als Dictionaries
        """
        print(f"Scopus Suche mit Query: {query}")
        
        if not self.api_key:
            print("Error: Scopus API key is required")
            return []
            
        headers = {
            "X-ELS-APIKey": self.api_key,
            "Accept": "application/json"
        }
        
        params = {
            "query": query,
            "count": max_results,
            "start": 0,
            "view": "COMPLETE"  # Vollständige Metadaten anfordern
        }
        
        try:
            response = requests.get(self.BASE_URL, params=params, headers=headers)
            response.raise_for_status()
            data = response.json()
            
            results = []
            if "search-results" in data and "entry" in data["search-results"]:
                raw_records = data["search-results"]["entry"]
                for record in raw_records:
                    parsed = self._parse_record(record)
                    if parsed:
                        parsed["source"] = "scopus"  # Quelle hinzufügen
                        results.append(parsed)
            
            print(f"Scopus Suche: {len(results)} Ergebnisse gefunden")
            return results
            
        except requests.exceptions.RequestException as e:
            print(f"Error during Scopus search: {e}")
            return []
            
    def _parse_record(self, record: Dict) -> Dict:
        """Parst einen Scopus-Datensatz in ein einheitliches Format"""
        try:
            # Extrahiere Autoren
            authors = []
            if "author" in record:
                if isinstance(record["author"], list):
                    for author in record["author"]:
                        if "authname" in author:
                            authors.append(author["authname"])
                elif isinstance(record["author"], dict) and "authname" in record["author"]:
                    authors.append(record["author"]["authname"])
            
            # Extrahiere citation count und konvertiere zu int, wenn möglich
            try:
                citation_count = int(record.get("citedby-count", 0))
            except (ValueError, TypeError):
                citation_count = 0
                
            # Extrahiere Seiten korrekt
            pages = ""
            if "prism:startingPage" in record and "prism:endingPage" in record:
                start_page = record.get("prism:startingPage", "")
                end_page = record.get("prism:endingPage", "")
                if start_page or end_page:
                    pages = f"{start_page}-{end_page}".strip("-")
                    
            # Extrahiere Keywords als Liste
            keywords = []
            if "authkeywords" in record and record["authkeywords"]:
                keywords = record["authkeywords"].split(" | ")
            
            return {
                "id": record.get("dc:identifier", "").replace("SCOPUS_ID:", ""),
                "title": record.get("dc:title", ""),
                "authors": authors,
                "journal": record.get("prism:publicationName", ""),
                "year": record.get("prism:coverDate", "")[:4] if record.get("prism:coverDate") else "",  # Nur das Jahr extrahieren
                "volume": record.get("prism:volume", ""),
                "issue": record.get("prism:issueIdentifier", ""),
                "pages": pages,
                "doi": record.get("prism:doi", ""),
                "citations": citation_count,
                "abstract": record.get("dc:description", ""),
                "keywords": keywords
            }
            
        except Exception as e:
            print(f"Error parsing Scopus record: {e}")
            return {
                "id": "",
                "title": "",
                "authors": [],
                "journal": "",
                "year": "",
                "doi": ""
            }