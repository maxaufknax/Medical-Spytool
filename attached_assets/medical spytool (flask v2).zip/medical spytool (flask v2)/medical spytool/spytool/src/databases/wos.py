import requests
from typing import Dict, List, Optional

class WoSDatabase:
    BASE_URL = "https://wos-api.clarivate.com/api/wos"
    
    def __init__(self):
        self.api_key = None
        
    def search(self, query: str, max_results: int = 100) -> List[Dict]:
        """
        Führt eine Suche in Web of Science durch
        
        Args:
            query: Die WoS-formatierte Suchanfrage (vom QueryBuilder erstellt)
            max_results: Maximale Anzahl der Ergebnisse
            
        Returns:
            Liste von Publikationen als Dictionaries
        """
        print(f"WoS Suche mit Query: {query}")
        
        if not self.api_key:
            print("Error: Web of Science API key is required")
            return []
            
        headers = {
            "X-ApiKey": self.api_key,
            "Accept": "application/json"
        }
        
        params = {
            "databaseId": "WOS",
            "usrQuery": query,
            "count": max_results,
            "firstRecord": 1
        }
        
        try:
            response = requests.get(f"{self.BASE_URL}/search", params=params, headers=headers)
            response.raise_for_status()
            data = response.json()
            
            results = []
            if "Data" in data and "Records" in data["Data"]:
                raw_records = data["Data"]["Records"]
                for record in raw_records:
                    parsed = self._parse_record(record)
                    if parsed:
                        parsed["source"] = "wos"  # Quelle hinzufügen
                        results.append(parsed)
                        
            print(f"WoS Suche: {len(results)} Ergebnisse gefunden")
            return results
            
        except requests.exceptions.RequestException as e:
            print(f"Error during WoS search: {e}")
            return []
            
    def _parse_record(self, record: Dict) -> Dict:
        """Parst einen WoS-Datensatz in ein einheitliches Format"""
        try:
            source = record.get("Source", {})
            title = record.get("Title", {}).get("Title", "")
            
            # Extrahiere Autoren
            authors = []
            for author in record.get("Author", []):
                display_name = author.get("DisplayName", "")
                if display_name:
                    authors.append(display_name)
                    
            # Extrahiere DOI
            identifiers = record.get("Identifiers", [])
            doi = next((i.get("Value", "") for i in identifiers if i.get("Type") == "doi"), "")
            
            # Extrahiere Abstract
            abstract = record.get("Abstract", "")
            if isinstance(abstract, dict) and "AbstractText" in abstract:
                abstract = abstract.get("AbstractText", "")
                
            return {
                "id": record.get("UID", ""),
                "title": title,
                "authors": authors,
                "journal": source.get("SourceTitle", ""),
                "year": source.get("PublicationYear", ""),
                "volume": source.get("Volume", ""),
                "issue": source.get("Issue", ""),
                "pages": f"{source.get('Pages', {}).get('Begin', '')}-{source.get('Pages', {}).get('End', '')}",
                "doi": doi,
                "citations": record.get("CitationCount", 0),
                "abstract": abstract,
                "keywords": record.get("Keywords", [])
            }
            
        except Exception as e:
            print(f"Error parsing WoS record: {e}")
            return {
                "id": "",
                "title": "",
                "authors": [],
                "journal": "",
                "year": "",
                "doi": ""
            }