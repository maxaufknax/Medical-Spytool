import requests
from typing import Dict, List, Optional
from bs4 import BeautifulSoup

class DNBDatabase:
    BASE_URL = "https://services.dnb.de/sru/dnb"
    
    def __init__(self):
        self.access_token = None
        
    def search(self, query: str, max_results: int = 100) -> List[Dict]:
        """
        Führt eine Suche in der Deutschen Nationalbibliothek durch
        
        Args:
            query: Die CQL-formatierte Suchanfrage (vom QueryBuilder erstellt)
            max_results: Maximale Anzahl der Ergebnisse
            
        Returns:
            Liste von Publikationen als Dictionaries
        """
        print(f"DNB Suche mit Query: {query}")
        params = {
            "version": "1.1",
            "operation": "searchRetrieve",
            "query": query,
            "maximumRecords": max_results,
            "recordSchema": "MARC21-xml"
        }
        
        headers = {}
        if self.access_token:
            headers["Authorization"] = f"Bearer {self.access_token}"
            
        try:
            response = requests.get(self.BASE_URL, params=params, headers=headers)
            response.raise_for_status()
            
            soup = BeautifulSoup(response.content, 'xml')
            records = soup.find_all('record')
            
            results = []
            for record in records:
                parsed = self._parse_record(record)
                if parsed:
                    results.append(parsed)
                    
            print(f"DNB Suche: {len(results)} Ergebnisse gefunden")
            return results
            
        except requests.exceptions.RequestException as e:
            print(f"Error during DNB search: {e}")
            return []
            
    def _parse_record(self, record) -> Optional[Dict]:
        """Parst einen DNB-Datensatz in ein einheitliches Format"""
        try:
            fields = record.find_all('datafield')
            
            title = self._get_field_value(fields, '245', 'a')
            authors = self._get_field_values(fields, '100', 'a')
            authors.extend(self._get_field_values(fields, '700', 'a'))
            
            isbn = self._get_field_value(fields, '020', 'a')
            dnb_id = self._get_field_value(fields, '035', 'a')
            year = self._get_field_value(fields, '264', 'c')
            if year and len(year) >= 4:
                year = year[:4]  # Extrahiere nur das Jahr, falls im Format "2020."
                
            # Extrahiere Abstract/Beschreibung, falls vorhanden
            abstract = self._get_field_value(fields, '520', 'a') or ""
            
            result = {
                "id": dnb_id or "",
                "title": title or "",
                "authors": authors,
                "isbn": isbn or "",
                "type": self._get_field_value(fields, '336', 'a') or "",
                "publisher": self._get_field_value(fields, '264', 'b') or "",
                "year": year or "",
                "language": self._get_field_value(fields, '041', 'a') or "",
                "subjects": self._get_field_values(fields, '650', 'a'),
                "abstract": abstract
            }
            
            # Standardisiere die Ausgabe für konsistente Anzeige in der Anwendung
            return {
                "id": result["id"],
                "title": result["title"],
                "authors": result["authors"],
                "journal": result.get("publisher", ""),
                "year": result["year"],
                "abstract": result.get("abstract", ""),
                "doi": "",  # DNB hat keine DOIs
                "source": "dnb"  # Quelle hinzufügen
            }
            
        except Exception as e:
            print(f"Error parsing DNB record: {e}")
            return None
            
    def _get_field_value(self, fields, tag: str, code: str) -> Optional[str]:
        """Hilfsfunktion zum Extrahieren eines einzelnen Feldwerts"""
        field = next((f for f in fields if f.get('tag') == tag), None)
        if field:
            subfield = field.find('subfield', {'code': code})
            return subfield.text.strip() if subfield else None
        return None
        
    def _get_field_values(self, fields, tag: str, code: str) -> List[str]:
        """Hilfsfunktion zum Extrahieren mehrerer Feldwerte"""
        values = []
        for field in fields:
            if field.get('tag') == tag:
                subfields = field.find_all('subfield', {'code': code})
                values.extend([sf.text.strip() for sf in subfields if sf.text])
        return values