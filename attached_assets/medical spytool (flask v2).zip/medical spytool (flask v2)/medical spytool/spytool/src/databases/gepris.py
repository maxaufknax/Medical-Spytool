import requests
import json
import xml.etree.ElementTree as ET
from bs4 import BeautifulSoup
from typing import Dict, List, Optional, Callable, Any

class GeprisDatabase:
    BASE_URL = "https://gepris.dfg.de/gepris/OCTOPUS"
    SEARCH_URL = "https://gepris.dfg.de/gepris/OCTOPUS/projekte"
    
    def __init__(self, api_key: str = None):
        """
        Initialisiert die DFG GEPRIS-Datenbankverbindung
        
        Args:
            api_key: Optional. API-Key für erweiterte Zugriffsmöglichkeiten (falls vorhanden)
        """
        self.api_key = api_key
        
    def search(self, query: str, max_results: int = 100) -> List[Dict]:
        """
        Führt eine Suche in der DFG GEPRIS-Datenbank durch
        
        Args:
            query: Suchanfrage (vom QueryBuilder erstellt)
            max_results: Maximale Anzahl der Ergebnisse
            
        Returns:
            Liste von Projekten als Dictionaries
        """
        print(f"GEPRIS Suche mit Query: {query}")
        
        params = {
            "task": "doSearchExtended",
            "context": "projekt",
            "facetValues": "",
            "sachverhalt": "person",
            "nurProjekteMitAB": "false",
            "zk_Top_Site_ID": "110",
            "einrichtungsart": "",
            "hf": "zu",
            "zweigstelle": "",
            "keyword": query.strip(),  # Suchbegriff
            "einrichtung": "",  # Institut/Organisation
            "fachgebiet": "",  # Fachgebiet
            "dfgGremium": ""
        }
        
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
        }
        
        try:
            response = requests.get(self.SEARCH_URL, params=params, headers=headers)
            response.raise_for_status()
            
            # Verwende BeautifulSoup für die HTML-Analyse
            soup = BeautifulSoup(response.content, 'html.parser')
            
            projects = []
            # Suche nach Projekteinträgen
            project_entries = soup.select('div.results-list-entries div.entry')
            
            # Begrenze die Anzahl der Ergebnisse
            project_entries = project_entries[:max_results] if project_entries else []
            
            for entry in project_entries:
                try:
                    # Extrahiere Titel
                    title_elem = entry.select_one('h2 a')
                    title = title_elem.text.strip() if title_elem else "Kein Titel"
                    project_url = title_elem['href'] if title_elem and 'href' in title_elem.attrs else ""
                    
                    # Extrahiere Projekt-ID aus der URL
                    project_id = project_url.split('/')[-1] if project_url else ""
                    
                    # Extrahiere Person/Personen
                    persons = []
                    person_elems = entry.select('div.name a')
                    for person in person_elems:
                        persons.append(person.text.strip())
                    
                    # Extrahiere Institution
                    institution_elem = entry.select_one('div.institution')
                    institution = institution_elem.text.strip() if institution_elem else ""
                    
                    # Extrahiere Förderungszeitraum
                    timeframe_elem = entry.select_one('div.period')
                    timeframe = timeframe_elem.text.strip() if timeframe_elem else ""
                    
                    # Extrahiere Jahr (falls möglich)
                    year = ""
                    if timeframe:
                        # Versuche, das Jahr zu extrahieren (z.B. "01/2020 - 12/2023" -> "2020")
                        parts = timeframe.split()
                        for part in parts:
                            if "/" in part and len(part) >= 7:
                                year = part.split("/")[-1]
                                break
                    
                    # Erstelle Projekt-Eintrag
                    project = {
                        "id": project_id,
                        "title": title,
                        "authors": persons,  # Als Autoren für konsistente Anzeige
                        "year": year,
                        "institution": institution,
                        "timeframe": timeframe,
                        "url": f"https://gepris.dfg.de{project_url}" if project_url else "",
                        "source": "gepris"  # Quelle hinzufügen
                    }
                    
                    # Konvertiere zu einheitlichem Format für die Anzeige
                    projects.append({
                        "id": project["id"],
                        "title": project["title"],
                        "authors": project["authors"],
                        "journal": project["institution"],  # Institution als "Journal" für konsistente Anzeige
                        "year": project["year"],
                        "abstract": f"Förderzeitraum: {project['timeframe']}",
                        "doi": "",  # GEPRIS hat keine DOIs
                        "url": project["url"],
                        "source": "gepris"
                    })
                    
                except Exception as e:
                    print(f"Fehler beim Parsen eines GEPRIS-Projekteintrags: {e}")
            
            print(f"GEPRIS Suche: {len(projects)} Ergebnisse gefunden")
            return projects
            
        except requests.exceptions.RequestException as e:
            print(f"Error during GEPRIS search: {e}")
            return []