import requests
from typing import Dict, List, Optional

class PubMedDatabase:
    BASE_URL = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/"
    
    def __init__(self, api_key: str = None):
        """
        Initialisiert die PubMed-Datenbankverbindung
        
        Args:
            api_key: Optional. API-Key für erweiterte Zugriffsmöglichkeiten
        """
        self.api_key = api_key
        
    def search(self, query: str, max_results: int = 100) -> List[Dict]:
        """
        Führt eine Suche in PubMed durch
        
        Args:
            query: Suchanfrage
            max_results: Maximale Anzahl der Ergebnisse
            
        Returns:
            Liste von Publikationen als Dictionaries
        """
        # Überprüfen, ob die Anfrage ein Personenname sein könnte (enthält Leerzeichen ohne Operatoren)
        if " " in query and not any(op in query for op in ["AND", "OR", "NOT", "(", ")"]):
            # Vermutlich ein vollständiger Name - in Autor-Format umwandeln für bessere Ergebnisse
            name_parts = query.split()
            if len(name_parts) == 2:  # Einfacher Vor- und Nachname
                query = f"{name_parts[1]}[Author] {name_parts[0]}[Author]"
        
        search_url = f"{self.BASE_URL}esearch.fcgi"
        params = {
            "db": "pubmed",
            "term": query,
            "retmax": max_results,
            "retmode": "json"
        }
        
        if self.api_key:
            params["api_key"] = self.api_key
            
        try:
            response = requests.get(search_url, params=params)
            response.raise_for_status()
            data = response.json()
            
            if "esearchresult" in data:
                id_list = data["esearchresult"].get("idlist", [])
                return self.fetch_details(id_list)
            
            return []
            
        except requests.exceptions.RequestException as e:
            print(f"Error during PubMed search: {e}")
            return []
            
    def fetch_details(self, id_list: List[str]) -> List[Dict]:
        """
        Holt Details zu den gefundenen PubMed-IDs
        
        Args:
            id_list: Liste von PubMed-IDs
            
        Returns:
            Liste von Publikationsdetails
        """
        if not id_list:
            return []
            
        fetch_url = f"{self.BASE_URL}efetch.fcgi"
        params = {
            "db": "pubmed",
            "id": ",".join(id_list),
            "retmode": "json",
            "rettype": "abstract"
        }
        
        if self.api_key:
            params["api_key"] = self.api_key
            
        try:
            response = requests.get(fetch_url, params=params)
            response.raise_for_status()
            data = response.json()
            
            results = []
            if "PubmedArticleSet" in data:
                for article in data["PubmedArticleSet"]:
                    parsed = self._parse_article(article)
                    if parsed:
                        results.append(parsed)
            
            return results
            
        except requests.exceptions.RequestException as e:
            print(f"Error fetching PubMed details: {e}")
            return []
            
    def _parse_article(self, article: Dict) -> Optional[Dict]:
        """
        Parst einen PubMed-Artikel in ein einheitliches Format
        
        Args:
            article: PubMed-Artikeldaten
            
        Returns:
            Formatierte Artikeldaten oder None bei Fehler
        """
        try:
            medline = article.get("MedlineCitation", {})
            article_data = medline.get("Article", {})
            
            return {
                "id": medline.get("PMID", ""),
                "title": article_data.get("ArticleTitle", ""),
                "abstract": article_data.get("Abstract", {}).get("AbstractText", ""),
                "authors": [
                    f"{author.get('LastName', '')} {author.get('ForeName', '')}"
                    for author in article_data.get("AuthorList", [])
                ],
                "journal": article_data.get("Journal", {}).get("Title", ""),
                "year": article_data.get("Journal", {}).get("Year", ""),
                "doi": next(
                    (id_data.get("Value", "")
                     for id_data in article_data.get("ELocationID", [])
                     if id_data.get("EIdType", "") == "doi"),
                    ""
                )
            }
            
        except Exception as e:
            print(f"Error parsing PubMed article: {e}")
            return None