"""Datenbank-Module für Medical Spytool"""
from .pubmed import PubMedDatabase
from .dnb import DNBDatabase
from .wos import WoSDatabase
from .scopus import ScopusDatabase
from .gepris import GeprisDatabase

__all__ = [
    'PubMedDatabase',
    'DNBDatabase',
    'WoSDatabase',
    'ScopusDatabase',
    'GeprisDatabase'
]