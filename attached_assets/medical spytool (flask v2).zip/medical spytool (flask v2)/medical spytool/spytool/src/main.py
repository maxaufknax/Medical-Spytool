"""Main entry point für Medical Spytool"""
import tkinter as tk
import sys
import traceback
from gui.main_window import MainWindow
from core.logger import Logger

def exception_handler(exc_type, exc_value, exc_traceback):
    """Global exception handler für unbehandelte Ausnahmen"""
    logger = Logger()
    error_msg = ''.join(traceback.format_exception(exc_type, exc_value, exc_traceback))
    logger.critical(f"Unbehandelte Ausnahme: {error_msg}")
    tk.messagebox.showerror(
        "Fehler",
        "Ein unerwarteter Fehler ist aufgetreten. Details wurden im Logfile gespeichert."
    )

def main():
    """Hauptfunktion der Anwendung"""
    # Setze globalen Exception Handler
    sys.excepthook = exception_handler
    
    # Starte die Anwendung
    app = MainWindow()
    app.mainloop()

if __name__ == "__main__":
    main()