class QueryBuilder:
    def __init__(self):
        self.terms = []
        self.filters = {}
        self.author_firstname = None
        self.author_lastname = None
        
    def add_term(self, term: str) -> None:
        """Fügt einen Suchbegriff hinzu"""
        if term:
            self.terms.append(term)
            
    def add_author(self, firstname: str = None, lastname: str = None) -> None:
        """Fügt einen Autor zur Suche hinzu"""
        self.author_firstname = firstname
        self.author_lastname = lastname
            
    def add_year_range(self, start_year: str = None, end_year: str = None) -> None:
        """Fügt einen Jahresbereich hinzu"""
        if start_year or end_year:
            self.filters['year_range'] = {
                'start': start_year,
                'end': end_year
            }
            
    def add_language(self, language: str) -> None:
        """Fügt einen Sprachfilter hinzu"""
        if language and language != "Alle":
            self.filters['language'] = language
            
    def build(self, database_type: str) -> str:
        """
        Erstellt die Suchanfrage für die spezifische Datenbank
        
        Args:
            database_type: Art der Datenbank ('pubmed', 'dnb', 'wos', 'scopus', 'gepris')
            
        Returns:
            Formatierte Suchanfrage als String
        """
        if database_type.lower() == 'pubmed':
            return self._build_pubmed_query()
        elif database_type.lower() == 'dnb':
            return self._build_dnb_query()
        elif database_type.lower() == 'wos':
            return self._build_wos_query()
        elif database_type.lower() == 'scopus':
            return self._build_scopus_query()
        elif database_type.lower() == 'gepris':
            return self._build_gepris_query()
        else:
            raise ValueError(f"Unbekannter Datenbanktyp: {database_type}")
            
    def _build_pubmed_query(self) -> str:
        """Erstellt eine PubMed-spezifische Suchanfrage

        PubMed nutzt spezifische Tags wie [au] für Autor, [dp] für Publication Date, [la] für Sprache

        Beispiele:
        - "Smith J[au] AND cancer[tiab]"
        - "2020:2022[dp] AND german[la]"
        """
        query_parts = []
        
        # Autor hinzufügen
        if self.author_lastname:
            author_query = self.author_lastname
            if self.author_firstname:
                # Bei PubMed ist das Format für Autoren: "LastName FirstInitial"
                first_initial = self.author_firstname[0] if self.author_firstname else ""
                author_query = f"{self.author_lastname} {first_initial}"
            query_parts.append(f"{author_query}[au]")
        
        # Füge Hauptsuchbegriffe hinzu
        if self.terms:
            # Bei mehreren Begriffen diese mit AND verknüpfen
            terms_query = " AND ".join([f"{term}[tiab]" for term in self.terms])
            query_parts.append(f"({terms_query})")
            
        # Füge Jahresfilter hinzu
        if 'year_range' in self.filters:
            year_range = self.filters['year_range']
            if year_range['start'] and year_range['end']:
                query_parts.append(f"{year_range['start']}:{year_range['end']}[dp]")
            elif year_range['start']:
                query_parts.append(f"{year_range['start']}[dp]")
            elif year_range['end']:
                query_parts.append(f":{year_range['end']}[dp]")
                
        # Füge Sprachfilter hinzu
        if 'language' in self.filters:
            # PubMed verwendet Sprachcodes wie "eng" für Englisch, "ger" für Deutsch
            lang_code = 'ger' if self.filters['language'] == 'Deutsch' else 'eng'
            query_parts.append(f"{lang_code}[la]")
            
        return " AND ".join(query_parts)
        
    def _build_dnb_query(self) -> str:
        """Erstellt eine DNB-spezifische Suchanfrage in CQL-Syntax

        Die Deutsche Nationalbibliothek verwendet CQL (Contextual Query Language)
        
        Beispiele:
        - "dnb.personalName = Mueller, Hans AND dnb.keyword = Medizin"
        - "dnb.publicationYear >= 2020 AND dnb.publicationYear <= 2023"
        """
        query_parts = []
        
        # Autor hinzufügen
        if self.author_lastname:
            if self.author_firstname:
                # Format für DNB: Nachname, Vorname
                author_query = f"dnb.personalName = {self.author_lastname}, {self.author_firstname}"
            else:
                author_query = f"dnb.personalName all {self.author_lastname}"
            query_parts.append(f"({author_query})")
        
        # Füge Hauptsuchbegriffe hinzu
        if self.terms:
            # Für die Suche in verschiedenen Feldern (Titel, Schlagwörter, etc.)
            terms_query = " OR ".join([
                f"dnb.title all {term}" for term in self.terms
            ] + [
                f"dnb.keyword all {term}" for term in self.terms
            ])
            query_parts.append(f"({terms_query})")
            
        # Füge Jahresfilter hinzu
        if 'year_range' in self.filters:
            year_range = self.filters['year_range']
            year_conditions = []
            
            if year_range['start']:
                year_conditions.append(f"dnb.publicationYear >= {year_range['start']}")
            if year_range['end']:
                year_conditions.append(f"dnb.publicationYear <= {year_range['end']}")
                
            if year_conditions:
                query_parts.append(" AND ".join(year_conditions))
                
        # Füge Sprachfilter hinzu
        if 'language' in self.filters:
            # DNB verwendet ISO-Sprachcodes wie "ger" für Deutsch, "eng" für Englisch
            lang_code = 'ger' if self.filters['language'] == 'Deutsch' else 'eng'
            query_parts.append(f"dnb.language = {lang_code}")
            
        # Verbinde alle Teile mit AND
        return " AND ".join(query_parts)
        
    def _build_wos_query(self) -> str:
        """Erstellt eine Web of Science-spezifische Suchanfrage

        Web of Science verwendet spezielle Feldabkürzungen wie AU= für Autor, PY= für Publication Year

        Beispiele:
        - "AU=(Smith J*) AND TI=(cancer treatment)"
        - "PY=2020-2022 AND LA=(English)"
        """
        query_parts = []
        
        # Autor hinzufügen
        if self.author_lastname:
            if self.author_firstname:
                # Web of Science verwendet das Format "Nachname FirstInitial*"
                first_initial = self.author_firstname[0] if self.author_firstname else ""
                author_query = f"AU=({self.author_lastname} {first_initial}*)"
            else:
                author_query = f"AU=({self.author_lastname})"
            query_parts.append(author_query)
        
        # Füge Hauptsuchbegriffe hinzu
        if self.terms:
            # Bei mehreren Suchbegriffen diese in Titel ODER Topic suchen
            terms_parts = []
            for term in self.terms:
                terms_parts.append(f"TI=({term}) OR TS=({term})")
            
            if terms_parts:
                query_parts.append(f"({' OR '.join(terms_parts)})")
            
        # Füge Jahresfilter hinzu
        if 'year_range' in self.filters:
            year_range = self.filters['year_range']
            if year_range['start'] and year_range['end']:
                query_parts.append(f"PY=({year_range['start']}-{year_range['end']})")
            elif year_range['start']:
                query_parts.append(f"PY>={year_range['start']}")
            elif year_range['end']:
                query_parts.append(f"PY<={year_range['end']}")
                
        # Füge Sprachfilter hinzu
        if 'language' in self.filters:
            # WoS verwendet Sprachbezeichnungen wie "English", "German"
            lang_name = 'German' if self.filters['language'] == 'Deutsch' else 'English'
            query_parts.append(f"LA=({lang_name})")
            
        return " AND ".join(query_parts)
        
    def _build_scopus_query(self) -> str:
        """Erstellt eine Scopus-spezifische Suchanfrage

        Scopus verwendet Feldcodes wie AUTHOR-NAME(), TITLE-ABS-KEY(), PUBYEAR

        Beispiele:
        - "AUTHOR-NAME(Smith J.) AND TITLE-ABS-KEY(cancer)"
        - "PUBYEAR > 2019 AND PUBYEAR < 2024 AND LANGUAGE(english)"
        """
        query_parts = []
        
        # Autor hinzufügen
        if self.author_lastname:
            if self.author_firstname:
                # Scopus verwendet das Format "Nachname, Vorname Initial"
                first_initial = self.author_firstname[0] if self.author_firstname else ""
                author_query = f"AUTHOR-NAME({self.author_lastname}, {first_initial})"
            else:
                author_query = f"AUTHOR-NAME({self.author_lastname})"
            query_parts.append(author_query)
        
        # Füge Hauptsuchbegriffe hinzu
        if self.terms:
            # Scopus: Suche in Titel, Abstract und Keywords
            terms_query = " AND ".join([f"TITLE-ABS-KEY({term})" for term in self.terms])
            query_parts.append(f"({terms_query})")
            
        # Füge Jahresfilter hinzu
        if 'year_range' in self.filters:
            year_range = self.filters['year_range']
            year_conditions = []
            
            if year_range['start']:
                year_conditions.append(f"PUBYEAR > {int(year_range['start'])-1}")
            if year_range['end']:
                year_conditions.append(f"PUBYEAR < {int(year_range['end'])+1}")
                
            if year_conditions:
                query_parts.append(" AND ".join(year_conditions))
                
        # Füge Sprachfilter hinzu
        if 'language' in self.filters:
            # Scopus verwendet Sprachbezeichnungen wie "English", "German"
            lang_name = 'German' if self.filters['language'] == 'Deutsch' else 'English'
            query_parts.append(f"LANGUAGE({lang_name.lower()})")
            
        return " AND ".join(query_parts)
        
    def _build_gepris_query(self) -> str:
        """Erstellt eine GEPRIS-spezifische Suchanfrage

        Da GEPRIS eine spezielle DFG-Projektdatenbank ist, verwenden wir hier
        einfache Suchbegriffe, die dann in der GEPRIS-Websuche verwendet werden.
        """
        query_parts = []
        
        # Autor/Person hinzufügen
        if self.author_lastname:
            if self.author_firstname:
                # Format: "Vorname Nachname"
                author_query = f"{self.author_firstname} {self.author_lastname}"
            else:
                author_query = self.author_lastname
            query_parts.append(author_query)
        
        # Füge Hauptsuchbegriffe hinzu
        if self.terms:
            query_parts.extend(self.terms)
            
        # GEPRIS unterstützt keine direkte Jahresfilterung in der API-Abfrage
        # Sprachfilter werden in GEPRIS auch nicht direkt unterstützt
        
        # Verbinde alles mit Leerzeichen für eine einfache Suche
        return " ".join(query_parts)