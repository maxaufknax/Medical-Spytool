"""
Utility module for providing mock data for testing database functionality
without requiring API keys or internet connectivity.
"""
from typing import List, Dict, Any, Optional
import random
from datetime import datetime

class MockDataProvider:
    """Provides mock data for testing purposes."""
    
    def __init__(self):
        # Medical topics for more realistic mock data
        self.medical_topics = [
            "nephrology", "renal transplantation", "hypertension", "kidney disease",
            "dialysis", "immune rejection", "pediatric nephrology", "kidney function",
            "diabetes and kidney", "nephritis"
        ]
        
        # Common journal names for mock publications
        self.journals = {
            "pubmed": [
                "Journal of the American Society of Nephrology", 
                "Kidney International", 
                "American Journal of Transplantation",
                "Pediatric Nephrology",
                "Transplantation"
            ],
            "wos": [
                "Clinical Journal of the American Society of Nephrology", 
                "Nephrology Dialysis Transplantation", 
                "International Journal of Nephrology",
                "Journal of Renal Nutrition",
                "Kidney and Blood Pressure Research"
            ],
            "scopus": [
                "Nephron", 
                "Journal of Nephrology", 
                "Advances in Chronic Kidney Disease",
                "Current Opinion in Nephrology and Hypertension",
                "BMC Nephrology"
            ],
            "dnb": [
                "Nieren- und Hochdruckkrankheiten", 
                "Deutsche Medizinische Wochenschrift", 
                "Medizinische Klinik",
                "Der Nephrologe",
                "Deutsche Zeitschrift für Klinische Forschung"
            ],
            "gepris": [
                "DFG Forschungsberichte", 
                "Klinische Forschung", 
                "Medizinische Hochschule",
                "Universitätsklinikum",
                "Deutsche Forschungsgemeinschaft"
            ]
        }
    
    def get_mock_publications(self, query: str, database: str, count: int = 10, additional_terms: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Generate mock publication data based on the query and database.
        
        Args:
            query: The search query
            database: The database name (pubmed, dnb, wos, scopus, gepris)
            count: Number of mock results to generate
            additional_terms: Additional search terms to include in mock data
            
        Returns:
            List of mock publication dictionaries
        """
        # Check if this is a person search (query contains a name)
        if " " in query and any(c.isalpha() for c in query) and not any(op in query for op in ["AND", "OR", "NOT"]):
            return self.get_mock_person_publications(query, database, count, additional_terms)
            
        results = []
        # Create different mock data based on database type
        for i in range(1, count + 1):
            # Randomize publication year between 2010 and current year
            current_year = datetime.now().year
            year = str(random.randint(2010, current_year))
            
            # Generate random topics
            topic = random.choice(self.medical_topics)
            if additional_terms:
                topic = f"{topic} and {additional_terms}"
            
            # Get a random journal for this database
            journal = random.choice(self.journals.get(database, ["Mock Journal"]))
            
            if database == "pubmed":
                results.append({
                    "id": f"PMC{100000+i}",
                    "title": f"Study on {topic.title()} Related to {query}",
                    "abstract": f"This mock publication investigates {topic} with a focus on {query}. The research demonstrates significant findings that could impact medical practice.",
                    "authors": [f"Author {j}, {'J' if j % 2 == 0 else 'L'}" for j in range(1, 4)],
                    "journal": journal,
                    "year": year,
                    "doi": f"10.1000/mock-{i}",
                    "source": "pubmed"
                })
            elif database == "dnb":
                results.append({
                    "id": f"DNB{200000+i}",
                    "title": f"Publikation über {topic.title()} - {query}",
                    "authors": [f"Autor {j}, {'K' if j % 2 == 0 else 'M'}" for j in range(1, 3)],
                    "journal": journal,
                    "year": year,
                    "isbn": f"978-3-16-148410-{i}",
                    "abstract": f"Diese Mock-Publikation untersucht {topic} mit Bezug auf {query}.",
                    "source": "dnb"
                })
            elif database == "wos":
                results.append({
                    "id": f"WOS:{300000+i}",
                    "title": f"Analysis of {topic.title()} in Context of {query}",
                    "abstract": f"Web of Science indexed study examining {topic} with detailed analysis of {query} implications.",
                    "authors": [f"Researcher {j}, {'B' if j % 2 == 0 else 'S'}" for j in range(1, 5)],
                    "journal": journal,
                    "year": year,
                    "doi": f"10.1111/mock-wos-{i}",
                    "citations": i * 5,
                    "source": "wos"
                })
            elif database == "scopus":
                results.append({
                    "id": f"SCOPUS_ID:{400000+i}",
                    "title": f"Comprehensive Review of {topic.title()} Applications on {query}",
                    "abstract": f"This Scopus-indexed article provides a systematic review of {topic} with particular emphasis on {query} applications.",
                    "authors": [f"Scientist {j}, {'C' if j % 2 == 0 else 'D'}" for j in range(1, 4)],
                    "journal": journal,
                    "year": year,
                    "doi": f"10.1016/j.mock-scopus-{i}",
                    "citations": i * 3,
                    "source": "scopus"
                })
            elif database == "gepris":
                start_year = int(year)
                end_year = min(start_year + 3, current_year + 2)
                results.append({
                    "id": f"GEPRIS{500000+i}",
                    "title": f"Forschungsprojekt: {topic.title()} mit Fokus auf {query}",
                    "abstract": f"Förderungszeitraum: {start_year}-{end_year}",
                    "authors": [f"Prof. Dr. {j}, {'R' if j % 2 == 0 else 'T'}" for j in range(1, 4)],
                    "journal": journal,  # Using journal field for institution
                    "year": year,
                    "url": f"https://gepris.dfg.de/gepris/projekt/MOCK{500000+i}",
                    "source": "gepris"
                })
                
        return results
    
    def get_mock_person_publications(self, name: str, database: str, count: int = 5, additional_terms: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Generate mock publication data for a specific person.
        
        Args:
            name: The person's name
            database: The database name
            count: Number of mock results to generate
            additional_terms: Additional search terms to include in mock data
            
        Returns:
            List of mock publication dictionaries
        """
        # Extract first and last name for more realistic mock data
        name_parts = name.split()
        first_name = name_parts[0] if len(name_parts) > 0 else "Unknown"
        last_name = name_parts[-1] if len(name_parts) > 1 else "Unknown"
        
        # Generate random author position (first, middle, last)
        author_positions = ["first", "middle", "last"]
        random.shuffle(author_positions)
        
        # Current year for realistic publication dates
        current_year = datetime.now().year
        
        # Select random medical topics
        topics = random.sample(self.medical_topics, min(count, len(self.medical_topics)))
        if additional_terms:
            topics = [f"{t} {additional_terms}" for t in topics]
        
        results = []
        
        for i in range(1, count + 1):
            # Randomize publication year between 2015 and current year
            year = str(random.randint(2015, current_year))
            
            # Get a random topic
            topic_idx = (i - 1) % len(topics)
            topic = topics[topic_idx]
            
            # Get a random journal for this database
            journal = random.choice(self.journals.get(database, ["Mock Journal"]))
            
            # Create author list with the search person in different positions
            position = author_positions[i % len(author_positions)]
            if position == "first":
                authors = [f"{first_name} {last_name}"]
                authors.extend([f"Collaborator {j}" for j in range(1, random.randint(2, 5))])
            elif position == "last":
                authors = [f"Collaborator {j}" for j in range(1, random.randint(2, 5))]
                authors.append(f"{first_name} {last_name}")
            else:
                authors = [f"Senior Author {random.randint(1, 3)}"]
                authors.append(f"{first_name} {last_name}")
                authors.extend([f"Junior Researcher {j}" for j in range(1, random.randint(1, 3))])
            
            # Base publication data
            base_data = {
                "title": f"{'Clinical ' if i % 2 == 0 else 'Experimental '}Study of {topic.title()}{' in Pediatric Patients' if i % 3 == 0 else ''}",
                "authors": authors,
                "year": year,
                "searched_person": f"{first_name} {last_name}"
            }
            
            if database == "pubmed":
                results.append({
                    **base_data,
                    "id": f"PMC{900000+i}",
                    "journal": journal,
                    "abstract": f"A comprehensive study on {topic} led by a team including {first_name} {last_name}. " +
                             f"This research investigates the implications for clinical practice and patient outcomes.",
                    "doi": f"10.1000/mock-{last_name.lower()}-{i}",
                    "source": "pubmed"
                })
            elif database == "scopus":
                results.append({
                    **base_data,
                    "id": f"SCOPUS_ID:{800000+i}",
                    "journal": journal,
                    "citations": random.randint(0, 50),
                    "abstract": f"Research conducted at University Hospital examining {topic} with involvement of {first_name} {last_name}. " +
                             f"This study provides new insights into treatment approaches.",
                    "doi": f"10.1016/j.mock-{last_name.lower()}-{i}",
                    "source": "scopus"
                })
            elif database == "wos":
                results.append({
                    **base_data,
                    "id": f"WOS:{700000+i}",
                    "journal": journal,
                    "citations": random.randint(0, 40),
                    "abstract": f"Analysis of {topic} with contributions from {first_name} {last_name}. " +
                             f"The study presents novel methodologies and findings relevant to the field.",
                    "doi": f"10.1111/mock-wos-{last_name.lower()}-{i}",
                    "source": "wos"
                })
            elif database == "dnb":
                results.append({
                    **base_data,
                    "id": f"DNB{600000+i}",
                    "journal": journal,
                    "abstract": f"Eine umfassende Untersuchung zu {topic} unter Beteiligung von {first_name} {last_name}. " +
                             f"Diese Forschung trägt zum Verständnis klinischer Aspekte bei.",
                    "isbn": f"978-3-16-148410-{i}",
                    "source": "dnb"
                })
            elif database == "gepris":
                start_year = int(year)
                end_year = min(start_year + random.randint(1, 4), current_year + 2)
                results.append({
                    **base_data,
                    "id": f"GEPRIS{500000+i}",
                    "journal": journal,  # Using journal field for institution
                    "abstract": f"Förderungszeitraum: {start_year}-{end_year}. " +
                             f"Forschungsprojekt zu {topic} mit Beteiligung von {first_name} {last_name}.",
                    "url": f"https://gepris.dfg.de/gepris/projekt/MOCK{500000+i}",
                    "source": "gepris"
                })
                
        return results