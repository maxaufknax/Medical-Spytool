import csv
import json
from typing import List, Dict, Any
from pathlib import Path
from core.logger import Logger

class DataExporter:
    def __init__(self, logger: Logger):
        self.logger = logger

    def export_results(self, results: List[Dict[str, Any]], format: str = "csv", filename: str = None) -> bool:
        """
        Exportiert die Suchergebnisse in verschiedene Formate
        
        Args:
            results: Liste der Suchergebnisse
            format: Exportformat ('csv' oder 'json')
            filename: Zieldateiname (optional)
            
        Returns:
            bool: True wenn Export erfolgreich, False sonst
        """
        try:
            if not results:
                self.logger.warning("Keine Ergebnisse zum Exportieren vorhanden")
                return False

            if filename is None:
                filename = f"spytool_export.{format}"

            filepath = Path(filename)
            
            if format.lower() == "csv":
                return self._export_csv(results, filepath)
            elif format.lower() == "json":
                return self._export_json(results, filepath)
            else:
                self.logger.error(f"Nicht unterstütztes Format: {format}")
                return False

        except Exception as e:
            self.logger.error(f"Fehler beim Exportieren: {e}")
            return False

    def _export_csv(self, results: List[Dict[str, Any]], filepath: Path) -> bool:
        """Exportiert Ergebnisse als CSV"""
        try:
            # Bestimme Felder aus allen Ergebnissen
            fieldnames = set()
            for result in results:
                fieldnames.update(result.keys())
            fieldnames = sorted(list(fieldnames))

            with open(filepath, 'w', newline='', encoding='utf-8') as csvfile:
                writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
                writer.writeheader()
                for result in results:
                    writer.writerow(result)

            self.logger.info(f"{len(results)} Ergebnisse nach {filepath} exportiert")
            return True

        except Exception as e:
            self.logger.error(f"Fehler beim CSV-Export: {e}")
            return False

    def _export_json(self, results: List[Dict[str, Any]], filepath: Path) -> bool:
        """Exportiert Ergebnisse als JSON"""
        try:
            with open(filepath, 'w', encoding='utf-8') as jsonfile:
                json.dump(results, jsonfile, indent=2, ensure_ascii=False)

            self.logger.info(f"{len(results)} Ergebnisse nach {filepath} exportiert")
            return True

        except Exception as e:
            self.logger.error(f"Fehler beim JSON-Export: {e}")
            return False

if __name__ == "__main__":
    logger = Logger()
    exporter = DataExporter(logger)
    # Example usage:
    # results = [{"title": "Example Paper", "authors": ["Author1", "Author2"]}]
    # exporter.export_results(results, format="csv", filename="output.csv")