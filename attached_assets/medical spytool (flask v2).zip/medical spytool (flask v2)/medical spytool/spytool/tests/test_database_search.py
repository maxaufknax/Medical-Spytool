"""
Test script for the database service functionality with mock data
"""
import sys
import os

# Add parent directory to path to allow imports
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from src.core.config_manager import ConfigManager
from src.core.logger import Logger
from src.core.database_service import DatabaseService

def test_database_search():
    """
    Test the database search functionality with mock data
    """
    print("\n=== Testing Database Search with Mock Data ===\n")
    
    # Initialize necessary components
    logger = Logger()
    config_manager = ConfigManager()
    
    # Ensure test mode is enabled in config
    config = config_manager.get_config()
    if "development" not in config:
        config["development"] = {}
    config["development"]["testing_mode"] = True
    config["development"]["use_mock_data"] = True
    config_manager.update_config(config)
    print("Mock data mode enabled in configuration")
    
    # Initialize database service
    db_service = DatabaseService(config_manager, logger)
    
    # Test search functionality
    test_queries = [
        "diabetes",
        "cancer treatment",
        "covid-19 vaccines",
        "neural networks in medicine"
    ]
    
    for query in test_queries:
        print(f"\n--- Testing search with query: '{query}' ---")
        
        # Test all databases search
        results = db_service.search_all(query, max_results=5)
        print(f"Found {len(results)} combined results across all databases")
        
        # Print a sample result from each database
        databases_found = set()
        for result in results:
            source = result.get("source")
            if source and source not in databases_found:
                databases_found.add(source)
                print(f"\nSample result from {source}:")
                print(f"  Title: {result.get('title', 'N/A')}")
                if "abstract" in result:
                    abstract = result.get("abstract", "")
                    print(f"  Abstract: {abstract[:100]}..." if len(abstract) > 100 else f"  Abstract: {abstract}")
                print(f"  Authors: {', '.join(result.get('authors', []))}")
        
        # Test individual database search
        for db_name in ["pubmed", "scopus", "wos", "dnb", "gepris"]:
            db_results = db_service.search_database(db_name, query, max_results=3)
            print(f"\n{db_name.upper()}: Found {len(db_results)} results")
            
    print("\n=== Database Search Tests Completed ===")

if __name__ == "__main__":
    test_database_search()