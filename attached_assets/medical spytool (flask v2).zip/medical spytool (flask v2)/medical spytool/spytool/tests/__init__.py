"""Tests für Medical Spytool"""
import pytest
from core.config_manager import ConfigManager
from core.logger import Logger
from core.database_service import DatabaseService
from gui.pubmed_tab import PubMedTab
from gui.search_tab import SearchTab

@pytest.fixture
def setup_core_services():
    """Fixture für Core-Services"""
    config_manager = ConfigManager()
    logger = Logger()
    database_service = DatabaseService(config_manager, logger)
    return config_manager, logger, database_service

def test_pubmed_search(setup_core_services):
    """Test PubMed-Suche"""
    config_manager, logger, database_service = setup_core_services
    pubmed_tab = PubMedTab(None, config_manager, logger, database_service)
    # TODO: Implementiere Test-Logik
    assert pubmed_tab is not None

def test_search_tab(setup_core_services):
    """Test allgemeine Suche"""
    config_manager, logger, database_service = setup_core_services
    search_tab = SearchTab(None, config_manager, logger, database_service)
    # TODO: Implementiere Test-Logik
    assert search_tab is not None