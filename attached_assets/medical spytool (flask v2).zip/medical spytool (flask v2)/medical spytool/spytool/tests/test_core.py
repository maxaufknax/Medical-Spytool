"""Tests for core functionality"""
import unittest
import os
import json
from src.core.config_manager import ConfigManager
from src.core.logger import Logger

class TestConfigManager(unittest.TestCase):
    def setUp(self):
        self.config_manager = ConfigManager()
        
    def test_default_config(self):
        """Test that default configuration is created correctly"""
        config = self.config_manager.get_config()
        
        # Check that required sections exist
        self.assertIn('api_keys', config)
        self.assertIn('search_settings', config)
        self.assertIn('export_settings', config)
        
        # Check API keys section
        api_keys = config['api_keys']
        self.assertIn('pubmed', api_keys)
        self.assertIn('dnb', api_keys)
        self.assertIn('wos', api_keys)
        self.assertIn('scopus', api_keys)
        
    def test_set_api_key(self):
        """Test setting and retrieving API keys"""
        test_key = "test_api_key_123"
        self.config_manager.set_api_key('pubmed', test_key)
        
        # Verify key was saved
        saved_key = self.config_manager.get_api_key('pubmed')
        self.assertEqual(saved_key, test_key)
        
class TestLogger(unittest.TestCase):
    def setUp(self):
        self.logger = Logger()
        
    def test_log_creation(self):
        """Test that log file is created and writable"""
        test_message = "Test log message"
        self.logger.info(test_message)
        
        # Check that logs directory exists
        self.assertTrue(os.path.exists(self.logger.log_dir))
        
        # Check that at least one log file exists
        log_files = os.listdir(self.logger.log_dir)
        self.assertTrue(len(log_files) > 0)
        
if __name__ == '__main__':
    unittest.main()