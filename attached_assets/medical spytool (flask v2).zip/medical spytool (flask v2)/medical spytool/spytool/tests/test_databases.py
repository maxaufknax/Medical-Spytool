import tkinter as tk
from tkinter import ttk
from gui import SpytoolGUI

def main():
    root = tk.Tk()
    root.title("Spytool - Publication Search and Analysis")
    app = SpytoolGUI(root)
    root.mainloop()

if __name__ == "__main__":
    main()