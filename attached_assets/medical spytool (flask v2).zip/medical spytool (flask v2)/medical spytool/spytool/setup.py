"""Setup configuration for Medical Spytool"""
from setuptools import setup, find_packages

setup(
    name="medical-spytool",
    version="1.0.0",
    description="Ein Tool zur medizinischen Literaturrecherche",
    author="Marcus Paasche",
    packages=find_packages(where='src'),
    package_dir={'': 'src'},
    install_requires=[
        'requests>=2.31.0',
        'beautifulsoup4>=4.12.2',
        'lxml>=4.9.3',
        'pandas>=2.1.0',
        'openpyxl>=3.1.2'
    ],
    entry_points={
        'console_scripts': [
            'medical-spytool=main:main',
        ],
    },
    python_requires='>=3.8',
    classifiers=[
        'Development Status :: 4 - Beta',
        'Intended Audience :: Science/Research',
        'Topic :: Scientific/Engineering :: Medical Science Apps.',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
    ],
)