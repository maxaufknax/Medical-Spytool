# Medical Spytool

Ein Tool zur systematischen medizinischen Literaturrecherche. Durchsuchen Sie PubMed, DNB, Web of Science und Scopus in einer einzigen Anwendung.

## Installation

1. Stellen Sie sicher, dass Python 3.8 oder höher installiert ist.

2. Klonen Sie das Repository:
```bash
git clone https://github.com/yourusername/medical-spytool.git
cd medical-spytool
```

3. Installieren Sie das Paket im Entwicklungsmodus:
```bash
pip install -e .
```

## Konfiguration

Vor der ersten Nutzung müssen Sie API-Keys für die verschiedenen Datenbanken konfigurieren:

1. Öffnen Sie das Programm:
```bash
medical-spytool
```

2. Navigieren Sie zum "Einstellungen" Tab
3. Tragen Sie Ihre API-Keys für die gewünschten Datenbanken ein

Die API-Keys werden in `config/settings.json` gespeichert.

## Verwendung

1. Starten Sie das Programm:
```bash
medical-spytool
```

2. Im "Suche" Tab:
   - Geben Sie Ihre Suchbegriffe ein
   - Wählen Sie die gewünschten Datenbanken aus
   - Klicken Sie auf "Suche starten"

3. Die Ergebnisse erscheinen in der Tabelle und können:
   - Sortiert
   - Gefiltert
   - Exportiert werden

## Features

- Gleichzeitige Suche in mehreren Datenbanken (PubMed, DNB, Web of Science, Scopus)
- Deduplizierung von Ergebnissen
- Export in verschiedene Formate (CSV, Excel)
- Speichern von Suchhistorie
- Analyse von Publikationstrends

## Projektstruktur

```
spytool/
├── config/            # Konfigurationsdateien
├── src/              # Quellcode
│   ├── core/         # Kernfunktionen
│   ├── databases/    # Datenbankmodule
│   ├── gui/          # GUI-Komponenten
│   └── utils/        # Hilfsfunktionen
└── tests/            # Testmodule
```

## Support

Bei Fragen oder Problemen öffnen Sie bitte ein Issue im GitHub Repository.