# -*- mode: python ; coding: utf-8 -*-
# Medical-Spytool Windows Executable Spec
# Optimized for standalone distribution

import sys
from pathlib import Path

block_cipher = None

# Application data files
added_files = [
    (r'/workspaces/Medical-Spytool\README.md', '.'),
    (r'/workspaces/Medical-Spytool\LICENSE', '.'),
    (r'/workspaces/Medical-Spytool\requirements.txt', '.'),
]

# Core hidden imports for medical research functionality
hidden_imports = [
    # Core Python packages
    'requests',
    'urllib3', 
    'certifi',
    
    # HTML/XML parsing
    'bs4',
    'lxml',
    'html.parser',
    
    # Data handling
    'pandas',
    'numpy',
    'openpyxl',
    'xlsxwriter',
    
    # Date/time utilities
    'dateutil',
    'dateutil.parser',
    'dateutil.tz',
    
    # Progress bars and utilities
    'tqdm',
    
    # Application modules
    'dnb_spytool',
    'dnb_spytool.__main__',
    'dnb_spytool.api',
    'dnb_spytool.api.dnb_api',
    'dnb_spytool.api.pubmed_api',
    'dnb_spytool.gui',
    'dnb_spytool.gui.main_window',
    'dnb_spytool.utils',
    'dnb_spytool.utils.file_handler',
    'dnb_spytool.utils.validators',
    'dnb_spytool.analytics',
    'dnb_spytool.analytics.analyzer',
    'dnb_spytool.cli',
    
    # GUI libraries (if used)
    'tkinter',
    'tkinter.ttk',
    'tkinter.messagebox',
    'tkinter.filedialog',
]

# Modules to exclude for smaller executable
excluded_modules = [
    # Heavy scientific packages not essential for core functionality
    'matplotlib',
    'seaborn',
    'scipy',
    'scikit-learn',
    'torch',
    'tensorflow',
    'keras',
    
    # Development and testing
    'pytest',
    'unittest',
    'doctest',
    'pdb',
    'pydoc',
    
    # Jupyter/IPython
    'jupyter',
    'IPython',
    'notebook',
    'jupyterlab',
    
    # Other optional packages
    'PIL',
    'cv2',
    'sqlite3',
    'multiprocessing',
]

a = Analysis(
    [r'/workspaces/Medical-Spytool/dnb_spytool\__main__.py'],
    pathex=[r'/workspaces/Medical-Spytool'],
    binaries=[],
    datas=added_files,
    hiddenimports=hidden_imports,
    hookspath=[],
    runtime_hooks=[],
    excludes=excluded_modules,
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

# Remove duplicate entries
a.datas = list(set(a.datas))

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    name='Medical-Spytool',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=True,
    icon=None,
    version_file=None,
)

# Optional: Create an installer directory structure
coll = COLLECT(
    exe,
    a.binaries,
    a.zipfiles,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name='Medical-Spytool-Installer',
)
